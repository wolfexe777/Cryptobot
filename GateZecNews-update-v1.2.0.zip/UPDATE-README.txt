Gate ZEC News update 1.0.0/1.1.0 -> 1.2.0 HYBRID
1. Stop the existing bot using STOP.cmd.
2. Extract this ZIP INTO the existing bot folder, replacing files.
3. Existing runtime and settings.json are preserved. Wallets are in LOCALAPPDATA and are not modified by this ZIP.
4. Run CHECK.cmd, CHECK_NETWORK.cmd, then START.cmd.
5. Diagnostics: %LOCALAPPDATA%\GateZecNews\network-check.json
The update requires the original 1.0.0 Windows package with its bundled runtime.
