@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
  echo Extract the entire GatePaper-Windows folder from the ZIP before starting.
  pause
  exit /b 1
)
"%~dp0runtime\python.exe" -I -B -X utf8 "%~dp0app\main.py" --stop %*
set "gatepaper_exit=%ERRORLEVEL%"
if not "%gatepaper_exit%"=="0" (
  echo GatePaper returned an error. See the message above.
  pause
)
exit /b %gatepaper_exit%
