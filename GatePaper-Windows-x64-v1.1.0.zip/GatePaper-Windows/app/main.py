"""Windows portable entry point; stdlib only. Source usage works on Linux too."""

import argparse
import json
import logging
import os
import sys
import threading
import urllib.request
import webbrowser
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.parse import urlsplit

# -I isolates the bundled interpreter; add only this application's own sources.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from gatepaper.config import read
from gatepaper.locking import InstanceLock
from gatepaper.service import Service
from gatepaper.web import create_server


def local_url(value):
    parsed = urlsplit(value)
    if (
        parsed.scheme != "http"
        or parsed.hostname != "127.0.0.1"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path
        or parsed.query
        or parsed.fragment
        or parsed.port is None
        or not 1024 <= parsed.port <= 65535
    ):
        raise ValueError("Недопустимый локальный адрес управления")
    return value


def run(argv=None):
    parser = argparse.ArgumentParser(
        description="GatePaper Desktop — только виртуальные ETH_USDT фьючерсы"
    )
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument(
        "--settings", type=Path, default=Path(__file__).resolve().parent.parent / "settings.json"
    )
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--stop", action="store_true")
    args = parser.parse_args(argv)
    if not 1024 <= args.port <= 65535:
        parser.error("Порт: 1024..65535")
    directory = (
        args.data_dir
        or Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share"))) / "GatePaper"
    )
    directory.mkdir(parents=True, exist_ok=True)
    if args.stop:
        try:
            info = json.loads((directory / "control.json").read_text())
            # A local file must never redirect a token/request to a remote endpoint.
            url = local_url(info["url"])
            request = urllib.request.Request(
                url + "/api/shutdown",
                data=b"{}",
                headers={"X-Control-Token": info["token"], "Content-Type": "application/json"},
            )
            urllib.request.urlopen(request, timeout=5).close()
            print("GatePaper stopped.")
            return 0
        except (OSError, ValueError, KeyError) as exc:
            print("GatePaper is not running or its control file is unavailable:", exc)
            return 1
    try:
        lock = InstanceLock(directory / "instance.lock")
    except RuntimeError:
        info = json.loads((directory / "control.json").read_text())
        url = local_url(info["url"])
        with urllib.request.urlopen(url + "/api/health", timeout=5) as response:
            if json.load(response).get("application") != "gatepaper-windows":
                raise RuntimeError("Порт занят другим приложением") from None
        if not args.no_browser:
            webbrowser.open(url)
        print("GatePaper is already running.")
        return 0
    service = server = None
    try:
        read(args.settings)
        logs = directory / "logs"
        logs.mkdir(exist_ok=True)
        logger = logging.getLogger("gatepaper")
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(
            logs / "app.log", maxBytes=1024 * 1024, backupCount=3, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        service = Service(directory, args.settings)
        server, token = create_server(
            service, Path(__file__).resolve().parent / "static", args.port
        )
        url = f"http://127.0.0.1:{server.server_port}"
        (directory / "control.json").write_text(
            json.dumps({"url": url, "token": token}), encoding="utf-8"
        )
        service.start_worker()
        if not args.no_browser:
            threading.Timer(0.5, webbrowser.open, args=(url,)).start()
        print("GatePaper PAPER is running. Real orders are disabled. Keep this window open.")
        print("Local interface:", url)
        print("Press Ctrl+C or use STOP.cmd to exit. Data:", directory)
        server.serve_forever(poll_interval=0.25)
        return 0
    except KeyboardInterrupt:
        return 0
    finally:
        if server:
            server.server_close()
        if service:
            service.close()
        lock.close()


if __name__ == "__main__":
    try:
        raise SystemExit(run())
    except Exception as error:
        logging.getLogger("gatepaper").exception("Application startup failed")
        print("GatePaper could not start:", error, file=sys.stderr)
        raise SystemExit(1) from error
