"""Verified-HTTPS, read-only Gate futures data and immutable local research inputs."""

import hashlib
import json
import os
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

BASE = "https://api.gateio.ws/api/v4/futures/usdt"
CONTRACT = "ETH_USDT"


class MarketError(RuntimeError):
    pass


@dataclass(frozen=True)
class Bar:
    t: int
    o: Decimal
    h: Decimal
    l: Decimal
    c: Decimal
    v: Decimal

    def __post_init__(self):
        if type(self.t) is not int or self.t < 0 or self.t % 60000:
            raise ValueError("Candle time must be minute-aligned Unix milliseconds")
        for field in ("o", "h", "l", "c", "v"):
            value = Decimal(str(getattr(self, field)))
            if not value.is_finite() or value < 0 or (field != "v" and not 0 < value < 1e9):
                raise ValueError("Invalid OHLCV value")
            object.__setattr__(self, field, value)
        if not self.l <= min(self.o, self.c) <= max(self.o, self.c) <= self.h:
            raise ValueError("Inconsistent candle high/low")

    def row(self):
        return [self.t, *[str(getattr(self, f)) for f in ("o", "h", "l", "c", "v")]]


def atomic_json(path, document):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False, encoding="utf-8") as f:
            name = f.name
            json.dump(document, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, path)
    finally:
        if name and os.path.exists(name):
            os.unlink(name)


def get(path, params=None):
    url = BASE + path + ("?" + urllib.parse.urlencode(params) if params else "")
    request = urllib.request.Request(
        url, headers={"Accept": "application/json", "User-Agent": "Cryptobot-Paper/0.2"}
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            raw = response.read(4 * 1024 * 1024 + 1)
        if len(raw) > 4 * 1024 * 1024:
            raise MarketError("Gate response exceeds 4 MiB")
        return json.loads(raw, parse_float=Decimal)
    except urllib.error.HTTPError as exc:
        code = exc.code
        exc.close()
        raise MarketError(f"Gate HTTP {code}: public market data unavailable") from None
    except (OSError, ValueError) as exc:
        raise MarketError(f"Cannot read verified Gate market data: {exc}") from exc


def contract():
    data = get(f"/contracts/{CONTRACT}")
    if data.get("name") != CONTRACT or data.get("in_delisting") or data.get("type") != "direct":
        raise MarketError("ETH_USDT contract unavailable")
    spec = {
        "multiplier": str(data["quanto_multiplier"]),
        "minimum": max(
            1, int(Decimal(str(data["order_size_min"])).to_integral_value(rounding="ROUND_CEILING"))
        ),
        "maintenance": str(data["maintenance_rate"]),
        "fee": str(data["taker_fee_rate"]),
        "tick": str(data["order_price_round"]),
        "funding_interval": data["funding_interval"],
        "funding_offset": data.get("funding_offset", 0),
    }
    if any(
        not Decimal(spec[k]).is_finite() or Decimal(spec[k]) <= 0
        for k in ("multiplier", "maintenance", "tick")
    ):
        raise MarketError("Invalid contract specification")
    if not 60 <= spec["funding_interval"] <= 86400:
        raise MarketError("Invalid funding interval")
    return spec


def candles(limit=1000, since=None, interval="1m"):
    if interval not in ("1m", "5m"):
        raise ValueError("Supported intervals: 1m, 5m")
    seconds = 60 if interval == "1m" else 300
    if type(limit) is not int or not 1 <= limit <= 2000:
        raise ValueError("Gate candles limit: 1..2000")
    params = {"contract": CONTRACT, "interval": interval}
    if since is None:
        params["limit"] = limit
    else:
        params.update({"from": since, "to": since + limit * seconds - 1})
    now = int(time.time())
    result = []
    for item in get("/candlesticks", params):
        t = int(item["t"])
        if t + seconds <= now:
            result.append(Bar(t * 1000, *[item[k] for k in ("o", "h", "l", "c", "v")]))
    result.sort(key=lambda x: x.t)
    if any(b.t - a.t != seconds * 1000 for a, b in zip(result, result[1:], strict=False)):
        raise MarketError("Gate minute history has gaps or duplicates")
    return result


def funding():
    result = []
    for event in get("/funding_rate", {"contract": CONTRACT, "limit": 100}):
        source = int(event["t"]) * 1000
        rate = Decimal(str(event["r"]))
        if not rate.is_finite() or abs(rate) > Decimal(".1"):
            raise MarketError("Invalid funding rate")
        # Minute OHLC simulation settles at the nominal minute open; retain source timing.
        result.append({"t": source // 60000 * 60000, "source_t": source, "rate": str(rate)})
    result.sort(key=lambda x: x["t"])
    if len({x["t"] for x in result}) != len(result):
        raise MarketError("Ambiguous duplicate funding settlements")
    return result


def coverage(spec, rates, start, end):
    interval = spec["funding_interval"] * 1000
    offset = spec["funding_offset"] * 1000
    first = ((start - offset + interval - 1) // interval) * interval + offset
    actual = {r["t"] for r in rates}
    if any(t not in actual for t in range(first, end, interval)):
        raise MarketError("Missing published funding: wait for Gate or shorten history")


def load_dataset(path):
    document = json.loads(Path(path).read_text())
    payload = {k: document[k] for k in ("bars", "funding", "spec")}
    digest = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if digest != document["metadata"]["sha256"]:
        raise ValueError("Dataset SHA256 mismatch")
    bars = [Bar(*row) for row in document["bars"]]
    meta = document["metadata"]
    if len(bars) != meta["count"] or any(
        b.t != meta["start"] + i * meta.get("bar_ms", 60000) for i, b in enumerate(bars)
    ):
        raise ValueError("Incomplete dataset")
    if not bars or bars[-1].t + meta.get("bar_ms", 60000) != meta["end"]:
        raise ValueError("Invalid dataset range")
    coverage(document["spec"], document["funding"], meta["start"], meta["end"])
    return bars, document


def download(path, days=6, interval="1m"):
    path = Path(path)
    if path.exists():
        cached = load_dataset(path)
        if cached[1]["metadata"]["interval"] != interval:
            raise ValueError("Cached interval differs; choose a new dataset path")
        return cached
    seconds = {"1m": 60, "5m": 300}.get(interval)
    if seconds is None or type(days) is not int or not 1 <= days <= (6 if interval == "1m" else 30):
        raise ValueError("History limits: six days 1m or thirty days 5m")
    step = seconds * 1000
    end = int(time.time()) // seconds * step
    start = end - days * 86400000
    spec = contract()
    rates = [r for r in funding() if start <= r["t"] < end]
    coverage(spec, rates, start, end)
    jobs = [(t // 1000, min(2000, (end - t) // step)) for t in range(start, end, 2000 * step)]

    def fetch(job):
        since, count = job
        bars = candles(count, since, interval)
        if len(bars) != count or bars[0].t != since * 1000:
            raise MarketError("Incomplete requested Gate history")
        return bars

    with ThreadPoolExecutor(max_workers=2) as pool:
        bars = [b for chunk in pool.map(fetch, jobs) for b in chunk]
    payload = {"bars": [b.row() for b in bars], "funding": rates, "spec": spec}
    digest = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    document = {
        **payload,
        "metadata": {
            "source": "Gate public futures API",
            "contract": CONTRACT,
            "interval": interval,
            "bar_ms": step,
            "start": start,
            "end": end,
            "count": len(bars),
            "sha256": digest,
            "downloaded_at": int(time.time() * 1000),
            "history_limit": 10000,
            "funding_timing": "minute open approximation; source_t preserves original timestamps",
        },
    }
    atomic_json(path, document)
    return load_dataset(path)
