"""Local settings, restricted to virtual execution and known strategy identifiers."""

import hashlib
import json

from .alternatives import NAMES as ALTERNATIVE_NAMES
from .broker import TradeConfig
from .indicators import NAMES

DEFAULT = {
    "mode": "paper",
    "exchange": "gate",
    "contract": "ETH_USDT",
    "interval": "5m",
    "strategies": list(ALTERNATIVE_NAMES),
    "strategy_trade": {},
    "auto_start": True,
    "trade": TradeConfig(
        stop=".010",
        take=".020",
        max_hold=240,
        cooldown=15,
        daily_loss_pct=".3",
        total_loss_pct="1",
        daily_entries=6,
        loss_streak=3,
    ).to_dict(),
}


def validate(document):
    allowed = set(DEFAULT)
    if set(document) - allowed:
        raise ValueError("В settings.json есть неизвестные поля")
    result = {**DEFAULT, **document}
    if (
        result["mode"] != "paper"
        or result["exchange"] != "gate"
        or result["contract"] != "ETH_USDT"
    ):
        raise ValueError("Эта сборка поддерживает только виртуальные ETH_USDT фьючерсы Gate")
    if result["interval"] not in ("1m", "5m"):
        raise ValueError("Интервал: 1m или 5m")
    if type(result["auto_start"]) is not bool:
        raise ValueError("auto_start должен быть true или false")
    names = result["strategies"]
    if (
        not isinstance(names, list)
        or not names
        or any(not isinstance(x, str) or x not in NAMES for x in names)
        or len(set(names)) != len(names)
    ):
        raise ValueError("Укажите неповторяющиеся стратегии из списка в инструкции")
    result["trade"] = TradeConfig(**result["trade"]).to_dict()
    if result["interval"] != "5m" and any(n in ALTERNATIVE_NAMES for n in names):
        raise ValueError("Новые часовые/дневные стратегии поддерживают только 5m")
    overrides = result["strategy_trade"]
    if not isinstance(overrides, dict) or any(n not in NAMES for n in overrides):
        raise ValueError("Неизвестная стратегия в strategy_trade")
    for name, values in overrides.items():
        if not isinstance(values, dict) or set(values) - {"stop", "take", "max_hold", "cooldown"}:
            raise ValueError("strategy_trade меняет только stop/take/max_hold/cooldown")
        trade_config(result, name)
    if result["interval"] == "5m" and result["trade"]["max_hold"] % 5:
        raise ValueError("Удержание на 5m должно быть кратно пяти минутам")
    return result


def trade_config(config, name):
    values = {**config["trade"], **config.get("strategy_trade", {}).get(name, {})}
    result = TradeConfig(**values)
    if config["interval"] == "5m" and (result.max_hold % 5 or result.cooldown % 5):
        raise ValueError("Удержание и пауза на 5m должны быть кратны пяти минутам")
    return result


def read(path):
    return validate(json.loads(path.read_text(encoding="utf-8-sig")))


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
