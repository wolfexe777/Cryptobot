"""Thread-safe persistent multi-strategy PAPER service, using only public Gate GETs."""

import copy
import csv
import io
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import replace
from decimal import Decimal

from . import market
from .broker import Broker, TradeConfig
from .config import digest, read, trade_config
from .indicators import NAMES, Indicators

LOGGER = logging.getLogger("gatepaper")


class Service:
    def __init__(self, directory, settings):
        self.directory, self.settings = directory, settings
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.shutdown = threading.Event()
        self.thread = self.job_thread = None
        self.error = None
        self.last_poll = None
        self.job = {"running": False, "message": "Исторический тест ещё не запускался"}
        self.db = sqlite3.connect(
            directory / "paper.sqlite3", check_same_thread=False, isolation_level=None
        )
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS snapshot(id INTEGER PRIMARY KEY,body TEXT NOT NULL,revision INTEGER NOT NULL)"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS archives(id INTEGER PRIMARY KEY,body TEXT NOT NULL)"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS observations(session TEXT,t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,t))"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS trades(session TEXT,strategy TEXT,entry_t INTEGER,exit_t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,strategy,entry_t,exit_t))"
        )
        row = self.db.execute("SELECT body,revision FROM snapshot WHERE id=1").fetchone()
        self.state, self.revision = (
            (json.loads(row[0]), row[1]) if row else (self.new_state(read(settings)), 0)
        )
        if self.state.get("version") != 1:
            raise ValueError("Неизвестная версия сохранённого счёта; база не сброшена")
        if not row:
            self.commit(self.state)

    @staticmethod
    def new_state(config):
        return {
            "version": 1,
            "session": uuid.uuid4().hex,
            "config": config,
            "config_sha256": digest(config),
            "running": config["auto_start"],
            "initialized": False,
            "spec": None,
            "books": {},
            "indicators": None,
            "last_processed": None,
            "new_bars": 0,
            "started_at": None,
        }

    def commit(self, state, observations=(), trades=(), archive=False):
        raw = json.dumps(state, ensure_ascii=False, allow_nan=False)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row = self.db.execute("SELECT revision FROM snapshot WHERE id=1").fetchone()
            if (row[0] if row else 0) != self.revision:
                raise ValueError("Состояние изменено другим процессом; запустите один экземпляр")
            if archive:
                self.db.execute("INSERT INTO archives(body) VALUES(?)", (json.dumps(self.state),))
            for bar, rate in observations:
                body = json.dumps({"bar": bar.row(), "funding": rate}, sort_keys=True)
                old = self.db.execute(
                    "SELECT body FROM observations WHERE session=? AND t=?",
                    (state["session"], bar.t),
                ).fetchone()
                if old and old[0] != body:
                    raise ValueError("Сохранённая свеча изменилась")
                self.db.execute(
                    "INSERT OR IGNORE INTO observations VALUES(?,?,?)",
                    (state["session"], bar.t, body),
                )
            for strategy, trade in trades:
                self.db.execute(
                    "INSERT INTO trades VALUES(?,?,?,?,?)",
                    (
                        state["session"],
                        strategy,
                        trade["entry_time"],
                        trade["exit_time"],
                        json.dumps(trade),
                    ),
                )
            revision = self.revision + 1
            self.db.execute("INSERT OR REPLACE INTO snapshot VALUES(1,?,?)", (raw, revision))
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
        self.state, self.revision = state, revision

    def start_worker(self):
        self.thread = threading.Thread(target=self.worker, name="gate-market-data", daemon=True)
        self.thread.start()

    def worker(self):
        while not self.shutdown.is_set():
            try:
                self.tick()
            except (OSError, ValueError, market.MarketError, sqlite3.Error) as exc:
                with self.lock:
                    self.error = str(exc)
                    self.last_poll = int(time.time() * 1000)
                LOGGER.warning("Market/state: %s", exc)
            except Exception:
                LOGGER.exception("Unexpected worker failure")
                with self.lock:
                    self.error = "Внутренняя ошибка; подробности в logs/app.log"
            self.shutdown.wait(10)

    def tick(self):
        with self.lock:
            if not self.state["running"]:
                return
            state = copy.deepcopy(self.state)
            revision = self.revision
        config = state["config"]
        step = 60000 if config["interval"] == "1m" else 300000
        cutoff = (int(time.time() * 1000) - 15000) // step * step
        # Publication grace and source specification checks precede any state mutation.
        if self.shutdown.is_set():
            return
        spec = market.contract()
        cfg = TradeConfig(**config["trade"])
        if Decimal(cfg.fee) < Decimal(spec["fee"]):
            raise market.MarketError("Комиссия в settings.json ниже публичного тарифа Gate")
        if self.shutdown.is_set():
            return
        observations = []
        closed = []
        if not state["initialized"]:
            bars = [
                b for b in market.candles(600, None, config["interval"]) if b.t + step <= cutoff
            ]
            if len(bars) < 200 or bars[-1].t + step != cutoff:
                raise market.MarketError("Не хватает завершённых свечей для прогрева")
            indicators = Indicators(interval=config["interval"])
            for bar in bars:
                indicators.update(bar)
            books = {
                name: Broker(trade_config(config, name), spec) for name in config["strategies"]
            }
            for book in books.values():
                book.last_t, book.last_price = bars[-1].t, bars[-1].c
            state.update(
                initialized=True,
                spec=spec,
                indicators=indicators.dump(),
                books={name: b.to_state() for name, b in books.items()},
                last_processed=cutoff,
                started_at=int(time.time() * 1000),
            )
            observations = [(bar, None) for bar in bars]
        else:
            if spec != state["spec"]:
                raise market.MarketError(
                    "Изменились условия контракта Gate; счёт сохранён, обработка остановлена"
                )
            since = state["last_processed"]
            bars = []
            if (cutoff - since) // step > 10000:
                raise market.MarketError(
                    "Перерыв превышает доступную историю Gate; пропущенные цены не выдумываются"
                )
            while since < cutoff:
                if self.shutdown.is_set():
                    return
                count = min(2000, (cutoff - since) // step)
                batch = market.candles(count, since // 1000, config["interval"])
                if (
                    len(batch) != count
                    or batch[0].t != since
                    or batch[-1].t + step != since + count * step
                ):
                    raise market.MarketError(
                        "Gate ещё не опубликовал полную непрерывную последовательность свечей"
                    )
                bars.extend(batch)
                since += count * step
            if bars:
                if self.shutdown.is_set():
                    return
                rates = market.funding()
                market.coverage(spec, rates, bars[0].t, bars[-1].t + step)
                mapping = {r["t"]: r for r in rates}
                indicators = Indicators(state["indicators"], interval=config["interval"])
                books = {name: Broker.restore(raw) for name, raw in state["books"].items()}
                for bar in bars:
                    values = indicators.update(bar)
                    for name, book in books.items():
                        for trade in book.process(
                            bar, values[name], mapping.get(bar.t, {}).get("rate", "0")
                        ):
                            closed.append((name, trade))
                    observations.append((bar, mapping.get(bar.t)))
                for book in books.values():
                    book.curve = book.curve[-600:]
                    book.history = book.history[-200:]
                state.update(
                    indicators=indicators.dump(),
                    books={k: b.to_state() for k, b in books.items()},
                    last_processed=cutoff,
                    new_bars=state["new_bars"] + len(bars),
                )
                if len(bars) > 2:
                    LOGGER.info("Replayed %s missed real candles", len(bars))
        if self.shutdown.is_set():
            return
        with self.lock:
            if self.revision != revision or not self.state["running"]:
                return
            if observations:
                self.commit(state, observations, closed)
            self.last_poll = int(time.time() * 1000)
            self.error = None

    def status(self):
        with self.lock:
            s = self.state
            rows = []
            for name in s["config"]["strategies"]:
                book = Broker.restore(s["books"][name]) if s["initialized"] else None
                metrics = (
                    book.metrics()
                    if book
                    else {
                        "equity": s["config"]["trade"]["balance"],
                        "net_pnl": "0",
                        "trades": 0,
                        "wins": 0,
                        "win_rate": 0,
                        "fees": "0",
                        "funding": "0",
                        "position": False,
                        "max_drawdown_pct": "0",
                        "risk_status": "waiting_for_data",
                        "profit_factor": None,
                    }
                )
                rows.append(
                    {
                        "id": name,
                        "name": NAMES[name],
                        "trade_config": trade_config(s["config"], name).to_dict(),
                        "summary": metrics,
                        "position": book.to_state()["position"] if book else None,
                        "history": book.history[-100:] if book else [],
                        "curve": book.curve if book else [],
                    }
                )
            try:
                changed = digest(read(self.settings)) != s["config_sha256"]
            except (OSError, ValueError, TypeError):
                changed = True
            return {
                "application": "gatepaper-windows",
                "mode": "paper",
                "real_orders": False,
                "running": s["running"],
                "initialized": s["initialized"],
                "rows": rows,
                "error": self.error,
                "last_poll": self.last_poll,
                "last_processed": s["last_processed"],
                "new_bars": s["new_bars"],
                "session": s["session"],
                "config": s["config"],
                "settings_changed": changed,
                "backtest": copy.deepcopy(self.job),
                "data_directory": str(self.directory),
            }

    def set_running(self, running):
        with self.lock:
            if type(running) is not bool:
                raise ValueError("Некорректный режим запуска")
            state = copy.deepcopy(self.state)
            state["running"] = running
            self.commit(state)
            if running:
                self.error = None

    def reset(self, confirmation):
        with self.lock:
            if self.state["running"]:
                raise ValueError("Сначала нажмите «Пауза»")
            if confirmation != "YES_RESET_PAPER":
                raise ValueError("Подтвердите новый виртуальный счёт")
            state = self.new_state(read(self.settings))
            state["running"] = False
            self.commit(state, archive=True)
            self.error = None

    def export_csv(self):
        with self.lock:
            rows = self.db.execute(
                "SELECT strategy,body FROM trades WHERE session=? ORDER BY exit_t",
                (self.state["session"],),
            ).fetchall()
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow(
            [
                "strategy",
                "entry_time_utc_ms",
                "exit_time_utc_ms",
                "side",
                "quantity_ETH",
                "entry_price",
                "exit_price",
                "net_pnl_USDT",
                "fees_USDT",
                "funding_USDT",
                "reason",
            ]
        )
        for name, raw in rows:
            r = json.loads(raw)
            writer.writerow(
                [
                    name,
                    *[
                        r[k]
                        for k in (
                            "entry_time",
                            "exit_time",
                            "side",
                            "quantity",
                            "entry_price",
                            "exit_price",
                            "net_pnl",
                            "fees",
                            "funding",
                            "reason",
                        )
                    ],
                ]
            )
        return ("\ufeff" + output.getvalue()).encode("utf-8")

    def start_backtest(self, days):
        if type(days) is not int or days not in (3, 7, 30):
            raise ValueError("Тест: 3, 7 или 30 дней")
        with self.lock:
            if self.job["running"]:
                raise ValueError("Исторический тест уже выполняется")
            job_id = uuid.uuid4().hex
            config = copy.deepcopy(self.state["config"])
            if config["interval"] == "1m" and days > 3:
                raise ValueError("На 1m доступен тест трёх дней; для 7/30 дней выберите 5m")
            self.job = {
                "running": True,
                "id": job_id,
                "message": "Загрузка настоящей истории Gate…",
            }
        self.job_thread = threading.Thread(
            target=self.backtest, args=(job_id, days, config), daemon=True
        )
        self.job_thread.start()

    def backtest(self, job_id, days, config):
        try:
            step = 60000 if config["interval"] == "1m" else 300000
            end = (int(time.time() * 1000) - 15000) // step * step
            start = end - days * 86400000
            warm_start = start - 500 * step
            bars = []
            since = warm_start
            spec = market.contract()
            cfg = TradeConfig(**config["trade"])
            if Decimal(cfg.fee) < Decimal(spec["fee"]):
                raise ValueError("Комиссия ниже тарифа Gate")
            while since < end:
                if self.shutdown.is_set():
                    return
                count = min(2000, (end - since) // step)
                batch = market.candles(count, since // 1000, config["interval"])
                if (
                    len(batch) != count
                    or batch[0].t != since
                    or batch[-1].t + step != since + count * step
                ):
                    raise market.MarketError("Неполная история Gate — тест не завершён")
                bars.extend(batch)
                since += count * step
                with self.lock:
                    self.job["message"] = f"Загружено свечей: {len(bars)}"
            rates = market.funding()
            market.coverage(spec, rates, warm_start, end)
            funding = [r for r in rates if warm_start <= r["t"] < end]
            payload = {"bars": [b.row() for b in bars], "funding": funding, "spec": spec}
            document = {
                **payload,
                "metadata": {
                    "source": "Gate public futures API",
                    "contract": market.CONTRACT,
                    "interval": config["interval"],
                    "bar_ms": step,
                    "start": warm_start,
                    "end": end,
                    "count": len(bars),
                    "sha256": digest(payload),
                    "evaluation_start": start,
                },
            }
            destination = self.directory / "backtests"
            destination.mkdir(exist_ok=True)
            market.atomic_json(destination / (job_id + ".dataset.json"), document)
            indicators = Indicators(interval=config["interval"])
            normal = {n: Broker(trade_config(config, n), spec) for n in config["strategies"]}
            stress = {
                n: Broker(
                    replace(
                        trade_config(config, n),
                        slippage=str(Decimal(cfg.slippage) * Decimal("1.5")),
                    ),
                    spec,
                )
                for n in config["strategies"]
            }
            mapping = {r["t"]: r["rate"] for r in funding}
            for index, bar in enumerate(bars):
                if self.shutdown.is_set():
                    return
                values = indicators.update(bar)
                if index < 500:
                    continue
                for name in normal:
                    for book in (normal[name], stress[name]):
                        book.process(bar, values[name], mapping.get(bar.t, "0"))
            result = {
                "running": False,
                "id": job_id,
                "message": "Исторический тест завершён",
                "start": start,
                "end": end,
                "days": days,
                "candles": len(bars) - 500,
                "dataset_sha256": document["metadata"]["sha256"],
                "accepted": False,
                "rows": [
                    {
                        "id": n,
                        "name": NAMES[n],
                        "normal": normal[n].metrics(),
                        "stress": stress[n].metrics(),
                    }
                    for n in normal
                ],
                "note": "Исторический результат; не подтверждает будущую прибыльность",
            }
            market.atomic_json(destination / (job_id + ".result.json"), result)
            with self.lock:
                self.job = result
        except Exception as exc:
            LOGGER.exception("Historical test failed")
            with self.lock:
                self.job = {"running": False, "id": job_id, "message": str(exc), "failed": True}

    def close(self):
        self.shutdown.set()
        for thread in (self.thread, self.job_thread):
            if thread:
                thread.join(timeout=20)
        with self.lock:
            if not any(t and t.is_alive() for t in (self.thread, self.job_thread)):
                self.db.close()
