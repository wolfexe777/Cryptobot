"""Closed-hour and previous-day hypotheses, not evidence of profitability.

Only complete, contiguous native 5m candles form higher-timeframe bars. All
recursive state is persisted; partial hours/days cannot supply reference levels.
"""

import copy

NAMES = {
    "supertrend_hour": "Supertrend · завершённый час",
    "hour_pullback": "Откат по часовому тренду",
    "daily_sweep": "Возврат за уровень прошлого дня",
}

# Frozen before inspecting the new comparison's last segment. Fees, slippage,
# position sizing and account loss limits always come from the user's trade config.
RISK_VARIANTS = (
    {"stop": ".008", "take": ".016", "max_hold": 120, "cooldown": 15},
    {"stop": ".010", "take": ".020", "max_hold": 240, "cooldown": 15},
    {"stop": ".012", "take": ".024", "max_hold": 240, "cooldown": 30},
    {"stop": ".015", "take": ".030", "max_hold": 240, "cooldown": 30},
)

def aggregate(previous, bar, duration):
    bucket = bar.t // duration * duration
    if previous is None or previous["t"] != bucket:
        previous = {
            "t": bucket,
            "o": float(bar.o),
            "h": float(bar.h),
            "l": float(bar.l),
            "c": float(bar.c),
            "count": 0,
            "first": bar.t,
            "last": bar.t - 300000,
        }
    if previous["last"] + 300000 != bar.t:
        raise ValueError("Разрыв внутри старшего таймфрейма")
    previous["h"] = max(previous["h"], float(bar.h))
    previous["l"] = min(previous["l"], float(bar.l))
    previous["c"] = float(bar.c)
    previous["last"] = bar.t
    previous["count"] += 1
    complete = (
        previous["first"] == bucket
        and previous["count"] == duration // 300000
        and bar.t + 300000 == bucket + duration
    )
    return previous, complete


class Alternatives:
    def __init__(self, state=None):
        self.state = (
            copy.deepcopy(state)
            if state
            else {
                "last_t": None,
                "hour": None,
                "day": None,
                "previous_day": None,
                "hours": 0,
                "ema": {},
                "atr_sum": 0.0,
                "atr": None,
                "hour_close": None,
                "upper": None,
                "lower": None,
                "trend": None,
                "previous_rsi": None,
                "sweep_day": None,
                "sweep_sides": [],
            }
        )

    def dump(self):
        return copy.deepcopy(self.state)

    def completed_hour(self, hour):
        s = self.state
        close = hour["c"]
        prior_close = s["hour_close"]
        tr = max(
            hour["h"] - hour["l"],
            abs(hour["h"] - prior_close) if prior_close is not None else 0,
            abs(hour["l"] - prior_close) if prior_close is not None else 0,
        )
        s["hours"] += 1
        for period in (12, 24):
            item = s["ema"].setdefault(str(period), {"sum": 0.0, "value": None})
            if item["value"] is None:
                item["sum"] += close
                if s["hours"] == period:
                    item["value"] = item["sum"] / period
            else:
                item["value"] += 2 / (period + 1) * (close - item["value"])
        if s["hours"] <= 10:
            s["atr_sum"] += tr
            if s["hours"] == 10:
                s["atr"] = s["atr_sum"] / 10
        else:
            s["atr"] = (s["atr"] * 9 + tr) / 10
        signal = 0
        if s["atr"] is not None:
            middle = (hour["h"] + hour["l"]) / 2
            upper, lower = middle + 3 * s["atr"], middle - 3 * s["atr"]
            if s["upper"] is not None:
                upper = upper if upper < s["upper"] or prior_close > s["upper"] else s["upper"]
                lower = lower if lower > s["lower"] or prior_close < s["lower"] else s["lower"]
                trend = (
                    1
                    if s["trend"] == -1 and close > upper
                    else -1
                    if s["trend"] == 1 and close < lower
                    else s["trend"]
                )
                if trend != s["trend"] and s["atr"] / close >= 0.0025:
                    signal = trend
            else:
                trend = 1 if close >= middle else -1
            s.update(upper=upper, lower=lower, trend=trend)
        s["hour_close"] = close
        return signal

    def update(self, bar, rsi):
        s = self.state
        if bar.t % 300000:
            raise ValueError("Новые стратегии требуют native 5m свечи")
        if s["last_t"] is not None and bar.t != s["last_t"] + 300000:
            raise ValueError("Новые стратегии требуют непрерывные 5m свечи")
        result = {name: 0 for name in NAMES}
        day_bucket = bar.t // 86400000 * 86400000
        s["hour"], completed = aggregate(s["hour"], bar, 3600000)
        if completed:
            result["supertrend_hour"] = self.completed_hour(s["hour"])
        if s["day"] is not None and s["day"]["t"] != day_bucket:
            day = s["day"]
            s["previous_day"] = (
                {"h": day["h"], "l": day["l"], "t": day["t"]}
                if day["first"] == day["t"]
                and day["count"] == 288
                and day["t"] + 86400000 == day_bucket
                else None
            )
        s["day"], _ = aggregate(s["day"], bar, 86400000)
        opening, high, low, close, volume = [
            float(getattr(bar, k)) for k in ("o", "h", "l", "c", "v")
        ]
        fast = s["ema"].get("12", {}).get("value")
        slow = s["ema"].get("24", {}).get("value")
        old_rsi = s["previous_rsi"]
        if (
            volume > 0
            and fast is not None
            and slow is not None
            and rsi is not None
            and old_rsi is not None
            and s["atr"] / close >= 0.0025
        ):
            result["hour_pullback"] = (
                1
                if fast > slow
                and s["hour_close"] > slow
                and old_rsi < 40 <= rsi
                and close > opening
                else -1
                if fast < slow
                and s["hour_close"] < slow
                and old_rsi > 60 >= rsi
                and close < opening
                else 0
            )
        if s["sweep_day"] != day_bucket:
            s.update(sweep_day=day_bucket, sweep_sides=[])
        prior_day = s["previous_day"]
        if (
            prior_day
            and volume > 0
            and high > low
            and (prior_day["h"] - prior_day["l"]) / close >= 0.008
        ):
            side = (
                1
                if low < prior_day["l"] < close
                and close > opening
                and (min(opening, close) - low) / (high - low) >= 0.4
                else -1
                if high > prior_day["h"] > close
                and close < opening
                and (high - max(opening, close)) / (high - low) >= 0.4
                else 0
            )
            if side and side not in s["sweep_sides"]:
                result["daily_sweep"] = side
                s["sweep_sides"].append(side)
        if volume <= 0:
            result = {name: 0 for name in NAMES}
        s.update(last_t=bar.t, previous_rsi=rsi)
        return result
