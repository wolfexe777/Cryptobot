# Исследованные открытые проекты и происхождение кода

Поиск и чтение первичных источников выполнены 27 октября 2026. Подтверждённого прибыльного результата для единственного ETH_USDT perpetual Gate не установлено.

| Проект | Что проверено | Использование |
| --- | --- | --- |
| [Freqtrade](https://github.com/freqtrade/freqtrade) | README, GPL-3.0, шаблон стратегии, документация бирж | Архитектурный ориентир: dry-run, бэктест, управление риском; сам движок не включён |
| [Freqtrade strategies](https://github.com/freqtrade/freqtrade-strategies) | README, GPL-3.0, Strategy001/002/004/005 | Вход EMA/Heikin-Ashi адаптирован из Strategy001; RSI/Bollinger — изменённый аналог Strategy002. Исходные 001/002 приложены |
| [NostalgiaForInfinity](https://github.com/iterativv/NostalgiaForInfinity) | README, GPL-3.0, текущий commit | Проект отсылает к результатам бэктестов в комментариях commits и рекомендует 40–80 пар, 6–12 одновременных сделок. Пригодность результатов к одной паре Gate не подтверждена. Код NFI не перенесён |
| [Hummingbot](https://github.com/hummingbot/hummingbot) | README и описание market making, Apache-2.0 | Изучен как другой тип бота; его заявки в стакане не моделируются как гарантированное исполнение по OHLC |

## Точные источники включённых примеров

Автор оригинальных Strategy001/Strategy002 — Gerald Lonlas и участники freqtrade-strategies. Репозиторий GPL-3.0. Зафиксированный commit:
`f3340ce11f5bdf62f598522e64d1f5638eaa13f5`.

- [Strategy001.py](https://github.com/freqtrade/freqtrade-strategies/blob/f3340ce11f5bdf62f598522e64d1f5638eaa13f5/user_data/strategies/Strategy001.py)
- [Strategy002.py](https://github.com/freqtrade/freqtrade-strategies/blob/f3340ce11f5bdf62f598522e64d1f5638eaa13f5/user_data/strategies/Strategy002.py)

Неизменённые оригиналы, LICENSE и SHA256 находятся в third_party/freqtrade-strategies. Они служат исходными материалами, не импортируются программой и не требуют установки Freqtrade, pandas или TA-Lib.

EMA/HA повторяет идею длинного входа с пересечением EMA20/50 и зелёной Heikin-Ashi, добавляет симметричный short. RSI/Bollinger использует подтверждённый возврат в полосу и растущий/падающий Wilder RSI; оригинальные фильтры stochastic/hammer/SAR заменены. Donchian реализован самостоятельно. Во всех вариантах выходы, taker-модель, стопы, удержание и лимиты риска — собственная модель приложения, отличающаяся от upstream minimal_roi/exit-правил. Чужие опубликованные результаты не выдаются за результаты этой сборки.

Сам Windows-код — GPL-3.0, предоставлен полностью. Финансовый симулятор и адаптер Gate перенесены из текущего проекта Cryptobot, без облачного сервера и Unix-зависимостей. Программа использует только стандартную библиотеку Python; все биржевые вызовы — публичные GET.

## Интерпретатор

[CPython от Astral python-build-standalone](https://github.com/astral-sh/python-build-standalone/releases/tag/20261026), Windows x86_64 MSVC, CPython 3.13.18. Дистрибутив загружен по HTTPS, SHA256 сверён с SHA256SUMS релиза и digest страницы assets. Точный URL, версия и хеш в runtime-lock.json. Лицензии исходной поставки сохранены без удаления. Windows-бинарник в Linux не исполнялся.


## Версия 1.1: самостоятельные исследовательские правила

`app/gatepaper/alternatives.py` реализует часовой Supertrend (Wilder ATR10 ×3),
откат RSI по часовым EMA12/24 и возврат за экстремум предыдущего полного UTC-дня.
Это новые самостоятельные реализации классических правил, а не скопированные
«прибыльные» стратегии и не проверенные торговые рекомендации.

Точное определение входов — в README-RU.txt и исходниках. Native 5m агрегируются
только в полные часы/дни. Состояние индикаторов сохраняется. 12 вариантов риска
проверены на ранее сохранённой реальной истории Gate; ни один не прошёл критерии.
Данные, источники SHA256, фиксированный выбор и все результаты включены в
research-inputs; повторный офлайн-прогон выполняет tools/compare_alternatives.py.
