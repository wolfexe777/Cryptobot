"""Fixed, causal market setups on complete 5m bars. No news is required.

Finite SMA/Cutler-RSI windows avoid reseeding recursive indicators on every poll.
The result describes a completed bar; actual entry remains a newly observed quote.
"""

from decimal import Decimal


def evaluate(bars, now):
    grouped = {}
    for bar in bars:
        if bar.t + 60000 <= now:
            grouped.setdefault(bar.t // 300000 * 300000, []).append(bar)
    completed = []
    for start, parts in sorted(grouped.items()):
        parts = sorted(parts, key=lambda b: b.t)
        if (
            len(parts) == 5
            and [b.t for b in parts] == list(range(start, start + 300000, 60000))
            and start + 300000 <= now
        ):
            completed.append(
                {
                    "t": start,
                    "o": parts[0].o,
                    "c": parts[-1].c,
                    "h": max(b.h for b in parts),
                    "l": min(b.l for b in parts),
                    "v": sum((b.v for b in parts), Decimal(0)),
                }
            )
    out = {
        "bar_t": completed[-1]["t"] if completed else None,
        "bar_end": completed[-1]["t"] + 300000 if completed else None,
        "candidate": None,
        "trend": 0,
        "reason": "Прогрев: нужны 22 полные пятиминутные свечи",
        "features": None,
    }
    if len(completed) < 22:
        return out
    rows = completed[-22:]
    if any(b["t"] - a["t"] != 300000 for a, b in zip(rows, rows[1:], strict=False)):
        out["reason"] = "Неполная последовательность пятиминутных свечей"
        return out
    current, prior = rows[-1], rows[-2]
    fast = sum((b["c"] for b in rows[-9:]), Decimal(0)) / 9
    slow = sum((b["c"] for b in rows[-21:]), Decimal(0)) / 21
    previous_fast = sum((b["c"] for b in rows[-10:-1]), Decimal(0)) / 9
    previous_slow = sum((b["c"] for b in rows[-22:-1]), Decimal(0)) / 21
    changes = [b["c"] - a["c"] for a, b in zip(rows[-15:-1], rows[-14:], strict=True)]
    gains = sum((max(d, Decimal(0)) for d in changes), Decimal(0))
    losses = sum((max(-d, Decimal(0)) for d in changes), Decimal(0))
    rsi = 100 - 100 / (1 + gains / losses) if losses else Decimal(100) if gains else Decimal(50)
    ranges = [
        max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"]))
        for a, b in zip(rows[-15:-1], rows[-14:], strict=True)
    ]
    atr = sum(ranges, Decimal(0)) / 14 / current["c"] * 100
    volume = sum((b["v"] for b in rows[-11:-1]), Decimal(0)) / 10
    ratio = current["v"] / volume if volume else Decimal(0)
    trend = (
        1
        if fast > slow and current["c"] > slow
        else -1
        if fast < slow and current["c"] < slow
        else 0
    )
    out.update(
        trend=trend,
        features={
            "sma9": str(fast),
            "sma21": str(slow),
            "rsi14_cutler": str(rsi),
            "atr14_pct": str(atr),
            "volume_ratio": str(ratio),
            "close": str(current["c"]),
        },
    )
    if now - out["bar_end"] > 90000:
        out["reason"] = "Закрытая свеча устарела для нового входа"
        return out
    if not Decimal(".15") <= atr <= Decimal("2"):
        out["reason"] = "Волатильность вне рабочего диапазона 0,15–2%"
        return out
    if ratio < Decimal("1.1"):
        out["reason"] = "Объём ниже 1,1 среднего"
        return out
    upper = max(b["h"] for b in rows[-7:-1])
    lower = min(b["l"] for b in rows[-7:-1])
    side = 0
    rule = None
    if trend == 1 and slow >= previous_slow and 50 <= rsi <= 80 and current["c"] > current["o"]:
        if current["c"] > upper:
            side, rule = 1, "trend_breakout"
        elif prior["c"] <= previous_fast < current["c"] and current["c"] > fast:
            side, rule = 1, "trend_pullback"
    elif trend == -1 and slow <= previous_slow and 20 <= rsi <= 50 and current["c"] < current["o"]:
        if current["c"] < lower:
            side, rule = -1, "trend_breakout"
        elif prior["c"] >= previous_fast > current["c"] and current["c"] < fast:
            side, rule = -1, "trend_pullback"
    out["reason"] = "Нет подтверждённого пробоя/возврата по тренду"
    if side:
        out["candidate"] = {
            "id": f"technical:{current['t']}:{side}",
            "direction": side,
            "rule": rule,
            "bar_t": current["t"],
            "bar_end": out["bar_end"],
            "features": out["features"],
        }
        out["reason"] = (
            "Пробой по тренду" if rule == "trend_breakout" else "Возврат по тренду после отката"
        )
    return out
