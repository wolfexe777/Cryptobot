"""Loopback-only HTTP UI with origin, Host and per-instance token checks."""

import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from . import VERSION


def create_server(service, static, port=8767, token=None):
    token = token or secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            # No URL/body/token values in access logs.
            return

        def send(self, data, kind="application/json; charset=utf-8", code=200, filename=None):
            body = (
                json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
                if isinstance(data, (dict, list))
                else data
            )
            self.send_response(code)
            self.send_header("Content-Type", kind)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'",
            )
            if filename:
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.end_headers()
            try:
                self.wfile.write(body)
            except (ConnectionError, BrokenPipeError):
                pass

        def host_ok(self):
            return self.headers.get("Host") in (
                f"127.0.0.1:{self.server.server_port}",
                f"localhost:{self.server.server_port}",
            )

        def do_GET(self):
            if not self.host_ok():
                return self.send({"error": "Недопустимый Host"}, code=403)
            path = urlsplit(self.path).path
            if path == "/api/health":
                return self.send(
                    {
                        "application": "gate-sol-news",
                        "mode": "paper",
                        "real_orders": False,
                        "version": VERSION,
                    }
                )
            if path == "/api/status":
                return self.send({**service.status(), "control_token": token})
            if path == "/api/research.json":
                return self.send(
                    service.export_research(),
                    "application/json; charset=utf-8",
                    filename="SOL-paper-research.json",
                )
            if path == "/api/activity.csv":
                return self.send(
                    service.export_activity_csv(),
                    "text/csv; charset=utf-8",
                    filename="SOL-activity-windows.csv",
                )
            if path == "/api/export.csv":
                try:
                    archive_id = parse_qs(urlsplit(self.path).query).get("archive", [None])[0]
                    return self.send(
                        service.export_csv(archive_id),
                        "text/csv; charset=utf-8",
                        filename="SOL-news-trades.csv",
                    )
                except ValueError as exc:
                    return self.send({"error": str(exc)}, code=400)
            assets = {
                "/": ("index.html", "text/html; charset=utf-8"),
                "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                "/style.css": ("style.css", "text/css; charset=utf-8"),
            }
            if path in assets:
                name, mime = assets[path]
                return self.send((static / name).read_bytes(), mime)
            self.send({"error": "Страница не найдена"}, code=404)

        def do_POST(self):
            origin = self.headers.get("Origin")
            allowed = (
                f"http://127.0.0.1:{self.server.server_port}",
                f"http://localhost:{self.server.server_port}",
            )
            if not self.host_ok() or (origin is not None and origin not in allowed):
                return self.send(
                    {"error": "Запрос разрешён только из локального интерфейса"}, code=403
                )
            if not secrets.compare_digest(self.headers.get("X-Control-Token", ""), token):
                return self.send(
                    {"error": "Обновите страницу: токен управления не совпадает"}, code=403
                )
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 <= length <= 16384:
                    raise ValueError("Слишком большой запрос")
                data = json.loads(self.rfile.read(length)) if length else {}
                if not isinstance(data, dict):
                    raise ValueError("Ожидался объект JSON")
                path = urlsplit(self.path).path
                if path == "/api/start":
                    service.set_entries(True)
                elif path == "/api/pause":
                    service.set_entries(False)
                elif path == "/api/resume-legacy":
                    service.resume_legacy_pause()
                elif path == "/api/activity":
                    service.set_activity(data.get("profile"))
                elif path == "/api/reset":
                    service.reset(data.get("confirmation"))
                elif path == "/api/backtest":
                    raise ValueError(
                        "Новостной бэктест без исторического first_seen недостоверен; используйте новые PAPER-наблюдения"
                    )
                elif path == "/api/shutdown":
                    self.send({"ok": True})
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                    return
                else:
                    return self.send({"error": "Команда не найдена"}, code=404)
                self.send({"ok": True})
            except (ValueError, KeyError, TypeError, OSError) as exc:
                self.send({"error": str(exc)}, code=400)

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    return server, token
