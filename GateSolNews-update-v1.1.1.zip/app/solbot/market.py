"""Verified public SOL futures data. Every fill is a newly observed quote."""

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

BASE = "https://api.gateio.ws/api/v4/futures/usdt"
CONTRACT = "SOL_USDT"


class MarketError(RuntimeError):
    pass


def get(path, params=None):
    url = BASE + path + ("?" + urllib.parse.urlencode(params) if params else "")
    request = urllib.request.Request(
        url, headers={"Accept": "application/json", "User-Agent": "GateSolNews/1.1.1"}
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            if urllib.parse.urlsplit(response.url).hostname != "api.gateio.ws":
                raise MarketError("Неожиданный адрес Gate")
            data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise MarketError("Слишком большой ответ Gate")
        return json.loads(data, parse_float=Decimal)
    except (OSError, ValueError, urllib.error.HTTPError) as exc:
        raise MarketError("Нет публичных данных Gate: " + str(exc)) from exc


def number(value, positive=True, field="value"):
    expected = "> 0" if positive else ">= 0"
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise MarketError(
            f"Gate {field}={str(value)[:80]!r}: ожидается конечное число {expected}"
        ) from exc
    if not result.is_finite() or (result <= 0 if positive else result < 0):
        raise MarketError(f"Gate {field}={str(value)[:80]!r}: ожидается конечное число {expected}")
    return result


@dataclass(frozen=True)
class Candle:
    t: int
    o: Decimal
    h: Decimal
    l: Decimal
    c: Decimal
    v: Decimal

    def row(self):
        return [self.t, *[str(getattr(self, k)) for k in ("o", "h", "l", "c", "v")]]


def candles(since=None, limit=180):
    params = {"contract": CONTRACT, "interval": "1m"}
    if since is None:
        params["limit"] = limit
    else:
        params.update({"from": since // 1000, "to": since // 1000 + limit * 60 - 1})
    result = []
    for row in get("/candlesticks", params):
        t = int(row["t"]) * 1000
        values = [
            number(row[k], positive=k != "v", field=f"candlesticks[{t}].{k}")
            for k in ("o", "h", "l", "c", "v")
        ]
        o, h, l, c, v = values
        if t % 60000 or not l <= min(o, c) <= max(o, c) <= h:
            raise MarketError("Некорректная SOL свеча")
        result.append(Candle(t, *values))
    result.sort(key=lambda b: b.t)
    if any(b.t - a.t != 60000 for a, b in zip(result, result[1:], strict=False)):
        raise MarketError("Свечи SOL имеют пропуски/повторы")
    return result


def contract():
    raw = get("/contracts/" + CONTRACT)
    if raw.get("name") != CONTRACT or raw.get("in_delisting") or raw.get("type") != "direct":
        raise MarketError("Линейный SOL_USDT контракт Gate недоступен")
    decimal_enabled = raw.get("enable_decimal", False)
    if type(decimal_enabled) is not bool:
        raise MarketError("Gate contract.enable_decimal: ожидается true/false")
    reported_minimum = number(
        raw["order_size_min"], positive=not decimal_enabled, field="contract.order_size_min"
    )
    # Gate's legacy integer minimum can be zero when decimal sizing is enabled.
    # This PAPER adapter uses a conservative tenth-contract increment, not a
    # claim that Gate's exact smallest supported decimal increment is 0.1.
    step = Decimal("0.1") if decimal_enabled else Decimal(1)
    if reported_minimum and reported_minimum % step:
        step = min(step, Decimal(1).scaleb(reported_minimum.as_tuple().exponent))
    effective_minimum = (
        max(Decimal(1), (reported_minimum / step).to_integral_value(rounding="ROUND_CEILING"))
        * step
    )
    result = {
        "multiplier": str(number(raw["quanto_multiplier"], field="contract.quanto_multiplier")),
        "minimum": str(effective_minimum) if decimal_enabled else int(effective_minimum),
        "reported_minimum": str(reported_minimum),
        "decimal_enabled": decimal_enabled,
        "size_step": str(step),
        "size_step_source": "conservative_paper_increment"
        if decimal_enabled
        else "integer_contracts",
        "maintenance": str(number(raw["maintenance_rate"], field="contract.maintenance_rate")),
        "fee": str(number(raw["taker_fee_rate"], False, field="contract.taker_fee_rate")),
        "tick": str(number(raw["order_price_round"], field="contract.order_price_round")),
        "funding_interval": int(raw["funding_interval"]),
        "funding_offset": int(raw.get("funding_offset", 0)),
        "maximum": str(number(raw["order_size_max"], field="contract.order_size_max"))
        if decimal_enabled
        else int(
            number(raw["order_size_max"], field="contract.order_size_max").to_integral_value(
                rounding="ROUND_FLOOR"
            )
        ),
        "max_leverage": str(number(raw["leverage_max"], field="contract.leverage_max")),
    }
    if (
        not 60 <= result["funding_interval"] <= 86400
        or Decimal(result["fee"]) > Decimal(".02")
        or Decimal(result["maximum"]) < effective_minimum
    ):
        raise MarketError("Некорректные условия SOL контракта")
    return result


def quote():
    raw = get("/order_book", {"contract": CONTRACT, "limit": 5})
    observed = int(time.time() * 1000)
    bids = [
        number(r["p"], field=f"order_book.bids[{i}].p")
        for i, r in enumerate(raw["bids"])
        if number(r["s"], False, field=f"order_book.bids[{i}].s") > 0
    ]
    asks = [
        number(r["p"], field=f"order_book.asks[{i}].p")
        for i, r in enumerate(raw["asks"])
        if number(r["s"], False, field=f"order_book.asks[{i}].s") > 0
    ]
    if not bids or not asks or max(bids) > min(asks):
        raise MarketError("Пустой/перекрёстный стакан SOL")
    stamp = raw.get("current")
    if stamp is not None:
        stamp = float(stamp)
        stamp = stamp if stamp > 1e12 else stamp * 1000
        if not observed - 30000 <= stamp <= observed + 10000:
            raise MarketError("Устаревший/будущий стакан Gate")
    return {"t": observed, "bid": str(max(bids)), "ask": str(min(asks))}


def funding():
    rows = []
    for item in get("/funding_rate", {"contract": CONTRACT, "limit": 100}):
        rate = Decimal(str(item["r"]))
        t = int(item["t"]) * 1000
        if not rate.is_finite() or abs(rate) > Decimal(".1") or t % 60000:
            raise MarketError("Некорректный funding SOL")
        rows.append({"t": t, "rate": str(rate)})
    rows.sort(key=lambda r: r["t"])
    if len({r["t"] for r in rows}) != len(rows):
        raise MarketError("Повтор funding SOL")
    return rows


def packet():
    with ThreadPoolExecutor(max_workers=4) as pool:
        tasks = [
            (name, pool.submit(action))
            for name, action in (
                ("contract", contract),
                ("candles", candles),
                ("order_book", quote),
                ("funding", funding),
            )
        ]
        results = []
        for name, task in tasks:
            try:
                results.append(task.result())
            except Exception as exc:
                raise MarketError(f"Gate {name}: {exc}") from exc
        spec, bars, q, rates = results
    bars = [b for b in bars if b.t + 65000 <= q["t"]]
    if len(bars) < 25 or q["t"] - (bars[-1].t + 60000) > 150000:
        raise MarketError("Недостаточно свежих завершённых свечей SOL")
    return {"spec": spec, "bars": bars, "quote": q, "funding": rates}


def funding_prices(events, bars):
    mapping = {b.t: b.o for b in bars}
    if len(events) > 24:
        raise MarketError("Долгий перерыв с открытой позицией: требуется проверка funding")

    def fetch_price(event):
        if event["t"] in mapping:
            return event["t"], str(mapping[event["t"]])
        else:
            batch = candles(event["t"], 1)
            if len(batch) != 1 or batch[0].t != event["t"]:
                raise MarketError("Нет свечи для оценки funding")
            return event["t"], str(batch[0].o)

    with ThreadPoolExecutor(max_workers=4) as pool:
        return dict(pool.map(fetch_price, events))
