SOL ONLY 1.0.x / 1.1.0 -> 1.1.1. Do NOT overlay on ZEC.
Stop SOL with STOP.cmd, extract into the existing SOL folder replacing files, run CHECK.cmd, CHECK_NETWORK.cmd, START.cmd. Runtime and settings are preserved; the wallet is not reset.
Disables the PAPER daily loss cap and clears a saved daily_loss halt without resetting the wallet, history or position. The global loss stop and streak pause remain. Strategy conditions still apply. Decimal PAPER contracts are preserved. Research export contains local PAPER data, never control tokens.
CHECK_GATE_DETAIL.cmd collects public endpoint fields without account data or orders.
