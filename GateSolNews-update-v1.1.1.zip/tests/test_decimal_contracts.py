"""Regression for the public SOL response supplied during the 1.0.0 failure."""

# ruff: noqa: E402
import importlib.util
import json
import sys
import tempfile
import unittest
from decimal import Decimal as D
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from solbot import market
from solbot.broker import Broker, TradeConfig
from solbot.config import DEFAULT
from solbot.service import Service, management_plan

RAW = {
    "funding_offset": 0,
    "in_delisting": False,
    "order_price_round": "0.01",
    "order_size_min": 0,
    "enable_decimal": True,
    "name": "SOL_USDT",
    "maintenance_rate": "0.005",
    "funding_interval": 28800,
    "type": "direct",
    "order_size_max": 300000,
    "quanto_multiplier": "1",
    "leverage_max": "100",
    "maker_fee_rate": "-0.0001",
    "taker_fee_rate": "0.00075",
    "status": "trading",
}


def actual_spec():
    with patch("solbot.market.get", return_value=RAW):
        return market.contract()


def tick(t, p):
    return SimpleNamespace(t=t, o=p, h=p, l=p, c=p)


class DecimalContractsTests(unittest.TestCase):
    def broker(self, side=1):
        b = Broker(TradeConfig(**DEFAULT["trade"]), actual_spec())
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.pending = side
        b.process(tick(100000, D("84.12")), 0)
        return b

    def test_actual_zero_minimum_and_decimal_flag_are_accepted(self):
        s = actual_spec()
        self.assertTrue(s["decimal_enabled"])
        self.assertEqual(s["reported_minimum"], "0")
        self.assertEqual(s["multiplier"], "1")
        self.assertEqual(s["size_step"], "0.1")
        self.assertEqual(s["size_step_source"], "conservative_paper_increment")

    def test_hundred_usdt_five_x_can_open_fractional_long_and_short(self):
        for side in (1, -1):
            b = self.broker(side)
            p = b.position
            self.assertIsNotNone(p)
            self.assertEqual(p["contracts"], D(".2"))
            self.assertEqual(p["quantity"], D(".2"))
            self.assertLessEqual(p["margin"] + p["entry_fee"], D(5))
            self.assertEqual(p["contracts"] % D(".1"), 0)
            stop = b.price(p["protective_stop"], side == -1)
            loss = (
                -side * p["quantity"] * (stop - p["entry"])
                + p["entry_fee"]
                + stop * p["quantity"] * b.fee
            )
            self.assertLessEqual(loss, D(".25"))

    def test_fractional_position_survives_json_restart_and_close(self):
        b = self.broker()
        before = b.to_state()
        restored = Broker.restore(json.loads(json.dumps(before)))
        self.assertEqual(restored.position, b.position)
        self.assertEqual(restored.to_state(), before)
        row = restored.close(160000, D("84.3"), "fixture_exit")
        self.assertEqual(D(row["contracts"]), D(".2"))
        self.assertEqual(D(row["quantity"]), D(".2"))
        json.dumps(restored.to_state())

    def test_funding_and_pnl_use_fractional_sol_not_step_count(self):
        b = self.broker()
        p = b.position
        entry = p["entry"]
        q = p["quantity"]
        entry_fee = p["entry_fee"]
        rate = D(".000052")
        price = D("84.12")
        b.process(tick(160000, price), 0, str(rate))
        self.assertEqual(b.funding, q * price * rate)
        row = b.close(170000, price, "fixture_exit")
        expected = (
            p["side"] * q * (D(row["exit_price"]) - entry)
            - entry_fee
            - D(row["exit_price"]) * q * b.fee
            - b.funding
        )
        self.assertEqual(D(row["net_pnl"]), expected)

    def test_decimal_maximum_is_rounded_down_in_size_units(self):
        s = actual_spec()
        s["maximum"] = ".15"
        b = Broker(TradeConfig(**DEFAULT["trade"]), s)
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.open(100000, D("84.12"), 1)
        self.assertEqual(b.position["contracts"], D(".1"))

    def test_zero_minimum_without_decimal_flag_is_still_rejected(self):
        raw = dict(RAW, enable_decimal=False)
        with (
            patch("solbot.market.get", return_value=raw),
            self.assertRaises(market.MarketError) as error,
        ):
            market.contract()
        self.assertIn("order_size_min", str(error.exception))

    def test_positive_decimal_minimum_is_obeyed(self):
        raw = dict(RAW, order_size_min="0.25")
        with patch("solbot.market.get", return_value=raw):
            s = market.contract()
        b = Broker(TradeConfig(**DEFAULT["trade"]), s)
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.open(100000, D("84.12"), 1)
        self.assertGreaterEqual(b.position["contracts"], D(".25"))
        self.assertLessEqual(b.position["margin"] + b.position["entry_fee"], D(5))

    def test_too_small_wallet_budget_does_not_force_minimum(self):
        cfg = dict(DEFAULT["trade"], balance="1")
        b = Broker(TradeConfig(**cfg), actual_spec())
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.open(100000, D("84.12"), 1)
        self.assertIsNone(b.position)
        self.assertEqual(b.wallet, D(1))

    def test_network_preview_uses_actual_decimal_contract_metadata(self):
        spec = importlib.util.spec_from_file_location("_decimal_check", ROOT / "tools/check.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = module.contract_preview(
            {
                "spec": actual_spec(),
                "quote": {"t": 100000, "bid": "84.11", "ask": "84.13"},
                "bars": [],
            }
        )
        self.assertTrue(result["feasible"])
        self.assertEqual(D(result["long_contracts"]), D(".2"))
        self.assertEqual(D(result["long_quantity"]), D(".2"))

    def test_service_end_to_end_opens_and_stores_fractional_contract(self):
        import test_activity as fixtures

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            settings = root / "settings.json"
            settings.write_text(json.dumps(DEFAULT))
            s = Service(root / "data", settings)
            try:
                for minute in (1, 2):
                    bars = fixtures.candles(minute)
                    t = fixtures.BASE + minute * 60000 + 10000
                    packet = {
                        "spec": actual_spec(),
                        "bars": bars,
                        "quote": {"t": t, "bid": "84.11", "ask": "84.13"},
                        "funding": [],
                    }
                    # Keep the causal signal's price consistent with this quote.
                    from solbot import activity

                    signal = activity.evaluate(bars, t)
                    if signal["candidate"]:
                        signal["candidate"]["features"]["close"] = "84.12"
                    with (
                        patch("solbot.service.market.packet", return_value=packet),
                        patch("solbot.service.activity.evaluate", return_value=signal),
                        patch("solbot.service.time.time", return_value=t / 1000),
                    ):
                        s.tick()
                position = s.status()["position"]
                self.assertIsNotNone(position)
                self.assertEqual(D(position["contracts"]), D(".2"))
                session = s.state["session"]
                wallet = s.state["book"]["wallet"]
                s.close()
                s = Service(root / "data", settings)
                self.assertEqual(s.state["session"], session)
                self.assertEqual(s.state["book"]["wallet"], wallet)
                self.assertEqual(s.status()["position"], position)
            finally:
                s.close()
