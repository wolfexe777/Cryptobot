"""SOL-specific contract, sizing, news and namespace guards; synthetic data."""

# ruff: noqa: E402

import contextlib
import copy
import importlib.util
import io
import json
import sqlite3
import sys
import tempfile
import unittest
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from solbot import market, news
from solbot.broker import Broker, TradeConfig
from solbot.config import DEFAULT, validate
from solbot.service import Service, management_plan


def raw_contract():
    return {
        "name": "SOL_USDT",
        "type": "direct",
        "quanto_multiplier": ".1",
        "order_size_min": 1,
        "order_size_max": 100000,
        "maintenance_rate": ".005",
        "taker_fee_rate": ".0005",
        "order_price_round": ".001",
        "funding_interval": 14400,
        "funding_offset": 0,
        "leverage_max": "50",
    }


def spec():
    with patch("solbot.market.get", return_value=raw_contract()):
        return market.contract()


class SolContractTests(unittest.TestCase):
    def test_public_routes_all_bind_sol_contract(self):
        rows = [{"t": 60, "o": "150", "h": "151", "l": "149", "c": "150", "v": "10"}]

        def response(path, params=None):
            if path.startswith("/contracts/"):
                return raw_contract()
            if path == "/candlesticks":
                return rows
            if path == "/order_book":
                return {"bids": [{"p": "150", "s": 10}], "asks": [{"p": "150.01", "s": 10}]}
            return [{"t": 60, "r": ".0001"}]

        with patch("solbot.market.get", side_effect=response) as get:
            s = market.contract()
            market.candles()
            market.quote()
            market.funding()
        self.assertEqual(s["multiplier"], "0.1")
        self.assertEqual(s["tick"], "0.001")
        self.assertEqual(s["funding_interval"], 14400)
        for call in get.call_args_list:
            if call.args[0].startswith("/contracts/"):
                self.assertEqual(call.args[0], "/contracts/SOL_USDT")
            else:
                self.assertEqual(call.args[1]["contract"], "SOL_USDT")

    def test_wrong_delisting_and_insufficient_leverage_contracts_rejected(self):
        for change in (
            {"name": "ZEC_USDT"},
            {"in_delisting": True},
            {"leverage_max": "0"},
            {"order_size_min": 5, "order_size_max": 1},
        ):
            raw = raw_contract()
            raw.update(change)
            with (
                patch("solbot.market.get", return_value=raw),
                self.assertRaises(market.MarketError),
            ):
                market.contract()

    def test_dynamic_sol_lots_respect_margin_risk_and_ticks(self):
        for p in (50, 100, 200, 249):
            for side in (1, -1):
                b = Broker(TradeConfig(**DEFAULT["trade"]), spec())
                b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
                b.open(100000, D(p), side)
                position = b.position
                self.assertIsNotNone(position)
                self.assertEqual(position["quantity"], position["contracts"] * D(".1"))
                self.assertLessEqual(position["margin"] + position["entry_fee"], D(5))
                stop_fill = b.price(position["protective_stop"], side == -1)
                loss = (
                    -side * position["quantity"] * (stop_fill - position["entry"])
                    + position["entry_fee"]
                    + stop_fill * position["quantity"] * b.fee
                )
                self.assertLessEqual(loss, D(".25"))
                self.assertEqual(position["entry"] % D(".001"), 0)

    def test_leverage_cap_blocks_new_entry_without_hiding_market_data(self):
        raw = raw_contract()
        raw["leverage_max"] = "3"
        with patch("solbot.market.get", return_value=raw):
            s = market.contract()
        b = Broker(TradeConfig(**DEFAULT["trade"]), s)
        b.open(100000, D(100), 1)
        self.assertIsNone(b.position)
        self.assertIn("Плечо", b.last_entry_block)

    def test_minimum_contract_is_not_forced_above_budget(self):
        b = Broker(TradeConfig(**DEFAULT["trade"]), spec())
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.open(100000, D(1000), 1)
        self.assertIsNone(b.position)
        self.assertEqual(b.wallet, D(100))
        self.assertIn("Минимальный контракт", b.last_entry_block)

    def test_exchange_maximum_contract_count_is_enforced(self):
        s = spec()
        s["maximum"] = 1
        b = Broker(TradeConfig(**DEFAULT["trade"]), s)
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        b.open(100000, D(50), 1)
        self.assertEqual(b.position["contracts"], 1)

    def test_atr_stop_scales_with_costs_and_rejects_excessive_cost(self):
        m = DEFAULT["management"]
        low = management_plan(m, D(".02"), D(".00075"), D(".0002"))
        high = management_plan(m, D(".02"), D(".0015"), D(".001"))
        self.assertEqual(D(low["stop_fraction"]), D(".003"))
        self.assertGreater(D(high["stop_fraction"]), D(low["stop_fraction"]))
        self.assertEqual(
            D(management_plan(m, D(2), D(".00075"), D(".0002"))["stop_fraction"]), D(".015")
        )
        self.assertIsNone(management_plan(m, D(".2"), D(".02"), D(".02")))

    def test_cost_setting_validation_and_foreign_settings(self):
        for value in ("NaN", "0", "4"):
            cfg = copy.deepcopy(DEFAULT)
            cfg["management"]["cost_stop_multiple"] = value
            with self.assertRaises(ValueError):
                validate(cfg)
        cfg = copy.deepcopy(DEFAULT)
        cfg["contract"] = "ZEC_USDT"
        with self.assertRaises(ValueError):
            validate(cfg)

    def test_network_diagnostic_previews_sol_sizing_without_account(self):
        module_spec = importlib.util.spec_from_file_location(
            "_sol_check_profile", ROOT / "tools/check.py"
        )
        module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(module)
        preview = module.contract_preview(
            {"spec": spec(), "quote": {"t": 100000, "bid": "149.99", "ask": "150.01"}, "bars": []}
        )
        self.assertEqual(preview["contract"], "SOL_USDT")
        self.assertTrue(preview["feasible"])
        self.assertLessEqual(D(preview["long_margin"]), D(5))
        self.assertEqual(preview["preview_balance"], "100")


class SolNewsTests(unittest.TestCase):
    def test_sol_events_and_unrelated_assets(self):
        cases = {
            "SEC approves SOL ETF": 1,
            "SEC approves Solana spot ETF": 1,
            "Solana network halted": -1,
            "Solana Alpenglow activated": 1,
            "Coinbase lists SOL": 1,
            "Kraken delists SOL": -1,
            "Zcash network halted": 0,
            "SEC approves Zcash ETF": 0,
            "Solana devnet halted": 0,
            "Solana could get an ETF approval": 0,
            "Bitcoin network halted while Solana remains online": 0,
            "Solana-based memecoin hacked": 0,
        }
        for title, side in cases.items():
            with self.subTest(title=title):
                self.assertEqual(news.classify(title, "", "coindesk")["direction"], side)

    def test_official_mainnet_outage_has_direction(self):
        r = news.classify("Mainnet Beta - Network Outage", "", "solana_status")
        self.assertEqual(r["direction"], -1)
        self.assertEqual(r["event_key"], "security:sol")

    def test_status_resolution_rpc_and_devnet_do_not_authorize_trades(self):
        for title, summary in [
            ("Mainnet Beta - Network Outage", "Resolved - block production restored"),
            ("Devnet - Outage", ""),
            ("Mainnet Beta RPC API outage", ""),
            ("Explorer outage", ""),
            ("Zcash v3.0 activated", ""),
        ]:
            with self.subTest(title=title):
                self.assertEqual(news.classify(title, summary, "solana_status")["direction"], 0)

    def test_release_routes_are_not_news_signals(self):
        for source in ("agave_github", "firedancer_github"):
            host = news.SOURCES[source]["host"]
            path = news.SOURCES[source]["path_prefix"]
            xml = f'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Solana Alpenglow activated</title><link href="https://{host}{path}/tag/v1"/><published>2026-11-11T00:00:00Z</published></entry></feed>'.encode()
            row = news.parse_feed(xml, source, 1794355200000)[0]
            self.assertFalse(row["can_signal"])
            self.assertEqual(row["classification"]["direction"], 0)

    def test_official_mirrors_share_publisher(self):
        self.assertEqual(
            news.publisher_for("https://solana.com/news/a"),
            news.publisher_for("https://status.solana.com/incidents/a"),
        )
        self.assertEqual(len(news.SOURCES), 9)


class SolIsolationTests(unittest.TestCase):
    def test_new_sol_database_does_not_modify_zec_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"
            data.mkdir()
            settings = root / "settings.json"
            old = data / "zec-news.sqlite3"
            old.write_bytes(b"old ZEC history sentinel")
            settings.write_text(json.dumps(DEFAULT))
            service = Service(data, settings)
            try:
                self.assertEqual(service.state["config"]["contract"], "SOL_USDT")
                self.assertEqual(service.state["config"]["trade"]["balance"], "100")
                self.assertEqual(service.state["config"]["trade"]["leverage"], 5)
                self.assertTrue((data / "sol-news.sqlite3").is_file())
                self.assertEqual(old.read_bytes(), b"old ZEC history sentinel")
            finally:
                service.close()

    def test_foreign_ledger_is_rejected_without_archiving_or_relabeling(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            settings = root / "settings.json"
            settings.write_text(json.dumps(DEFAULT))
            service = Service(root / "data", settings)
            state = copy.deepcopy(service.state)
            state["config"]["contract"] = "ZEC_USDT"
            service.commit(state)
            service.close()
            with self.assertRaises(ValueError):
                Service(root / "data", settings)
            db = sqlite3.connect(root / "data/sol-news.sqlite3")
            try:
                body = json.loads(db.execute("SELECT body FROM snapshot").fetchone()[0])
                self.assertEqual(body["config"]["contract"], "ZEC_USDT")
                self.assertEqual(db.execute("SELECT COUNT(*) FROM archives").fetchone()[0], 0)
            finally:
                db.close()

    def test_changed_exchange_limits_do_not_disable_existing_exit(self):
        import test_activity as fixtures

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            settings = root / "settings.json"
            settings.write_text(json.dumps(DEFAULT))
            service = Service(root / "data", settings)
            current_spec = spec()

            def step(minute):
                bars = fixtures.candles(minute)
                stamp = fixtures.BASE + minute * 60000 + 10000
                p = bars[-1].c
                packet = {
                    "bars": bars,
                    "quote": {"t": stamp, "bid": str(p - D(".01")), "ask": str(p + D(".01"))},
                    "spec": current_spec,
                    "funding": [],
                }
                with (
                    patch("solbot.service.market.packet", return_value=packet),
                    patch("solbot.service.time.time", return_value=stamp / 1000),
                ):
                    service.tick()

            try:
                step(1)
                step(2)
                position = service.status()["position"]
                self.assertIsNotNone(position)
                current_spec.update(maximum=1, max_leverage="3")
                step(3)
                self.assertEqual(service.status()["position"]["contracts"], position["contracts"])
                step(14)
                self.assertIsNone(service.status()["position"])
                step(16)
                self.assertIsNone(service.status()["position"])
                self.assertIn("Плечо", service.state["message"])
            finally:
                service.close()

    def test_sol_stop_refuses_foreign_application(self):
        s = importlib.util.spec_from_file_location("_sol_main_guard", ROOT / "app/main.py")
        module = importlib.util.module_from_spec(s)
        s.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "control.json").write_text(
                json.dumps({"url": "http://127.0.0.1:8766", "token": "fixture"})
            )
            from unittest.mock import MagicMock

            response = MagicMock()
            response.__enter__.return_value.read.return_value = b'{"application":"gate-zec-news"}'
            with (
                patch("urllib.request.urlopen", return_value=response) as get,
                contextlib.redirect_stdout(io.StringIO()),
            ):
                self.assertEqual(module.run(["--stop", "--data-dir", str(root)]), 1)
            self.assertEqual(get.call_count, 1)
