@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 tools\autostart.py enable
pause
