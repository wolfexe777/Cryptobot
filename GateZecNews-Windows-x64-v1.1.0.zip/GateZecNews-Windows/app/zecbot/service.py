"""Persistent news-aware quote PAPER execution. No backdated news orders."""

import copy
import csv
import io
import json
import logging
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from decimal import Decimal, localcontext
from types import SimpleNamespace

from . import market, news
from .broker import Broker, TradeConfig
from .config import digest, read, upgrade_sources

LOGGER = logging.getLogger("zecbot")


def restore_book(state):
    if not state.get("book"):
        return None
    book = Broker.restore(state["book"])
    book.slip = Decimal(state.get("execution_slippage", book.config.slippage))
    book.fee = Decimal(state.get("execution_fee", book.config.fee))
    return book


def price_confirmation(arm, bars, quote, settings):
    now = quote["t"]
    if now > arm["expires"]:
        return False, "Срок реакции на новость истёк"
    eligible = [b for b in bars if b.t >= arm["anchor_t"] and b.t + 60000 <= now]
    if not eligible:
        return False, "Ожидаем завершённую минуту после получения новости"
    bar = eligible[-1]
    prior = [b for b in bars if b.t < bar.t][-20:]
    if len(prior) < 20:
        return False, "Не хватает данных для подтверждения"
    side = arm["event"]["direction"]
    mid = (Decimal(quote["bid"]) + Decimal(quote["ask"])) / 2
    move = side * (mid / Decimal(arm["anchor_price"]) - 1) * 100
    if move < Decimal(settings["min_move_pct"]):
        return False, "Цена ещё не подтвердила направление новости"
    if move > Decimal(settings["max_move_pct"]):
        return False, "Цена уже прошла слишком далеко после сигнала"
    old = sum((b.v for b in prior), Decimal(0)) / 20
    mean = sum((b.c for b in prior), Decimal(0)) / 20
    if old <= 0 or bar.v < old * Decimal(settings["volume_ratio"]):
        return False, "Нет подтверждения объёмом"
    if side * (bar.c - bar.o) <= 0 or side * (bar.c - mean) <= 0:
        return False, "Свеча/средняя цена не подтверждают направление"
    return True, "Новость и последующая реакция цены подтверждены"


class Service:
    def __init__(self, directory, settings):
        self.directory, self.settings = directory, settings
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.shutdown = threading.Event()
        self.threads = []
        self.db = sqlite3.connect(
            directory / "zec-news.sqlite3", check_same_thread=False, isolation_level=None
        )
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
CREATE TABLE IF NOT EXISTS snapshot(id INTEGER PRIMARY KEY,body TEXT NOT NULL,revision INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS articles(id TEXT PRIMARY KEY,seen INTEGER NOT NULL,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS trades(session TEXT,entry_t INTEGER,exit_t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,entry_t,exit_t));
CREATE TABLE IF NOT EXISTS quotes(session TEXT,t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,t));
CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY,t INTEGER,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS archives(id INTEGER PRIMARY KEY,body TEXT NOT NULL);
""")
        row = self.db.execute("SELECT body,revision FROM snapshot WHERE id=1").fetchone()
        self.state, self.revision = (
            (json.loads(row[0]), row[1]) if row else (self.new_state(read(settings)), 0)
        )
        if self.state.get("version") != 1 or self.state["config"]["contract"] != "ZEC_USDT":
            raise ValueError("Неизвестная база ZEC; данные не сброшены")
        if not row:
            self.commit(self.state)
        elif self.state.get("arm") or upgrade_sources(self.state["config"]) != self.state["config"]:
            state = copy.deepcopy(self.state)
            state["arm"] = None
            state["config"] = upgrade_sources(state["config"])
            state["config_sha256"] = digest(state["config"])
            self.commit(state)
        self.market_error = None
        self.last_market_attempt = None

    @staticmethod
    def new_state(config):
        return {
            "version": 1,
            "session": uuid.uuid4().hex,
            "config": config,
            "config_sha256": digest(config),
            "entries_enabled": config["auto_start"],
            "started_at": int(time.time() * 1000),
            "book": None,
            "spec": None,
            "quote": None,
            "funding_cursor": None,
            "arm": None,
            "consumed": {},
            "message": "Ожидаем новости и котировки ZEC",
        }

    def commit(self, state, trades=(), quote=None, decisions=(), archive=False):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            old = self.db.execute("SELECT revision FROM snapshot WHERE id=1").fetchone()
            if (old[0] if old else 0) != self.revision:
                raise ValueError("База изменилась другим процессом")
            if archive:
                self.db.execute("INSERT INTO archives(body) VALUES(?)", (json.dumps(self.state),))
            for row in trades:
                self.db.execute(
                    "INSERT INTO trades VALUES(?,?,?,?)",
                    (
                        state["session"],
                        row["entry_time"],
                        row["exit_time"],
                        json.dumps(row, ensure_ascii=False),
                    ),
                )
            if quote:
                self.db.execute(
                    "INSERT INTO quotes VALUES(?,?,?)",
                    (state["session"], quote["t"], json.dumps(quote)),
                )
            for row in decisions:
                self.db.execute(
                    "INSERT INTO decisions(t,body) VALUES(?,?)",
                    (row["t"], json.dumps(row, ensure_ascii=False)),
                )
            revision = self.revision + 1
            self.db.execute(
                "INSERT OR REPLACE INTO snapshot VALUES(1,?,?)",
                (json.dumps(state, ensure_ascii=False, allow_nan=False), revision),
            )
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
        self.state, self.revision = state, revision

    def poll_news(self):
        with self.lock:
            enabled = list(self.state["config"]["sources"])
            timeout = self.state["config"].get("news_timeout_seconds", 20)

        def fetch(source):
            start = time.monotonic()
            try:
                observed, rows = news.fetch(source, timeout=timeout)
                return source, observed, rows, None, int((time.monotonic() - start) * 1000)
            except Exception as exc:
                return (
                    source,
                    int(time.time() * 1000),
                    [],
                    str(exc),
                    int((time.monotonic() - start) * 1000),
                )

        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = [pool.submit(fetch, source) for source in enabled]
            for future in as_completed(futures):
                self.store_news_updates([future.result()])

    def store_news_updates(self, updates):
        with self.lock:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                for source, observed, rows, error, elapsed_ms in updates:
                    old = self.db.execute(
                        "SELECT body FROM sources WHERE id=?", (source,)
                    ).fetchone()
                    status = json.loads(old[0]) if old else {"initialized": False, "last_ok": None}
                    status.update(
                        last_attempt=observed, error=error, count=len(rows), elapsed_ms=elapsed_ms
                    )
                    if error is None:
                        for row in rows:
                            row["baseline"] = not status["initialized"]
                            previous = self.db.execute(
                                "SELECT body FROM articles WHERE id=?", (row["id"],)
                            ).fetchone()
                            if previous:
                                previous = json.loads(previous[0])
                                if previous["classification"] != row["classification"]:
                                    previous["updated_at"] = observed
                                    previous["title"] = row["title"]
                                    previous["invalidated_event"] = previous.get(
                                        "invalidated_event"
                                    ) or previous["classification"].get("event_key")
                                    previous["classification"] = {
                                        "direction": 0,
                                        "event_key": None,
                                        "reason": "Смысл публикации изменился: прежний сигнал отозван",
                                    }
                                    self.db.execute(
                                        "UPDATE articles SET body=? WHERE id=?",
                                        (json.dumps(previous, ensure_ascii=False), row["id"]),
                                    )
                                continue
                            self.db.execute(
                                "INSERT OR IGNORE INTO articles VALUES(?,?,?)",
                                (row["id"], row["first_seen"], json.dumps(row, ensure_ascii=False)),
                            )
                        status.update(initialized=True, last_ok=observed)
                    self.db.execute(
                        "INSERT OR REPLACE INTO sources VALUES(?,?)",
                        (source, json.dumps(status, ensure_ascii=False)),
                    )
                self.db.execute("COMMIT")
            except BaseException:
                self.db.execute("ROLLBACK")
                raise

    def news_snapshot(self):
        articles = [
            json.loads(r[0])
            for r in self.db.execute("SELECT body FROM articles ORDER BY seen DESC LIMIT 1000")
        ]
        health = {r[0]: json.loads(r[1]) for r in self.db.execute("SELECT id,body FROM sources")}
        return articles, health

    def tick(self):
        with self.lock:
            state = copy.deepcopy(self.state)
            revision = self.revision
        packet = market.packet()
        quote = packet["quote"]
        spec = packet["spec"]
        bars = packet["bars"]
        now = quote["t"]
        if state["quote"] and now <= state["quote"]["t"]:
            return
        cfg = TradeConfig(**state["config"]["trade"])
        book = restore_book(state) or Broker(cfg, spec)
        if state["spec"] and any(state["spec"][k] != spec[k] for k in spec if k != "fee"):
            raise market.MarketError("Изменились параметры ZEC контракта; счёт сохранён")
        cursor = state["funding_cursor"]
        due = []
        expected = []
        if book.position and cursor is not None:
            step = spec["funding_interval"] * 1000
            offset = spec["funding_offset"] * 1000
            first = ((cursor - offset) // step + 1) * step + offset
            mapping = {r["t"]: r for r in packet["funding"]}
            expected = [t for t in range(first, now + 1, step) if t > book.position["time"]]
            if any(t not in mapping for t in expected):
                raise market.MarketError(
                    "Ожидаем опубликованный funding: финансовый результат не выдумывается"
                )
            due = [mapping[t] for t in expected]
        settlement = market.funding_prices(due, bars)
        # Slow historical requests must never turn a stale quote into an entry.
        if int(time.time() * 1000) - quote["t"] > 2000:
            fresh = market.quote()
            if fresh["t"] <= quote["t"]:
                raise market.MarketError("Нет новой котировки после загрузки истории")
            if book.position and cursor is not None:
                latest = [
                    t for t in range(first, fresh["t"] + 1, step) if t > book.position["time"]
                ]
                if latest != expected:
                    raise market.MarketError(
                        "Новый период funding: ожидаем следующую полную загрузку"
                    )
            quote = fresh
            now = quote["t"]
        with self.lock:
            if self.revision != revision or self.shutdown.is_set():
                return
            articles, health = self.news_snapshot()
            settings = state["config"]["news"]
            events = news.confirmed_events(articles, health, now, settings)
            events = [
                e
                for e in events
                if e["first_seen"] >= state["started_at"]
                and now - e["first_seen"] <= settings["signal_ttl_minutes"] * 60000
            ]
            bid, ask = Decimal(quote["bid"]), Decimal(quote["ask"])
            mid = (bid + ask) / 2
            spread = (ask - bid) / mid * 100
            book.fee = max(Decimal(cfg.fee), Decimal(spec["fee"]))
            book.slip = Decimal(cfg.slippage) + (ask - bid) / (ask + bid)
            state["consumed"] = {k: v for k, v in state["consumed"].items() if v > now}
            records = []
            decisions = []
            with localcontext() as context:
                context.prec = 40
                for event in due:
                    p = book.position
                    cost = (
                        p["side"]
                        * p["quantity"]
                        * Decimal(settlement[event["t"]])
                        * Decimal(event["rate"])
                    )
                    book.wallet -= cost
                    book.funding += cost
                    p["funding"] += cost
                # Confirmed contrary news can reduce an existing exposure. An
                # opposite new position still needs its own later price reaction.
                retracted = any(
                    a.get("invalidated_event")
                    and book.position
                    and book.position.get("news_event")
                    and a["id"] in book.position["news_event"]["article_ids"]
                    for a in articles
                )
                if retracted:
                    tag = book.position.get("news_event")
                    row = book.close(now, mid, "news_retraction")
                    row.update(entry_news=tag, exit_news=None)
                    records.append(row)
                    decisions.append({"t": now, "kind": "news_retraction", "event": tag})
                opposing = next(
                    (
                        e
                        for e in events
                        if book.position and e["direction"] != book.position["side"]
                    ),
                    None,
                )
                if opposing:
                    tag = book.position.get("news_event")
                    row = book.close(now, mid, "news_reversal")
                    row.update(entry_news=tag, exit_news=opposing)
                    records.append(row)
                    decisions.append({"t": now, "kind": "news_reversal", "event": opposing})
                available = [
                    e
                    for e in events
                    if state["consumed"].get(e["id"] + ":" + str(e["direction"]), 0) <= now
                ]
                mixed = len({e["direction"] for e in events}) > 1
                if mixed:
                    available = []
                if state["arm"] and not any(
                    e["id"] == state["arm"]["event"]["id"]
                    and e["direction"] == state["arm"]["event"]["direction"]
                    for e in available
                ):
                    state["arm"] = None
                if state["arm"] and now > state["arm"]["expires"]:
                    state["arm"] = None
                if (
                    state["entries_enabled"]
                    and not book.position
                    and not state["arm"]
                    and available
                ):
                    event = available[0]
                    # A large move since publication is not a fresh opportunity.
                    reference = next(
                        (b.o for b in bars if b.t <= event["published_at"] < b.t + 60000), None
                    )
                    if reference is not None and abs(mid / reference - 1) * 100 <= Decimal(
                        settings["max_move_pct"]
                    ):
                        state["arm"] = {
                            "event": event,
                            "anchor_t": now,
                            "anchor_price": str(mid),
                            "expires": event["first_seen"] + settings["signal_ttl_minutes"] * 60000,
                        }
                        decisions.append(
                            {"t": now, "kind": "armed", "event": event, "anchor_price": str(mid)}
                        )
                signal = 0
                message = "Ожидаем свежее подтверждённое событие Zcash"
                if mixed:
                    message = "Противоречивые новости: новые входы запрещены"
                if state["arm"]:
                    okay, message = price_confirmation(state["arm"], bars, quote, settings)
                    if spread > Decimal(settings["max_spread_pct"]):
                        okay = False
                        message = "Спред ZEC слишком широк для нового входа"
                    if okay and state["entries_enabled"]:
                        signal = state["arm"]["event"]["direction"]
                tag = (
                    book.position.get("news_event")
                    if book.position
                    else (state["arm"]["event"] if signal and state["arm"] else None)
                )
                # Signal and all evidence predate this observed quote. Fills use
                # bid/ask plus adverse slippage at now, never a past candle open.
                book.pending = signal
                tick = SimpleNamespace(t=now, o=mid, h=mid, l=mid, c=mid)
                for row in book.process(tick, 0, "0"):
                    row["entry_news"] = tag
                    records.append(row)
                opened = (book.position and book.position["time"] == now) or any(
                    r["entry_time"] == now for r in records
                )
                if opened and state["arm"]:
                    event = state["arm"]["event"]
                    if book.position:
                        book.position["news_event"] = event
                    state["consumed"][event["id"] + ":" + str(event["direction"])] = now + 86400000
                    decisions.append({"t": now, "kind": "opened", "event": event, "quote": quote})
                    state["arm"] = None
                if not state["entries_enabled"]:
                    message = "Новые входы выключены; новости и защита открытой позиции работают"
                if book.metrics().get("risk_status") not in (None, "active"):
                    message = "Сработало ограничение риска: " + book.metrics()["risk_status"]
                book.curve = book.curve[-600:]
                book.history = book.history[-200:]
                state.update(
                    book=book.to_state(),
                    spec=spec,
                    quote=quote,
                    funding_cursor=now,
                    execution_fee=str(book.fee),
                    execution_slippage=str(book.slip),
                    message=message,
                )
                self.commit(state, records, quote, decisions)
                self.market_error = None
                self.last_market_attempt = int(time.time() * 1000)

    def start_workers(self):
        def loop(action, interval, kind):
            while not self.shutdown.is_set():
                start = time.monotonic()
                try:
                    action()
                except Exception as exc:
                    LOGGER.exception("%s poll failed", kind)
                    if kind == "market":
                        with self.lock:
                            self.market_error = str(exc)
                            self.last_market_attempt = int(time.time() * 1000)
                self.shutdown.wait(max(0, interval - (time.monotonic() - start)))

        for action, period, kind in (
            (self.poll_news, self.state["config"]["news_poll_seconds"], "news"),
            (self.tick, self.state["config"]["market_poll_seconds"], "market"),
        ):
            thread = threading.Thread(target=loop, args=(action, period, kind), daemon=True)
            self.threads.append(thread)
            thread.start()

    def status(self):
        with self.lock:
            book = restore_book(self.state)
            articles, health = self.news_snapshot()
            try:
                changed = digest(read(self.settings)) != self.state["config_sha256"]
            except Exception:
                changed = True
            return {
                "application": "gate-zec-news",
                "mode": "paper",
                "real_orders": False,
                "entries_enabled": self.state["entries_enabled"],
                "session": self.state["session"],
                "quote": self.state["quote"],
                "spec": self.state["spec"],
                "execution_fee": self.state.get("execution_fee"),
                "execution_slippage": self.state.get("execution_slippage"),
                "config": self.state["config"],
                "summary": book.metrics() if book else None,
                "position": book.to_state()["position"] if book else None,
                "history": [
                    json.loads(r[0])
                    for r in self.db.execute(
                        "SELECT body FROM trades WHERE session=? ORDER BY exit_t DESC LIMIT 100",
                        (self.state["session"],),
                    )
                ],
                "news": articles[:150],
                "sources": {
                    s: {**news.SOURCES[s], **health.get(s, {})}
                    for s in self.state["config"]["sources"]
                },
                "news_health": news.readiness(
                    health, int(time.time() * 1000), self.state["config"]["sources"]
                ),
                "decisions": [
                    json.loads(r[0])
                    for r in self.db.execute(
                        "SELECT body FROM decisions ORDER BY id DESC LIMIT 100"
                    )
                ],
                "arm": self.state["arm"],
                "message": self.state["message"],
                "error": self.market_error,
                "settings_changed": changed,
                "last_market_attempt": self.last_market_attempt,
                "data_directory": str(self.directory),
                "news_rules": "headline heuristics; not a fact checker",
                "funding_model": "Published rate × trade candle open at settlement, a mark-price approximation",
            }

    def set_entries(self, value):
        if type(value) is not bool:
            raise ValueError("Некорректный режим")
        with self.lock:
            state = copy.deepcopy(self.state)
            state["entries_enabled"] = value
            state["arm"] = None
            self.commit(state)

    def reset(self, confirmation):
        with self.lock:
            book = restore_book(self.state)
            if self.state["entries_enabled"] or (book and book.position):
                raise ValueError("Выключите входы; дождитесь закрытия открытой позиции")
            if confirmation != "ARCHIVE_ZEC_PAPER":
                raise ValueError("Требуется явная архивация счёта")
            state = self.new_state(read(self.settings))
            state["entries_enabled"] = False
            self.commit(state, archive=True)

    def export_csv(self):
        with self.lock:
            rows = [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT body FROM trades WHERE session=? ORDER BY exit_t",
                    (self.state["session"],),
                )
            ]
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        fields = [
            "entry_time",
            "exit_time",
            "side",
            "quantity",
            "entry_price",
            "exit_price",
            "net_pnl",
            "fees",
            "funding",
            "reason",
        ]
        writer.writerow([*fields, "entry_news_json", "exit_news_json"])
        for row in rows:
            writer.writerow(
                [
                    *[row[k] for k in fields],
                    json.dumps(row.get("entry_news"), ensure_ascii=False),
                    json.dumps(row.get("exit_news"), ensure_ascii=False),
                ]
            )
        return out.getvalue().encode("utf-8-sig")

    def close(self):
        self.shutdown.set()
        for thread in self.threads:
            thread.join(timeout=15)
        if not any(t.is_alive() for t in self.threads):
            with self.lock:
                self.db.close()
