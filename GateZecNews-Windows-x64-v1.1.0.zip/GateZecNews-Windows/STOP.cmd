@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 app\main.py --stop
if errorlevel 1 pause
