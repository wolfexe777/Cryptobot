# Gate SOL News: источники и лицензии

Основа — собственная GPL-3.0 реализация Gate ZEC News 1.4.1 из этого
репозитория. Финансовый PAPER broker и блокировка процесса происходят из
GatePaper. SOL-адаптация, привязка контракта и новостей, фильтр затрат,
изоляция данных и диагностика реализованы в этой сборке. LICENSE.txt — GPL-3.0.

Gate Futures USDT API: https://www.gate.com/docs/developers/apiv4/en/
Используются публичные `/contracts/SOL_USDT`, `/candlesticks`, `/order_book`
и `/funding_rate` на `https://api.gateio.ws/api/v4/futures/usdt`.
Закрытых API, реальных заявок и API-ключей нет. Условия контракта читаются
во время работы; тестовые примеры не являются настоящей спецификацией Gate.

Новостные адреса:

- https://status.solana.com/history.atom
- https://news.google.com/rss/search?q=Solana+OR+SOL+when:1d&hl=en-US&gl=US&ceid=US:en
- https://www.bing.com/news/search?q=Solana&format=rss&setlang=en-US&mkt=en-US
- https://decrypt.co/feed
- https://www.theblock.co/rss.xml
- https://www.coindesk.com/arc/outboundfeeds/rss/
- https://cointelegraph.com/rss
- https://github.com/anza-xyz/agave/releases.atom
- https://github.com/firedancer-io/firedancer/releases.atom

Адреса проверяются CHECK_NETWORK.cmd на ПК. Их доступность из Windows
не заявляется без такой проверки. Релизы клиентов не дают торговых сигналов.
Официальный источник и издатели агрегаторов проверяются по HTTPS allowlist;
агрегатор не получает независимого голоса. Материалы издателей и наборы
реальных новостей не включены в ZIP: фикстуры в tests синтетические.

Windows runtime: Astral python-build-standalone, CPython 3.13.18 x64,
release 20261026. Точная ссылка и SHA256 в runtime-lock.json; лицензии
runtime сохранены. Нативный Windows здесь не исполнялся.


SOL 1.0.1 поддерживает enable_decimal=true с нулевым старым integer-minimum.
Публичный контрактный JSON предоставлен пользователем для воспроизведения
ошибки; в tests воспроизведены только публичные параметры SOL, не кошелёк.
PAPER-округление 0,1 контракта при таком ответе — консервативная политика
симулятора, не заявление точного минимального шага реальной заявки.


SOL 1.1.0: собственная причинная политика SMA5/15/30, нормирование
на один ATR импульса, окно входов и предварительное ограничение размера
остатком денежных бюджетов. Параметры являются гипотезой для PAPER. Никакие
пользовательские торговые CSV и индивидуальные финансовые результаты в
дистрибутив не включены; бэктест новой доходности по ним не заявляется.
