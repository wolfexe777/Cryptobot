"""Synthetic frequency/causality checks; not real SOL performance."""

import copy
import json
import sys
import tempfile
import unittest
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from solbot import activity, market
from solbot.config import DEFAULT, validate
from solbot.service import Service
from test_hybrid import SPEC, START

BASE = START // 900000 * 900000


def price(i, side=1):
    p = D(100) + D(".08") * i + (D(".10") if i % 2 else -D(".10"))
    return p if side == 1 else 200 - p


def candles(end, side=1):
    out = []
    for i in range(end - 60, end):
        o, c = price(i - 1, side), price(i, side)
        out.append(
            market.Candle(BASE + i * 60000, o, max(o, c) + D(".12"), min(o, c) - D(".12"), c, D(10))
        )
    return out


class SignalTests(unittest.TestCase):
    def test_both_directions_have_active_signals(self):
        for side in (1, -1):
            r = activity.evaluate(candles(2, side), BASE + 2 * 60000 + 10000)
            self.assertEqual(r["candidate"]["direction"], side)
            self.assertEqual(r["candidate"]["rule"], "confirmed_trend")

    def test_future_bars_do_not_affect_signal(self):
        bars = candles(2)
        now = BASE + 2 * 60000 + 10000
        expected = activity.evaluate(bars, now)
        self.assertEqual(activity.evaluate(bars + candles(100), now), expected)

    def test_gap_duplicate_incomplete_stale_and_flat_block(self):
        now = BASE + 2 * 60000 + 10000
        bars = candles(2)
        cases = [bars[-10:], bars[:-5] + bars[-4:], bars + [bars[-1]]]
        flat = [market.Candle(b.t, D(100), D(100), D(100), D(100), D(10)) for b in bars]
        cases.append(flat)
        for case in cases:
            self.assertIsNone(activity.evaluate(case, now)["candidate"])
        self.assertIsNone(activity.evaluate(bars, now + 180000)["candidate"])

    def test_fixed_requested_cadence_and_malformed_settings(self):
        cfg = validate(copy.deepcopy(DEFAULT))
        self.assertEqual(cfg["trade"]["max_hold"], 12)
        self.assertEqual(cfg["trade"]["cooldown"], 0)
        self.assertEqual(cfg["trade"]["daily_entries"], 0)
        for key, value in [
            ("profile", "live"),
            ("entry_interval_minutes", 1),
            ("entry_interval_minutes", True),
            ("max_hold_minutes", 15),
            ("target_closed_per_hour", 100),
        ]:
            bad = copy.deepcopy(DEFAULT)
            bad["activity"][key] = value
            with self.assertRaises(ValueError):
                validate(bad)
        bad = copy.deepcopy(DEFAULT)
        bad["activity"] = []
        with self.assertRaises(ValueError):
            validate(bad)


class ActiveExecutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.settings = self.root / "settings.json"
        self.cfg = copy.deepcopy(DEFAULT)
        self.cfg["sources"] = ["solana_status"]
        self.settings.write_text(json.dumps(self.cfg))
        self.minute = 1
        self.wide = False
        self.spec = dict(SPEC, funding_interval=86400)
        self.packet_patch = patch("solbot.service.market.packet", side_effect=self.packet)
        self.clock_patch = patch("solbot.service.time.time", side_effect=lambda: self.now() / 1000)
        self.packet_patch.start()
        self.clock_patch.start()
        self.service = Service(self.root / "data", self.settings)
        self.service.store_news_updates([("solana_status", self.now(), [], "fixture offline", 0)])

    def now(self):
        return BASE + self.minute * 60000 + 10000

    def packet(self):
        bars = candles(self.minute)
        p = bars[-1].c
        spread = D(1) if self.wide else D(".01")
        return {
            "bars": bars,
            "quote": {"t": self.now(), "bid": str(p - spread), "ask": str(p + spread)},
            "spec": self.spec,
            "funding": [],
        }

    def tearDown(self):
        self.service.close()
        self.clock_patch.stop()
        self.packet_patch.stop()
        self.tmp.cleanup()

    def step(self, minute):
        self.minute = minute
        self.service.tick()

    def open(self):
        self.step(1)  # initial snapshot must not open
        self.assertIsNone(self.service.status()["position"])
        self.step(2)
        self.assertIsNotNone(self.service.status()["position"])

    def test_steady_trend_can_close_four_trades_in_rolling_hour(self):
        for minute in range(1, 66):
            self.step(minute)
        s = self.service.status()
        self.assertEqual(s["activity"]["closed_last_hour"], 4)
        self.assertTrue(s["activity"]["target_met"])
        self.assertFalse(s["activity"]["frequency_guaranteed"])
        entries = [
            json.loads(r[0])["entry_time"]
            for r in self.service.db.execute("SELECT body FROM trades")
        ]
        if s["position"]:
            entries.append(s["position"]["time"])
        self.assertEqual(len({t // 900000 for t in entries}), len(entries))
        self.assertGreater(D(s["summary"]["fees"]), 0)
        self.assertEqual(s["config"]["trade"]["balance"], "100")
        self.assertEqual(s["config"]["trade"]["leverage"], 5)

    def test_no_second_entry_in_same_quarter_after_close_or_restart(self):
        self.open()
        state = copy.deepcopy(self.service.state)
        from solbot.service import restore_book

        book = restore_book(state)
        record = book.close(self.now() + 1, book.last_price, "fixture_exit")
        state["book"] = book.to_state()
        self.service.commit(state, [record])
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        for minute in (4, 6, 8, 10):
            self.step(minute)
            self.assertIsNone(self.service.status()["position"])
        self.assertIn("15-минутной", self.service.status()["message"])
        self.step(16)
        self.assertIsNotNone(self.service.status()["position"])

    def test_time_limit_closes_without_waiting_two_hours(self):
        self.open()
        self.step(14)
        rows = self.service.status()["history"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["exit_time"] - rows[0]["entry_time"], 12 * 60000)

    def test_wide_spread_blocks_and_reports_reason(self):
        self.step(1)
        self.wide = True
        self.step(2)
        self.assertIsNone(self.service.status()["position"])
        self.assertIn("Спред", self.service.status()["activity"]["message"])

    def test_confirmed_contrary_news_blocks_active_entry(self):
        from test_sol import article

        self.step(1)
        self.service.store_news_updates([("solana_status", self.now(), [], None, 0)])
        self.minute = 2
        row = article("Solana network halted", stamp=self.now() - 30000, seen=self.now() - 1000)
        self.service.store_news_updates([("solana_status", self.now() - 1000, [row], None, 0)])
        self.service.tick()
        s = self.service.status()
        self.assertIsNone(s["position"])
        self.assertTrue(s["news_context"])
        self.assertIn("новостным", s["message"])

    def test_cost_filter_blocks_small_move_without_forced_entry(self):
        self.step(1)
        self.minute = 2
        signal = activity.evaluate(candles(2), self.now())
        signal["features"]["range_15m_pct"] = "0.05"
        with patch("solbot.service.activity.evaluate", return_value=signal):
            self.service.tick()
        s = self.service.status()
        self.assertIsNone(s["position"])
        self.assertTrue(any(d["kind"] == "active_blocked_costs" for d in s["decisions"]))
        self.assertIn("затрат", s["message"])

    def test_pause_not_overridden_by_frequency_target(self):
        self.step(1)
        self.service.set_entries(False)
        for minute in (2, 16, 32, 46):
            self.step(minute)
        s = self.service.status()
        self.assertIsNone(s["position"])
        self.assertEqual(s["activity"]["closed_last_hour"], 0)
        self.assertIn("выключены", s["activity"]["message"])

    def test_total_loss_halt_is_never_reset_to_hit_frequency(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["total_halt"] = True
        self.service.commit(state)
        for minute in (2, 16, 32, 46):
            self.step(minute)
        s = self.service.status()
        self.assertIsNone(s["position"])
        self.assertEqual(s["summary"]["risk_status"], "total_stop")
        self.assertFalse(s["activity"]["target_met"])

    def test_profile_switch_keeps_wallet_losses_and_position(self):
        self.open()
        before = copy.deepcopy(self.service.state)
        self.service.set_activity("retest")
        self.assertEqual(self.service.state["book"]["wallet"], before["book"]["wallet"])
        self.assertEqual(self.service.state["book"]["position"], before["book"]["position"])
        self.assertEqual(self.service.state["book"]["limits"], before["book"]["limits"])
        self.assertEqual(self.service.state["config"]["trade"]["max_hold"], 120)
        self.service.set_activity("active")
        self.assertEqual(self.service.state["config"]["trade"]["max_hold"], 12)
        self.assertEqual(self.service.state["config"]["trade"]["daily_entries"], 0)
        self.assertEqual(self.service.state["session"], before["session"])
        self.assertEqual(self.service.state["book"]["limits"], before["book"]["limits"])

    def test_old_13_migrates_frequency_without_resetting_account(self):
        self.open()
        old = copy.deepcopy(self.service.state)
        old["config"].pop("activity")
        old["config"]["trade"].update(max_hold=120, cooldown=15, daily_entries=4)
        old["book"]["config"].update(max_hold=120, cooldown=15, daily_entries=4)
        old.pop("activity_last_slot")
        self.service.commit(old)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        s = self.service.state
        self.assertEqual(s["session"], old["session"])
        self.assertEqual(s["book"]["position"], old["book"]["position"])
        self.assertEqual(s["book"]["wallet"], old["book"]["wallet"])
        self.assertEqual(s["book"]["limits"], old["book"]["limits"])
        self.assertEqual(s["book"]["config"]["max_hold"], 12)
        self.assertEqual(s["book"]["config"]["daily_entries"], 0)
        self.assertEqual(s["activity_last_slot"], old["book"]["position"]["time"] // 900000)

    def test_no_catchup_entries_after_long_offline_gap(self):
        self.step(1)
        self.step(62)
        s = self.service.status()
        self.assertEqual(s["activity"]["opened_last_hour"], 1)
        self.assertEqual(s["activity"]["closed_last_hour"], 0)

    def test_old_archive_trades_not_counted_toward_current_target(self):
        self.open()
        self.step(14)
        self.assertEqual(self.service.status()["activity"]["closed_last_hour"], 1)
        self.service.set_entries(False)
        self.service.reset("ARCHIVE_SOL_PAPER")
        self.assertEqual(self.service.status()["activity"]["closed_last_hour"], 0)
        self.assertEqual(self.service.status()["activity"]["opened_last_hour"], 0)
