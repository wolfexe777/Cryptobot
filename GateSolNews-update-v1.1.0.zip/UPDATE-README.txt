SOL ONLY 1.0.x -> 1.1.0. Do NOT overlay on ZEC.
Stop SOL with STOP.cmd, extract into the existing SOL folder replacing files, run CHECK.cmd, CHECK_NETWORK.cmd, START.cmd. Runtime and settings are preserved; the wallet is not reset.
Adds confirmed trend entries in the first 5 minutes and sizes by remaining monetary headroom. Existing monetary stops remain. Decimal PAPER contracts are preserved. Research export contains local PAPER data, never control tokens.
CHECK_GATE_DETAIL.cmd collects public endpoint fields without account data or orders.
