"""Active PAPER signals from completed minutes, paced by 15-minute windows.

This is an experimental signal policy, not a forecast of profitable returns.
"""

from decimal import Decimal


def evaluate(bars, now):
    rows = sorted((b for b in bars if b.t + 60000 <= now), key=lambda b: b.t)[-31:]
    out = {
        "bar_t": rows[-1].t if rows else None,
        "bar_end": rows[-1].t + 60000 if rows else None,
        "candidate": None,
        "trend": 0,
        "features": None,
        "reason": "Прогрев: нужны 31 непрерывная минутная свеча",
    }
    if len(rows) < 31:
        return out
    if any(b.t - a.t != 60000 for a, b in zip(rows, rows[1:], strict=False)):
        out["reason"] = "Разрыв или повтор в минутных свечах"
        return out
    c = rows[-1]
    fast = sum((b.c for b in rows[-5:]), Decimal(0)) / 5
    slow = sum((b.c for b in rows[-15:]), Decimal(0)) / 15
    changes = [b.c - a.c for a, b in zip(rows[-15:-1], rows[-14:], strict=True)]
    gains = sum((max(d, Decimal(0)) for d in changes), Decimal(0))
    losses = sum((max(-d, Decimal(0)) for d in changes), Decimal(0))
    rsi = 100 - 100 / (1 + gains / losses) if losses else Decimal(100) if gains else Decimal(50)
    atr = (
        sum(
            (
                max(b.h - b.l, abs(b.h - a.c), abs(b.l - a.c))
                for a, b in zip(rows[-15:-1], rows[-14:], strict=True)
            ),
            Decimal(0),
        )
        / 14
        / c.c
        * 100
    )
    volume = sum((b.v for b in rows[-21:-1]), Decimal(0)) / 20
    ratio = c.v / volume if volume else Decimal(0)
    momentum = (c.c / rows[-16].c - 1) * 100
    trend = 1 if fast > slow and momentum > 0 else -1 if fast < slow and momentum < 0 else 0
    out["trend"] = trend
    out["features"] = {
        "sma9": str(fast),
        "sma21": str(slow),
        "fast_period": 5,
        "slow_period": 15,
        "timeframe": "1m",
        "rsi14_cutler": str(rsi),
        "atr14_pct": str(atr),
        "volume_ratio": str(ratio),
        "close": str(c.c),
        "momentum_15m_pct": str(momentum),
    }
    if now - out["bar_end"] > 90000:
        out["reason"] = "Минутная свеча устарела: ждём свежие данные"
        return out
    if not Decimal(".05") <= atr <= Decimal("1.5"):
        out["reason"] = "Минутная волатильность вне диапазона 0,05–1,5%"
        return out
    if not Decimal(".5") <= ratio <= 5:
        out["reason"] = "Объём вне диапазона 0,5–5×"
        return out
    side, rule = 0, None
    # Broad trend entry: a candle in the trend direction; extremes remain blocked.
    if trend and trend * (c.c - c.o) > 0 and (40 <= rsi <= 75 if trend == 1 else 25 <= rsi <= 60):
        side, rule = trend, "active_momentum"
    else:
        mean = sum((b.c for b in rows[-20:]), Decimal(0)) / 20
        deviation = (c.c / mean - 1) * 100
        # Range reversal needs an actual turn, never a blind falling-knife entry.
        if abs(momentum) <= Decimal(".5") and abs(deviation) >= Decimal(".15"):
            if deviation < 0 and c.c > c.o and 25 <= rsi <= 55:
                side, rule = 1, "active_range_reversal"
            elif deviation > 0 and c.c < c.o and 45 <= rsi <= 75:
                side, rule = -1, "active_range_reversal"
    out["reason"] = "Нет минутного импульса или подтверждённого разворота диапазона"
    if side:
        out["candidate"] = {
            "id": f"active:{c.t}:{side}",
            "direction": side,
            "rule": rule,
            "bar_t": c.t,
            "bar_end": out["bar_end"],
            "features": out["features"],
        }
        out["reason"] = (
            "Минутный импульс по тренду"
            if rule == "active_momentum"
            else "Разворот от края диапазона"
        )
    return out
