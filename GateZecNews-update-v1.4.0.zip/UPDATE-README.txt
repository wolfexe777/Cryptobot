Gate ZEC News update 1.0.0-1.3.0 -> 1.4.0 ACTIVE PAPER
1. Stop the existing bot using STOP.cmd.
2. Extract this ZIP INTO the existing bot folder, replacing files.
3. Existing runtime and settings.json are preserved. From 1.3.0 the wallet, position, trades and loss limits are preserved. Active profile: max one entry per 15m, max holding 12m, no daily entry cap. Older accounts first migrate to 100 USDT / 5x with archive.
4. Run CHECK.cmd, CHECK_NETWORK.cmd, then START.cmd.
5. Diagnostics: %LOCALAPPDATA%\GateZecNews\network-check.json
The update requires the original 1.0.0 Windows package with its bundled runtime.
