"""Transport recovery and publisher attribution; synthetic RSS fixtures only."""

# The portable interpreter intentionally loads only this application's source tree.
# ruff: noqa: E402

import contextlib
import copy
import importlib.util
import io
import json
import sys
import tempfile
import threading
import time
import unittest
import urllib.parse
from datetime import datetime, timezone
from email.utils import format_datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from zecbot import news
from zecbot.broker import Broker, TradeConfig
from zecbot.config import DEFAULT, DEFAULT_SOURCES, LEGACY_SOURCES, validate
from zecbot.service import Service, restore_book

NOW = 1793400000000
SPEC = {
    "multiplier": ".01",
    "minimum": 1,
    "maintenance": ".003",
    "tick": ".01",
    "fee": ".00075",
    "funding_interval": 28800,
    "funding_offset": 0,
}


def item(
    title, source="google_news", publisher="https://www.coindesk.com", label="CoinDesk", path="a"
):
    stamp = format_datetime(datetime.fromtimestamp(NOW / 1000, timezone.utc))
    if source == "google_news":
        url = f"https://news.google.com/rss/articles/{path}"
    elif source == "bing_news":
        url = "https://www.bing.com/news/apiclick.aspx?" + urllib.parse.urlencode(
            {"url": publisher + "/article/" + path}
        )
    else:
        url = "https://" + news.SOURCES[source]["host"] + "/" + path
    url = url.replace("&", "&amp;")
    xml = f'<rss><channel><item><title>{title}</title><link>{url}</link><pubDate>{stamp}</pubDate><source url="{publisher}">{label}</source></item></channel></rss>'.encode()
    return news.parse_feed(xml, source, NOW)[0]


class AttributionTests(unittest.TestCase):
    def health(self, *sources):
        return {key: {"last_ok": NOW, "error": None} for key in sources}

    def test_google_suffix_removed_and_original_publisher_kept(self):
        row = item("SEC approves Zcash ETF - CoinDesk")
        self.assertEqual(row["title"], "SEC approves Zcash ETF")
        self.assertEqual(row["publisher"], "coindesk")
        self.assertFalse(row["primary"])
        self.assertTrue(row["can_signal"])

    def test_same_publisher_direct_and_aggregated_is_not_two_confirmations(self):
        a = item("SEC approves Zcash ETF - CoinDesk")
        b = item("Zcash ETF approved", source="coindesk")
        self.assertNotEqual(a["fingerprint"], b["fingerprint"])
        self.assertEqual(
            news.confirmed_events(
                [a, b], self.health("google_news", "coindesk"), NOW, DEFAULT["news"]
            ),
            [],
        )

    def test_two_original_publishers_can_share_one_delivery_route(self):
        a = item("SEC approves Zcash ETF - CoinDesk")
        b = item(
            "Zcash ETF approved - Cointelegraph",
            publisher="https://cointelegraph.com",
            label="Cointelegraph",
            path="b",
        )
        result = news.confirmed_events([a, b], self.health("google_news"), NOW, DEFAULT["news"])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["publishers"], ["coindesk", "cointelegraph"])
        self.assertEqual(result[0]["sources"], ["google_news"])

    def test_unknown_or_spoofed_publisher_cannot_generate_a_signal(self):
        for url in (
            "https://coindesk.com.evil",
            "http://coindesk.com",
            "https://user@coindesk.com",
            "https://127.0.0.1",
        ):
            row = item("SEC approves Zcash ETF", publisher=url)
            self.assertFalse(row["can_signal"])
            self.assertEqual(row["classification"]["direction"], 0)

    def test_bing_unwraps_known_original_publisher_without_fetching_article(self):
        row = item(
            "Zcash ETF approved",
            source="bing_news",
            publisher="https://decrypt.co",
            label="Decrypt",
        )
        self.assertEqual(row["publisher"], "decrypt")
        self.assertTrue(row["can_signal"])
        a = item(
            "SEC approves Zcash ETF", publisher="https://decrypt.co", label="Decrypt", path="b"
        )
        self.assertEqual(
            news.confirmed_events(
                [a, row], self.health("google_news", "bing_news"), NOW, DEFAULT["news"]
            ),
            [],
        )

    def test_release_updated_time_is_visible_but_never_a_catalyst(self):
        xml = b'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Zcash NU7 activated</title><link href="https://github.com/zcash/zcash/releases/tag/v7"/><updated>2026-10-31T00:00:00Z</updated></entry></feed>'
        row = news.parse_feed(xml, "zcash_github", NOW)[0]
        self.assertIsNotNone(row["published_at"])
        self.assertEqual(row["time_kind"], "updated_only")
        self.assertFalse(row["can_signal"])
        self.assertEqual(row["classification"]["direction"], 0)
        self.assertEqual(
            news.confirmed_events([row], self.health("zcash_github"), NOW, DEFAULT["news"]), []
        )

    def test_github_scope_and_readiness_do_not_claim_news_trading(self):
        self.assertFalse(
            news.allowed_url("https://github.com/other/zcash/releases/tag/v7", "zcash_github")
        )
        status = news.readiness(self.health("zcash_github", "zebra_github"), NOW, DEFAULT_SOURCES)
        self.assertTrue(status["release_only"])
        self.assertEqual(status["event_sources"], [])

    def test_transport_uses_configured_timeout_and_bounded_reading(self):
        response = MagicMock()
        response.__enter__.return_value = response
        response.url = news.SOURCES["ecc"]["url"]
        response.read1.side_effect = [b"<rss/>", b""]
        opener = MagicMock()
        opener.open.return_value = response
        with patch("zecbot.news.urllib.request.build_opener", return_value=opener):
            _, rows = news.fetch("ecc", timeout=25)
        self.assertEqual(rows, [])
        self.assertEqual(opener.open.call_args.kwargs["timeout"], 25)


class UpgradeAndPollingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.settings = self.root / "settings.json"
        cfg = copy.deepcopy(DEFAULT)
        cfg["activity"]["profile"] = "retest"
        cfg["sources"] = ["ecc", "coindesk"]
        self.settings.write_text(json.dumps(cfg))
        self.service = Service(self.root / "data", self.settings)

    def tearDown(self):
        self.service.close()
        self.temp.cleanup()

    def test_fast_feed_is_committed_while_slow_feed_is_still_waiting(self):
        started = threading.Event()
        release = threading.Event()

        def fetch(source, timeout=20):
            if source == "coindesk":
                started.set()
                release.wait(3)
            return NOW, []

        try:
            with patch("zecbot.service.news.fetch", side_effect=fetch):
                worker = threading.Thread(target=self.service.poll_news)
                worker.start()
                self.assertTrue(started.wait(1))
                deadline = time.monotonic() + 1
                status = None
                while time.monotonic() < deadline:
                    with self.service.lock:
                        row = self.service.db.execute(
                            "SELECT body FROM sources WHERE id='ecc'"
                        ).fetchone()
                    if row:
                        status = json.loads(row[0])
                        break
                    time.sleep(0.01)
                self.assertIsNotNone(status)
                self.assertEqual(status["last_ok"], NOW)
                self.assertTrue(worker.is_alive())
                release.set()
                worker.join(3)
        finally:
            release.set()
            if "worker" in locals():
                worker.join(4)

    def test_old_default_source_upgrade_keeps_wallet_position_session_and_risk(self):
        cfg = validate(copy.deepcopy(DEFAULT))
        cfg["sources"] = list(LEGACY_SOURCES)
        cfg.pop("news_timeout_seconds")
        cfg["trade"]["balance"] = "12345"
        cfg["trade"]["allocation"] = "0.07"
        book = Broker(TradeConfig(**cfg["trade"]), SPEC)
        book.pending = 1
        book.process(SimpleNamespace(t=NOW, o=100, h=100, l=100, c=100), 0)
        state = self.service.new_state(cfg)
        state.update(
            book=book.to_state(),
            execution_fee=".0008",
            execution_slippage=".0003",
            entries_enabled=False,
        )
        self.settings.write_text(json.dumps(cfg))
        self.service.commit(state)
        before = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["session"], before["session"])
        self.assertEqual(self.service.state["book"], before["book"])
        self.assertFalse(self.service.state["entries_enabled"])
        self.assertEqual(self.service.state["config"]["trade"], before["config"]["trade"])
        self.assertEqual(self.service.state["config"]["sources"], DEFAULT_SOURCES)
        self.assertEqual(restore_book(self.service.state).fee, restore_book(before).fee)
        self.assertFalse(self.service.status()["settings_changed"])

    def test_custom_source_list_is_not_overwritten(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg["activity"]["profile"] = "retest"
        cfg["sources"] = ["ecc"]
        cfg.pop("news_timeout_seconds")
        self.assertEqual(validate(cfg)["sources"], ["ecc"])

    def test_diagnostic_distinguishes_release_only_from_event_feed_success(self):
        spec = importlib.util.spec_from_file_location("_zec_diag", ROOT / "tools/check.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        def fetch(source, timeout=20):
            if source in ("zcash_github", "zebra_github"):
                return NOW, []
            raise OSError("fixture unavailable")

        report = self.root / "network.json"
        with (
            patch("zecbot.market.packet", return_value={}),
            patch("zecbot.news.fetch", side_effect=fetch),
            contextlib.redirect_stdout(io.StringIO()),
        ):
            result = module.main(["--network", "--report", str(report)])
        self.assertEqual(result, 2)
        data = json.loads(report.read_text())
        self.assertTrue(data["gate_ok"])
        self.assertEqual(data["status"], "ONLY_RELEASE_FEEDS_AVAILABLE")
        self.assertEqual(data["event_feeds_available"], 0)
        self.assertNotIn("control_token", data)


if __name__ == "__main__":
    unittest.main()
