"""GPL-3.0 adaptations, not upstream performance claims.

MoniGoMani signal weighting idea: Rikj000/MoniGoMani (Rikj000 et al.).
CombinedBinHAndCluc entry formula: freqtrade/freqtrade-strategies,
berlinguyinca et al. Exact revisions and adaptation differences: STRATEGIES.md.
No downloaded Python is executed. Indicators use a defined finite history.
"""

from decimal import Decimal as D

from . import activity
from .market import Candle

CATALOG = {
    "mgm_weighted": {
        "name": "MGM: взвешенные сигналы",
        "timeframe": "1m",
        "directions": "LONG / SHORT",
        "source": "https://github.com/Rikj000/MoniGoMani",
        "description": "Адаптация идеи MoniGoMani: ADX, MACD, SMA, VWAP и возврат в Bollinger. Фиксированные веса, без hyperopt.",
    },
    "combined_bollinger": {
        "name": "Combined: Bollinger-покупки",
        "timeframe": "5m",
        "directions": "LONG",
        "source": "https://github.com/freqtrade/freqtrade-strategies/blob/f3340ce11f5bdf62f598522e64d1f5638eaa13f5/user_data/strategies/berlinguyinca/CombinedBinHAndCluc.py",
        "description": "Входы BinHV45 / ClucMay72018 на 5m; выход к средней Bollinger. Собственные стопы и затраты PAPER.",
    },
    "confirmed_trend": {
        "name": "Прежняя: подтверждённый тренд",
        "timeframe": "1m",
        "directions": "LONG / SHORT",
        "source": None,
        "description": "Правила версии 1.1.1: SMA5/15/30 и импульс не менее одного ATR.",
    },
}


def ema(values, period):
    """SMA seed followed by standard EMA; None precedes the seed."""
    out = [None] * len(values)
    if len(values) < period:
        return out
    out[period - 1] = sum(values[:period], D(0)) / period
    alpha = D(2) / (period + 1)
    for i in range(period, len(values)):
        out[i] = out[i - 1] + alpha * (values[i] - out[i - 1])
    return out


def bands(values, period=20):
    values = values[-period:]
    mean = sum(values, D(0)) / period
    sd = (sum(((x - mean) ** 2 for x in values), D(0)) / (period - 1)).sqrt()
    return mean, mean - 2 * sd, mean + 2 * sd


def wilder(values, period=14):
    out = [sum(values[:period], D(0)) / period]
    for x in values[period:]:
        out.append((out[-1] * (period - 1) + x) / period)
    return out


def indicators(rows):
    closes = [b.c for b in rows]
    tr, plus, minus, gains, losses = [], [], [], [], []
    for a, b in zip(rows, rows[1:], strict=False):
        tr.append(max(b.h - b.l, abs(b.h - a.c), abs(b.l - a.c)))
        up, down = b.h - a.h, a.l - b.l
        plus.append(max(up, D(0)) if up > down else D(0))
        minus.append(max(down, D(0)) if down > up else D(0))
        gains.append(max(b.c - a.c, D(0)))
        losses.append(max(a.c - b.c, D(0)))
    atr, p, m = wilder(tr), wilder(plus), wilder(minus)
    dx = [100 * abs(x - y) / (x + y) if x + y else D(0) for x, y in zip(p, m, strict=True)]
    gain, loss = wilder(gains)[-1], wilder(losses)[-1]
    rsi = 100 - 100 / (1 + gain / loss) if loss else D(100) if gain else D(50)
    typical = [(b.h + b.l + b.c) / 3 for b in rows]
    mid, low, high = bands(typical)
    vol = sum((b.v for b in rows[-20:]), D(0))
    volume_base = sum((b.v for b in rows[-21:-1]), D(0)) / 20
    return {
        "atr14_pct": atr[-1] / closes[-1] * 100,
        "adx14": wilder(dx)[-1],
        "plus_di": 100 * p[-1] / atr[-1] if atr[-1] else D(0),
        "minus_di": 100 * m[-1] / atr[-1] if atr[-1] else D(0),
        "rsi14_wilder": rsi,
        "volume_ratio": rows[-1].v / volume_base if volume_base else D(0),
        "close": closes[-1],
        "bb_mid": mid,
        "bb_low": low,
        "bb_high": high,
        "vwap20": sum((p * b.v for p, b in zip(typical[-20:], rows[-20:], strict=True)), D(0)) / vol
        if vol
        else closes[-1],
    }


def grouped(bars, now, minutes):
    groups = {}
    step = minutes * 60000
    for b in bars:
        if b.t + 60000 <= now:
            groups.setdefault(b.t // step * step, []).append(b)
    out = []
    for t, parts in sorted(groups.items()):
        parts = sorted(parts, key=lambda b: b.t)
        if [b.t for b in parts] != list(range(t, t + step, 60000)) or t + step > now:
            continue
        out.append(
            Candle(
                t,
                parts[0].o,
                max(b.h for b in parts),
                min(b.l for b in parts),
                parts[-1].c,
                sum((b.v for b in parts), D(0)),
            )
        )
    return out


def evaluate(bars, now, strategy, settings):
    if strategy == "confirmed_trend":
        return activity.evaluate(bars, now, settings)
    if strategy not in CATALOG:
        raise ValueError("Неизвестная стратегия")
    minutes, count = (1, 240) if strategy == "mgm_weighted" else (5, 60)
    raw = sorted((b for b in bars if b.t + 60000 <= now), key=lambda b: b.t)
    rows = grouped(bars, now, minutes)[-count:]
    out = {
        "bar_t": rows[-1].t if rows else None,
        "bar_end": rows[-1].t + minutes * 60000 if rows else None,
        "candidate": None,
        "trend": 0,
        "features": None,
        "strategy": strategy,
        "reason": f"Прогрев: нужны {count} полных свечей {minutes}m",
    }
    if len(rows) < count:
        return out
    recent = raw[-(count * minutes + minutes) :]
    if any(b.t - a.t != 60000 for a, b in zip(recent, recent[1:], strict=False)):
        out["reason"] = "Разрыв или повтор в исходных минутных свечах"
        return out
    if any(b.t - a.t != minutes * 60000 for a, b in zip(rows, rows[1:], strict=False)):
        out["reason"] = "Разрыв в свечах стратегии: ждём непрерывные данные"
        return out
    f = indicators(rows)
    # The legacy UI keys remain available; RSI type is explicitly labelled.
    f.update(
        sma9=sum((b.c for b in rows[-9:]), D(0)) / 9,
        sma21=sum((b.c for b in rows[-50:]), D(0)) / 50,
        fast_period=9,
        slow_period=50,
        timeframe=f"{minutes}m",
        rsi_kind="Wilder",
        rsi14_cutler=f["rsi14_wilder"],
        range_15m_pct=(
            max(b.h for b in rows[-15 // minutes :]) - min(b.l for b in rows[-15 // minutes :])
        )
        / rows[-1].c
        * 100,
    )
    candidate = weighted(rows, f, out) if strategy == "mgm_weighted" else combined(rows, f, out)
    out["features"] = {k: str(v) if isinstance(v, D) else v for k, v in f.items()}
    # Even protective indicators must be causal; stale data never admits entries.
    if now - out["bar_end"] > 90000:
        out["reason"] = "Свеча стратегии устарела: ждём свежие данные"
        return out
    if now % 900000 >= settings["entry_window_minutes"] * 60000:
        out["reason"] = "Окно входа закрыто: новые сделки только в первые 5 минут интервала"
        return out
    if f["atr14_pct"] <= 0 or f["volume_ratio"] <= 0:
        out["reason"] = "Нет волатильности или объёма для входа"
        return out
    if candidate:
        side, rule = candidate
        out["candidate"] = {
            "id": f"{strategy}:{rows[-1].t}:{side}",
            "direction": side,
            "rule": rule,
            "strategy_revision": strategy + "-gate-paper-1",
            "bar_t": out["bar_t"],
            "bar_end": out["bar_end"],
            "features": out["features"],
        }
    return out


def weighted(rows, f, out):
    closes = [b.c for b in rows]
    slow = sum(closes[-200:], D(0)) / 200
    f["sma200"] = slow
    macd = [
        a - b
        for a, b in zip(ema(closes, 12), ema(closes, 26), strict=True)
        if a is not None and b is not None
    ]
    f["macd"], f["macd_signal"] = macd[-1], ema(macd, 9)[-1]
    previous = indicators(rows[:-1])
    trending = f["adx14"] >= 25
    f["regime"] = "trend" if trending else "range"
    scores, ballots = {}, {}
    for side in (1, -1):
        reentry = (
            (previous["close"] <= previous["bb_low"] and f["close"] > f["bb_low"])
            if side == 1
            else (previous["close"] >= previous["bb_high"] and f["close"] < f["bb_high"])
        )
        recovery = (
            (previous["rsi14_wilder"] <= 30 < f["rsi14_wilder"])
            if side == 1
            else (previous["rsi14_wilder"] >= 70 > f["rsi14_wilder"])
        )
        votes = {
            "adx_direction": 25 if trending and side * (f["plus_di"] - f["minus_di"]) > 0 else 0,
            "macd": 20 if side * (f["macd"] - f["macd_signal"]) > 0 else 0,
            "sma9_50": 15 if side * (f["sma9"] - f["sma21"]) > 0 else 0,
            "sma50_200": 15 if side * (f["sma21"] - slow) > 0 else 0,
            "vwap": 10 if side * (f["close"] - f["vwap20"]) > 0 else 0,
            "rsi_recovery": 15 if recovery else 0,
            "bollinger_reentry": 20 if reentry else 0,
        }
        scores[side] = sum(votes.values())
        ballots[str(side)] = votes
    f.update(long_score=scores[1], short_score=scores[-1], vote_threshold=65, votes=ballots)
    direction = 1 if f["plus_di"] > f["minus_di"] else -1 if f["plus_di"] < f["minus_di"] else 0
    out["trend"] = direction if trending else 0
    out["reason"] = f"MGM: {f['regime']}, баллы LONG {scores[1]} / SHORT {scores[-1]}; порог 65"
    for side in sorted(scores, key=scores.get, reverse=True):
        votes = ballots[str(side)]
        if scores[side] < 65 or scores[side] - scores[-side] < 15:
            continue
        if trending and side != direction:
            continue
        if not trending and not (votes["bollinger_reentry"] or votes["rsi_recovery"]):
            continue
        if not (30 <= f["rsi14_wilder"] <= 75 if side == 1 else 25 <= f["rsi14_wilder"] <= 70):
            continue
        if side * (rows[-1].c - rows[-1].o) <= 0:
            continue
        if not D(".05") <= f["atr14_pct"] <= D("1.5") or not D(".5") <= f["volume_ratio"] <= 5:
            continue
        out["reason"] += "; направление и закрытая свеча подтверждены"
        return side, "mgm_weighted"
    return None


def combined(rows, f, out):
    closes = [b.c for b in rows]
    mid, lower, _ = bands(closes, 40)
    previous_lower = bands(closes[:-1], 40)[1]
    c, previous = rows[-1], rows[-2]
    width, change, tail = abs(mid - lower), abs(c.c - previous.c), abs(c.c - c.l)
    slow = ema(closes, 50)[-1]
    volume_base = sum((b.v for b in rows[-31:-1]), D(0)) / 30
    bin_h = (
        previous_lower > 0
        and width > c.c * D(".008")
        and change > c.c * D(".0175")
        and tail < width * D(".25")
        and c.c < previous_lower
        and c.c <= previous.c
    )
    cluc = c.c < slow and c.c < D(".985") * f["bb_low"] and c.v < volume_base * 20
    f.update(ema50=slow, bin_h=bin_h, cluc=cluc)
    out["exit_long"] = c.c > f["bb_mid"]
    # Countertrend buys intentionally do not inherit a trend-reversal exit.
    out["reason"] = "Combined: ждём условия BinHV45 или ClucMay72018 ниже Bollinger"
    if bin_h or cluc:
        out["reason"] = (
            "Combined: " + ("BinHV45" if bin_h else "ClucMay72018") + " на закрытой 5m свече"
        )
        return 1, "combined_bin_h_cluc"
    return None
