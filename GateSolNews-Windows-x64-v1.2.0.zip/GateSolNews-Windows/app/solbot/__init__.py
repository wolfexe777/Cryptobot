"""SOL news-aware PAPER bot. GPL-3.0. No private exchange endpoints."""

VERSION = "1.2.0"
