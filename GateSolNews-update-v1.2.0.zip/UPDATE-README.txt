SOL ONLY 1.0.x / 1.1.x -> 1.2.0. Do NOT overlay on ZEC.
Stop SOL with STOP.cmd, extract into the existing SOL folder replacing files, run CHECK.cmd, CHECK_NETWORK.cmd, START.cmd. Runtime and settings are preserved; the wallet is not reset.
Adds MGM weighted signals and CombinedBinHAndCluc Bollinger entries, selectable in the active profile while flat. MGM is the new default for old settings without a strategy field. Read STRATEGIES.md for source revisions, licenses and adaptation differences. Upstream profit descriptions do not establish SOL returns.
PAPER daily loss cap stays disabled. Global loss stop and streak pause remain. Decimal PAPER contracts are preserved. Research export contains local PAPER data, never control tokens.
