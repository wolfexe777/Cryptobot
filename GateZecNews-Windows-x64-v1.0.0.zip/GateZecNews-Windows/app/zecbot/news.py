"""Bounded RSS/Atom parsing and explicit event rules, never an instruction engine.

These are headline heuristics, not a fact checker or a predictive language model.
Publication time and the time first observed by this process are kept separately.
"""

import hashlib
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser

SOURCES = {
    "zcash": {
        "name": "Zcash",
        "url": "https://z.cash/blog/feed/",
        "host": "z.cash",
        "primary": True,
    },
    "ecc": {
        "name": "Electric Coin Company",
        "url": "https://electriccoin.co/blog/feed/",
        "host": "electriccoin.co",
        "primary": True,
    },
    "foundation": {
        "name": "Zcash Foundation",
        "url": "https://zfnd.org/feed/",
        "host": "zfnd.org",
        "primary": True,
    },
    "coindesk": {
        "name": "CoinDesk",
        "url": "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "host": "coindesk.com",
        "primary": False,
    },
    "cointelegraph": {
        "name": "Cointelegraph",
        "url": "https://cointelegraph.com/rss",
        "host": "cointelegraph.com",
        "primary": False,
    },
}


class NewsError(RuntimeError):
    pass


def allowed_url(url, source):
    try:
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname or ""
        expected = SOURCES[source]["host"]
        return (
            parsed.scheme == "https"
            and (host == expected or host.endswith("." + expected))
            and parsed.username is None
            and parsed.password is None
            and parsed.port in (None, 443)
        )
    except ValueError:
        return False


class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(value, limit=3000):
    parser = Text()
    parser.feed(value[:12000])
    return " ".join(" ".join(parser.parts).split())[:limit]


def fingerprint(title):
    return hashlib.sha256(re.sub(r"[^a-z0-9]+", " ", title.lower()).strip().encode()).hexdigest()


def classify(title, summary, source):
    title = title.lower()
    body = title + " " + summary.lower()
    result = {
        "direction": 0,
        "event_key": None,
        "reason": "Нет однозначного фундаментального события",
    }
    if not (re.search(r"\b(?:zcash|zec)\b", body) or SOURCES[source]["primary"]):
        return {**result, "reason": "Нет связи с Zcash"}
    if (
        re.search(
            r"\b(?:could|may|might|will|would|to approve|to list|set to|rumou?r|reportedly|unconfirmed|alleged|propos(?:al|ed|es|ing)|plans?|expected|consider(?:ing|s)?|seeks?|filed|application|denies|denied|not|fake|prediction|forecast)\b",
            title,
        )
        or "?" in title
    ):
        return {**result, "reason": "Слух, прогноз, отрицание или ещё не принятое решение"}
    if re.search(r"\b(?:price|rallies|surges|soars|jumps|plunges|tumbles|rally|sell-off)\b", title):
        return {**result, "reason": "Описание уже прошедшего движения цены"}
    if re.search(
        r"\b(?:fixed|fixes|patched|resolved|mitigated|historical|simulation|testnet)\b", title
    ):
        return {**result, "reason": "Устранённое, историческое или тестовое событие"}
    asset = bool(re.search(r"\b(?:zcash|zec)\b", title))
    exchanges = [
        name
        for name in ("coinbase", "binance", "kraken", "gate", "okx", "bybit", "bitstamp")
        if re.search(r"\b" + name + r"\b", title)
    ]
    jurisdiction = re.search(r"\b(?:eu|us|uk|japan|india|australia|germany|france)\b", title)
    if (
        asset
        and jurisdiction
        and re.search(
            r"\b(?:bans|ban on) (?:zcash|zec)\b|\b(?:zcash|zec) (?:trading )?(?:is |has been )?banned\b",
            title,
        )
    ):
        return {
            "direction": -1,
            "event_key": "regulation:" + jurisdiction[0],
            "reason": "Заголовок сообщает о запрете Zcash в указанной юрисдикции",
        }
    if asset and re.search(
        r"\b(?:zcash|zec)(?:['’]s)? (?:network |chain )?(?:was |is |has been )?(?:exploited|hacked|halted|critical vulnerability disclosed|suffers attack)\b|\b(?:funds stolen from|critical vulnerability disclosed in) (?:zcash|zec)\b",
        title,
    ):
        return {
            "direction": -1,
            "event_key": "security:zec",
            "reason": "Заголовок сообщает о действующем инциденте Zcash",
        }
    if (
        asset
        and exchanges
        and re.search(
            r"\b(?:delists?|delisting|removes?) (?:zcash|zec)\b|\b(?:zcash|zec) (?:is |was |has been )?(?:delisted|delisting|removed from trading)\b",
            title,
        )
    ):
        return {
            "direction": -1,
            "event_key": "listing:" + exchanges[0],
            "reason": "Заголовок сообщает о делистинге Zcash",
        }
    if (
        asset
        and exchanges
        and re.search(
            r"\b(?:lists|listed|begins trading) (?:zcash|zec)\b|\b(?:zcash|zec) (?:is |now |has been )?listed on\b",
            title,
        )
    ):
        return {
            "direction": 1,
            "event_key": "listing:" + exchanges[0],
            "reason": "Заголовок сообщает о начавшемся листинге Zcash",
        }
    if asset and (
        re.search(r"approves? (?:the )?(?:first )?zcash (?:spot )?etf", title)
        or re.search(r"(?:zcash|zec) (?:spot )?etf (?:is |has been )?approved", title)
    ):
        return {
            "direction": 1,
            "event_key": "etf:zec",
            "reason": "Заголовок сообщает об одобрении Zcash ETF",
        }
    if (asset or SOURCES[source]["primary"]) and re.search(
        r"\b(?:activated|activation complete|upgrade is live|upgrade completed)\b", title
    ):
        version = re.search(r"\bnu\s*\d+(?:\.\d+)?\b", title)
        if version or (asset and re.search(r"\b(?:zcash|zec) network upgrade\b", title)):
            return {
                "direction": 1,
                "event_key": "upgrade:" + (version[0].replace(" ", "") if version else "zec"),
                "reason": "Заголовок сообщает об активации обновления сети",
            }
    return result


def parse_feed(data, source, observed_at):
    if (
        len(data) > 1024 * 1024
        or b"\x00" in data
        or re.search(rb"<!\s*(?:DOCTYPE|ENTITY)", data, re.I)
    ):
        raise NewsError("Слишком большой XML или запрещённый DTD/ENTITY")
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise NewsError("Источник не вернул корректный RSS/Atom") from exc

    def local(tag):
        return tag.rsplit("}", 1)[-1]

    if local(root.tag) not in ("rss", "feed", "RDF"):
        raise NewsError("Ответ не является RSS/Atom")
    rows = []
    for node in (n for n in root.iter() if local(n.tag) in ("item", "entry")):
        fields = {}
        url = None
        for item in node:
            key = local(item.tag)
            if (
                key == "link"
                and item.attrib.get("href")
                and item.attrib.get("rel", "alternate") == "alternate"
            ):
                url = item.attrib["href"]
            fields.setdefault(key, "".join(item.itertext()).strip())
        title = plain(fields.get("title", ""), 500)
        url = url or fields.get("link", "")
        if not title or not allowed_url(url, source):
            continue
        parsed = urllib.parse.urlsplit(url)
        query = urllib.parse.urlencode(
            [
                (k, v)
                for k, v in urllib.parse.parse_qsl(parsed.query)
                if not k.lower().startswith("utm_") and k.lower() not in ("fbclid", "gclid", "ref")
            ]
        )
        canonical = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, query, ""))
        stamp = fields.get("pubDate") or fields.get("published") or fields.get("date")
        published = None
        if stamp:
            try:
                date = parsedate_to_datetime(stamp)
            except (ValueError, TypeError):
                try:
                    date = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
                except ValueError:
                    date = None
            if date and date.tzinfo is not None:
                published = int(date.astimezone(timezone.utc).timestamp() * 1000)
        summary = plain(
            fields.get("description") or fields.get("summary") or fields.get("encoded") or ""
        )
        identifier = hashlib.sha256((source + "|" + canonical).encode()).hexdigest()
        rows.append(
            {
                "id": identifier,
                "source": source,
                "title": title,
                "url": canonical,
                "published_at": published,
                "first_seen": observed_at,
                "fingerprint": fingerprint(title),
                "classification": classify(title, summary, source),
            }
        )
        if len(rows) >= 100:
            break
    return rows


def fetch(source):
    class Redirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, msg, headers, url):
            if not allowed_url(url, source):
                raise NewsError("Редирект за пределы издателя отклонён")
            return super().redirect_request(request, fp, code, msg, headers, url)

    opener = urllib.request.build_opener(Redirect())
    request = urllib.request.Request(
        SOURCES[source]["url"],
        headers={
            "User-Agent": "GateZecNews/1.0 (+RSS paper research)",
            "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml",
        },
    )
    with opener.open(request, timeout=8) as response:
        if not allowed_url(response.url, source):
            raise NewsError("Неожиданный адрес ленты")
        data = response.read(1024 * 1024 + 1)
    observed = int(time.time() * 1000)
    return observed, parse_feed(data, source, observed)


def confirmed_events(articles, health, now, settings):
    groups = {}
    invalidated = {
        r["invalidated_event"]
        for r in articles
        if r.get("invalidated_event")
        and now - settings["max_age_minutes"] * 60000 <= r.get("updated_at", 0) <= now
    }
    baseline_copies = {
        r["fingerprint"]
        for r in articles
        if r.get("baseline")
        and r["published_at"] is not None
        and now - settings["max_age_minutes"] * 60000 <= r["published_at"] <= now
    }
    for row in articles:
        pub = row["published_at"]
        classification = row["classification"]
        status = health.get(row["source"], {})
        if (
            row.get("baseline")
            or row["fingerprint"] in baseline_copies
            or pub is None
            or not classification["direction"]
            or not now - settings["max_age_minutes"] * 60000 <= pub <= now + 60000
            or not now - settings["confirmation_minutes"] * 60000 <= row["first_seen"] <= now
            or status.get("error")
            or status.get("last_ok") is None
            or not 0 <= now - status["last_ok"] <= 180000
        ):
            continue
        key = classification["event_key"]
        groups.setdefault(key, []).append(row)
    result = []
    for key, rows in groups.items():
        if key in invalidated:
            continue
        if len({r["classification"]["direction"] for r in rows}) != 1:
            continue
        primary = any(SOURCES[r["source"]]["primary"] for r in rows)
        # Copied titles cannot turn one story into two confirmations.
        unique = {}
        for row in rows:
            unique.setdefault(row["fingerprint"], row)
        publishers = {r["source"] for r in unique.values()}
        if not primary and len(publishers) < 2:
            continue
        first = min(r["first_seen"] for r in rows)
        result.append(
            {
                "id": key,
                "direction": rows[0]["classification"]["direction"],
                "first_seen": first,
                "published_at": min(r["published_at"] for r in rows),
                "article_ids": [r["id"] for r in rows],
                "titles": [r["title"] for r in rows],
                "sources": sorted({r["source"] for r in rows}),
                "basis": "Первичный источник" if primary else "Два разных издателя",
            }
        )
    return sorted(result, key=lambda r: r["first_seen"], reverse=True)
