"""Numeric and execution regressions for GPL strategy adaptations; synthetic only."""

# ruff: noqa: E402
import copy
import sys
import threading
import unittest
import urllib.error
import urllib.request
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as fixtures
from solbot import strategies
from solbot.config import DEFAULT, SIGNALS, validate
from solbot.market import Candle
from solbot.service import Service, trend_exit_due
from solbot.web import create_server


def trend_bars(end=2, side=1):
    out = []
    for i in range(end - 400, end):
        o, c = fixtures.price(i - 1, side), fixtures.price(i, side)
        out.append(
            Candle(
                fixtures.BASE + i * 60000, o, max(o, c) + D(".12"), min(o, c) - D(".12"), c, D(10)
            )
        )
    return out


def drop_bars(tail=".01"):
    out = []
    for i in range(60):
        c = D("100") if i < 59 else D(96)
        for j in range(5):
            o = D(100) if j == 0 else c
            out.append(
                Candle(
                    fixtures.BASE + (i * 5 + j) * 60000,
                    o,
                    max(o, c) + D(".1"),
                    c - D(tail),
                    c,
                    D(10),
                )
            )
    return out


class AdaptedIndicatorTests(unittest.TestCase):
    def test_seeded_ema_sample_bollinger_and_wilder_known_values(self):
        self.assertEqual(
            strategies.ema(list(map(D, range(1, 6))), 3), [None, None, D(2), D(3), D(4)]
        )
        mid, low, high = strategies.bands(list(map(D, range(1, 21))))
        self.assertEqual(mid, D("10.5"))
        self.assertEqual(low, mid - 2 * D(35).sqrt())
        self.assertEqual(high, mid + 2 * D(35).sqrt())
        self.assertEqual(strategies.wilder([D(1)] * 14 + [D(15)])[-1], D(2))

    def test_trend_direction_and_votes_are_symmetric(self):
        for side in (1, -1):
            r = strategies.evaluate(
                trend_bars(side=side), fixtures.BASE + 130000, "mgm_weighted", SIGNALS
            )
            self.assertEqual(r["candidate"]["direction"], side)
            self.assertEqual(r["candidate"]["rule"], "mgm_weighted")
            self.assertEqual(r["trend"], side)
            f = r["features"]
            score = f["long_score"] if side == 1 else f["short_score"]
            self.assertGreaterEqual(score, 65)
            self.assertEqual(score, sum(f["votes"][str(side)].values()))
            self.assertEqual(f["timeframe"], "1m")

    def test_future_candles_do_not_change_either_strategy(self):
        for name, bars, now in (
            ("mgm_weighted", trend_bars(), fixtures.BASE + 130000),
            ("combined_bollinger", drop_bars(), fixtures.BASE + 18010000),
        ):
            future = Candle(now + 60000, D(100), D(9999), D(1), D(9999), D(10000))
            self.assertEqual(
                strategies.evaluate(bars, now, name, SIGNALS),
                strategies.evaluate(bars + [future], now, name, SIGNALS),
            )

    def test_missing_duplicate_stale_warmup_and_zero_volume_block(self):
        now = fixtures.BASE + 130000
        bars = trend_bars()
        cases = [
            bars[-100:],
            bars[:-8] + bars[-7:],
            bars + [bars[-2]],
            [Candle(b.t, b.o, b.h, b.l, b.c, D(0)) for b in bars],
        ]
        for case in cases:
            self.assertIsNone(strategies.evaluate(case, now, "mgm_weighted", SIGNALS)["candidate"])
        self.assertIsNone(
            strategies.evaluate(bars, now + 180000, "mgm_weighted", SIGNALS)["candidate"]
        )

    def test_late_window_allows_mgm_entry_with_protective_trend(self):
        r = strategies.evaluate(trend_bars(6), fixtures.BASE + 370000, "mgm_weighted", SIGNALS)
        self.assertEqual(r["trend"], 1)
        self.assertIsNotNone(r["candidate"])
        self.assertNotIn("Окно входа закрыто", r["reason"])

    def test_combined_uses_original_long_only_bin_h_formula_on_complete_5m(self):
        r = strategies.evaluate(
            drop_bars(), fixtures.BASE + 18010000, "combined_bollinger", SIGNALS
        )
        self.assertTrue(r["features"]["bin_h"])
        self.assertEqual(r["candidate"]["direction"], 1)
        self.assertEqual(r["candidate"]["rule"], "combined_bin_h_cluc")
        self.assertEqual(r["features"]["timeframe"], "5m")
        self.assertFalse(r["exit_long"])
        self.assertIsNone(
            strategies.evaluate(
                drop_bars()[:-1], fixtures.BASE + 18010000, "combined_bollinger", SIGNALS
            )["candidate"]
        )

    def test_cluc_branch_survives_when_tail_rejects_bin_h(self):
        r = strategies.evaluate(
            drop_bars(".8"), fixtures.BASE + 18010000, "combined_bollinger", SIGNALS
        )
        self.assertFalse(r["features"]["bin_h"])
        self.assertTrue(r["features"]["cluc"])
        self.assertIsNotNone(r["candidate"])

    def test_mean_reversion_exit_uses_own_band_and_ignores_opposite_trend(self):
        p = {"time": 1000, "side": 1, "entry_reason": {"rule": "combined_bin_h_cluc"}}
        tech = {
            "trend": -1,
            "bar_t": 300000,
            "bar_end": 600000,
            "strategy": "combined_bollinger",
            "exit_long": False,
        }
        self.assertFalse(trend_exit_due(p, tech, True))
        tech["exit_long"] = True
        self.assertTrue(trend_exit_due(p, tech, True))
        tech["bar_end"] = 1000
        self.assertFalse(trend_exit_due(p, tech, True))

    def test_unknown_strategy_and_live_mode_are_rejected(self):
        for value in (None, "magic_profit", {"id": "magic_profit"}, {"id": []}):
            cfg = copy.deepcopy(DEFAULT)
            cfg["strategy"] = value
            with self.assertRaises(ValueError):
                validate(cfg)
        cfg = copy.deepcopy(DEFAULT)
        cfg["mode"] = "live"
        with self.assertRaises(ValueError):
            validate(cfg)


class AdaptedExecutionTests(unittest.TestCase):
    setUp = fixtures.ActiveExecutionTests.setUp
    tearDown = fixtures.ActiveExecutionTests.tearDown
    now = fixtures.ActiveExecutionTests.now
    step = fixtures.ActiveExecutionTests.step

    def packet(self):
        bars = trend_bars(self.minute)
        p = bars[-1].c
        return {
            "bars": bars,
            "quote": {"t": self.now(), "bid": str(p - D(".01")), "ask": str(p + D(".01"))},
            "spec": self.spec,
            "funding": [],
        }

    def test_mgm_end_to_end_entry_costs_risk_and_restart(self):
        self.service.set_strategy("mgm_weighted")
        self.step(1)
        self.assertIsNone(self.service.status()["position"])
        self.step(2)
        p = self.service.status()["position"]
        self.assertEqual(p["entry_reason"]["rule"], "mgm_weighted")
        self.assertGreater(D(self.service.status()["summary"]["fees"]), 0)
        self.assertLessEqual(D(p["planned_risk_usdt"]), D(".25"))
        state = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(state, self.service.state)
        self.assertFalse(self.service.status()["settings_changed"])
        self.step(14)
        self.assertEqual(self.service.status()["summary"]["trades"], 1)

    def test_combined_end_to_end_entry_then_mean_exit_with_costs(self):
        self.service.set_strategy("combined_bollinger")
        bars = drop_bars()

        def step(minute):
            self.minute = minute
            visible = [b for b in bars if b.t + 60000 <= self.now()]
            price = visible[-1].c
            packet = {
                "bars": visible,
                "quote": {
                    "t": self.now(),
                    "bid": str(price - D(".01")),
                    "ask": str(price + D(".01")),
                },
                "spec": self.spec,
                "funding": [],
            }
            with patch("solbot.service.market.packet", return_value=packet):
                self.service.tick()

        step(299)
        self.assertIsNone(self.service.status()["position"])
        step(300)
        p = self.service.status()["position"]
        self.assertEqual(p["entry_reason"]["rule"], "combined_bin_h_cluc")
        self.assertEqual(p["side"], 1)
        self.assertGreater(D(self.service.status()["summary"]["fees"]), 0)
        # A new complete 5m close above the middle band requests an exit.
        # The observed quote stays near the fill to isolate the exit policy.
        tech = {
            "bar_t": self.now(),
            "bar_end": self.now() + 300000,
            "candidate": None,
            "trend": -1,
            "features": p["entry_reason"]["features"],
            "strategy": "combined_bollinger",
            "exit_long": True,
            "reason": "fixture mean exit",
        }
        with patch("solbot.service.strategies.evaluate", return_value=tech):
            step(305)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["history"][0]["reason"], "strategy_mean_exit")

    def test_adapted_entry_still_respects_spread_and_risk(self):
        self.service.set_strategy("mgm_weighted")
        self.step(1)
        self.minute = 2
        packet = self.packet()
        packet["quote"].update(bid="99", ask="101")
        with patch("solbot.service.market.packet", return_value=packet):
            self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertTrue(
            any(d["kind"] == "technical_blocked_spread" for d in self.service.status()["decisions"])
        )
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["total_halt"] = True
        self.service.commit(state)
        self.step(16)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["risk_status"], "total_stop")

    def test_confirmed_bad_news_blocks_mgm_long(self):
        from test_sol import article

        self.service.set_strategy("mgm_weighted")
        self.step(1)
        self.service.store_news_updates([("solana_status", self.now(), [], None, 0)])
        self.minute = 2
        row = article("Solana network halted", stamp=self.now() - 30000, seen=self.now() - 1000)
        self.service.store_news_updates([("solana_status", self.now() - 1000, [row], None, 0)])
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertTrue(
            any(d["kind"] == "technical_blocked_news" for d in self.service.status()["decisions"])
        )

    def test_old_open_position_keeps_old_trend_during_default_migration(self):
        self.step(1)
        self.step(2)
        state = copy.deepcopy(self.service.state)
        self.assertEqual(state["book"]["position"]["entry_reason"]["rule"], "confirmed_trend")
        state["config"].pop("strategy")
        self.service.commit(state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["config"]["strategy"]["id"], "mgm_weighted")
        self.assertEqual(self.service.state["book"]["position"], state["book"]["position"])
        self.step(3)
        self.assertEqual(
            self.service.state["technical"]["features"]["strategy_revision"],
            "sol-confirmed-trend-1",
        )

    def test_switch_preserves_losing_ledger_halts_and_frequency_cursor(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["book"]["wallet"] = "99.6"
        state["book"]["limits"]["total_halt"] = True
        state["activity_last_slot"] = self.now() // 900000
        self.service.commit(state)
        self.service.set_strategy("combined_bollinger")
        self.assertEqual(self.service.state["book"], state["book"])
        self.assertEqual(self.service.state["session"], state["session"])
        self.assertEqual(self.service.state["activity_last_slot"], state["activity_last_slot"])
        self.assertIsNone(self.service.state["technical_cursor"])

    def test_cannot_switch_with_position_or_in_retest_profile(self):
        self.service.set_strategy("mgm_weighted")
        self.step(1)
        self.step(2)
        before = copy.deepcopy(self.service.state)
        with self.assertRaises(ValueError):
            self.service.set_strategy("combined_bollinger")
        self.assertEqual(self.service.state, before)
        self.step(14)
        self.service.set_activity("retest")
        with self.assertRaises(ValueError):
            self.service.set_strategy("combined_bollinger")

    def test_new_strategy_is_used_for_old_config_without_resetting_wallet(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["config"].pop("strategy")
        state["book"]["wallet"] = "99.8"
        self.service.commit(state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["config"]["strategy"]["id"], "mgm_weighted")
        self.assertEqual(self.service.state["book"]["wallet"], "99.8")
        self.assertEqual(self.service.state["session"], state["session"])

    def test_http_selection_requires_token_and_persists_strategy(self):
        server, token = create_server(self.service, Path(__file__).parents[1] / "app/static", 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}/api/strategy"
        try:
            request = urllib.request.Request(
                url, b'{"strategy":"mgm_weighted"}', {"Content-Type": "application/json"}
            )
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(request)
            self.assertEqual(error.exception.code, 403)
            request.add_header("X-Control-Token", token)
            with urllib.request.urlopen(request) as response:
                self.assertEqual(response.status, 200)
            self.assertEqual(self.service.state["config"]["strategy"]["id"], "mgm_weighted")
            request = urllib.request.Request(
                url, b'{"strategy":"fake"}', {"X-Control-Token": token}
            )
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(request)
            self.assertEqual(error.exception.code, 400)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)
