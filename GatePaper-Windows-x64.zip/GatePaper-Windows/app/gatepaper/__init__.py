"""GatePaper Desktop: local, public-data-only futures simulation. GPL-3.0."""

VERSION = "1.0.0"
