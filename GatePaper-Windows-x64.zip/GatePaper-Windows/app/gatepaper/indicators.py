"""Persisted online indicators; no pandas, TA-Lib, future data or truncation resets.

EMA/Heikin-Ashi entry adapted from Gerald Lonlas' Strategy001 (GPL-3.0).
RSI/band recovery is an explicitly different analogue of Strategy002; see SOURCES.md.
Original samples and their license accompany the distribution.
"""

import copy
import math
from collections import deque

NAMES = {
    "ema_ha": "EMA 20/50 + Heikin-Ashi",
    "rsi_bands": "RSI + возврат в Bollinger",
    "donchian": "Пробой Donchian 20",
}


class Indicators:
    def __init__(self, state=None):
        self.state = (
            copy.deepcopy(state)
            if state
            else {
                "count": 0,
                "last_t": None,
                "last_close": None,
                "ema": {},
                "gain": 0.0,
                "loss": 0.0,
                "changes": 0,
                "ha_open": None,
                "ha_close": None,
                "window": [],
                "previous": None,
            }
        )

    def dump(self):
        return copy.deepcopy(self.state)

    def update(self, bar):
        s = self.state
        if s["last_t"] is not None and bar.t <= s["last_t"]:
            raise ValueError("Свечи индикаторов должны продвигаться по времени")
        close, opening, high, low, volume = [
            float(getattr(bar, k)) for k in ("c", "o", "h", "l", "v")
        ]
        prior = s["previous"]
        previous_ema = {k: v["value"] for k, v in s["ema"].items()}
        ema = {}
        for period in (20, 50, 100):
            key = str(period)
            item = s["ema"].setdefault(key, {"sum": 0.0, "value": None})
            if item["value"] is None:
                item["sum"] += close
                if s["count"] + 1 == period:
                    item["value"] = item["sum"] / period
            else:
                item["value"] += 2 / (period + 1) * (close - item["value"])
            ema[key] = item["value"]
        rsi = None
        if s["last_close"] is not None:
            delta = close - s["last_close"]
            gain = max(delta, 0)
            loss = max(-delta, 0)
            s["changes"] += 1
            if s["changes"] <= 14:
                s["gain"] += gain
                s["loss"] += loss
                if s["changes"] == 14:
                    s["gain"] /= 14
                    s["loss"] /= 14
            else:
                s["gain"] = (s["gain"] * 13 + gain) / 14
                s["loss"] = (s["loss"] * 13 + loss) / 14
            if s["changes"] >= 14:
                rsi = (
                    100 - 100 / (1 + s["gain"] / s["loss"])
                    if s["loss"]
                    else 100.0
                    if s["gain"]
                    else 50.0
                )
        ha_close = (opening + high + low + close) / 4
        ha_open = (
            (s["ha_open"] + s["ha_close"]) / 2
            if s["ha_open"] is not None
            else (opening + close) / 2
        )
        old_window = s["window"]
        upper = max(x[1] for x in old_window[-20:]) if len(old_window) >= 20 else None
        lower = min(x[2] for x in old_window[-20:]) if len(old_window) >= 20 else None
        window = deque(old_window, maxlen=100)
        window.append([close, high, low, volume, (high + low + close) / 3])
        band_low = band_high = None
        if len(window) >= 20:
            typical = [x[4] for x in list(window)[-20:]]
            mean = math.fsum(typical) / 20
            dev = math.sqrt(math.fsum((x - mean) ** 2 for x in typical) / 20)
            band_low, band_high = mean - 2 * dev, mean + 2 * dev
        result = {k: 0 for k in NAMES}
        if prior and volume > 0 and ema["100"] is not None:
            if previous_ema.get("20") is not None and previous_ema.get("50") is not None:
                result["ema_ha"] = (
                    1
                    if previous_ema["20"] <= previous_ema["50"]
                    and ema["20"] > ema["50"]
                    and ha_close > ema["20"]
                    and ha_close > ha_open
                    else -1
                    if previous_ema["20"] >= previous_ema["50"]
                    and ema["20"] < ema["50"]
                    and ha_close < ema["20"]
                    and ha_close < ha_open
                    else 0
                )
            if rsi is not None and prior["rsi"] is not None and band_low is not None:
                result["rsi_bands"] = (
                    1
                    if prior["band_low"] is not None
                    and prior["low"] < prior["band_low"]
                    and close > band_low
                    and rsi > prior["rsi"]
                    and rsi < 50
                    else -1
                    if prior["band_high"] is not None
                    and prior["high"] > prior["band_high"]
                    and close < band_high
                    and rsi < prior["rsi"]
                    and rsi > 50
                    else 0
                )
            if upper is not None:
                result["donchian"] = (
                    1
                    if close > upper and prior["close"] <= upper and close > ema["100"]
                    else -1
                    if close < lower and prior["close"] >= lower and close < ema["100"]
                    else 0
                )
        s.update(
            count=s["count"] + 1,
            last_t=bar.t,
            last_close=close,
            ha_open=ha_open,
            ha_close=ha_close,
            window=list(window),
            previous={
                "close": close,
                "low": low,
                "high": high,
                "rsi": rsi,
                "band_low": band_low,
                "band_high": band_high,
            },
        )
        return result
