@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 tools\gate_detail.py
pause
