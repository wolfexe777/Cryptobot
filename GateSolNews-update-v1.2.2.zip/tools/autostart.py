"""Opt-in current-user Windows startup. Never requires administrator privileges."""

import argparse
import os
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("enable", "disable"))
    args = parser.parse_args()
    if os.name != "nt":
        print("This optional feature is for Windows only.")
        return 1
    import winreg

    root = Path(__file__).resolve().parents[1]
    path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, path) as key:
        if args.action == "enable":
            command = subprocess.list2cmdline(
                [
                    str(root / "runtime/python.exe"),
                    "-I",
                    "-B",
                    "-X",
                    "utf8",
                    str(root / "app/main.py"),
                    "--no-browser",
                ]
            )
            winreg.SetValueEx(key, "GateSolNewsPaper", 0, winreg.REG_SZ, command)
            print(
                "Enabled at Windows sign-in for this user. Keep the extracted folder in this location."
            )
        else:
            try:
                winreg.DeleteValue(key, "GateSolNewsPaper")
            except FileNotFoundError:
                pass
            print("Windows sign-in autostart disabled. An already running process is not stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
