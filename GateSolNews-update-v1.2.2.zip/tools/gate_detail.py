"""Read-only public SOL endpoint diagnostics, independent of trading validators."""

import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))


def probe():
    from solbot import market

    jobs = {
        "contract": ("/contracts/SOL_USDT", None),
        "candles": ("/candlesticks", {"contract": "SOL_USDT", "interval": "1m", "limit": 180}),
        "order_book": ("/order_book", {"contract": "SOL_USDT", "limit": 5}),
        "funding": ("/funding_rate", {"contract": "SOL_USDT", "limit": 100}),
    }
    report = {
        "contract": "SOL_USDT",
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "real_orders": False,
        "endpoints": {},
    }
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {
            pool.submit(market.get, path, params): name for name, (path, params) in jobs.items()
        }
        for f in as_completed(futures):
            name = futures[f]
            try:
                data = f.result()
                if name == "contract":
                    fields = (
                        "name",
                        "type",
                        "in_delisting",
                        "quanto_multiplier",
                        "order_size_min",
                        "order_size_max",
                        "maintenance_rate",
                        "taker_fee_rate",
                        "order_price_round",
                        "funding_interval",
                        "funding_offset",
                        "leverage_max",
                        "enable_decimal",
                    )
                    details = {k: data.get(k) for k in fields}
                elif name == "order_book":
                    details = {k: data.get(k) for k in ("current", "bids", "asks")}
                elif name == "candles":
                    invalid = []
                    for row in data:
                        for k in ("o", "h", "l", "c", "v"):
                            try:
                                v = Decimal(str(row.get(k)))
                                valid = v.is_finite() and (v >= 0 if k == "v" else v > 0)
                            except (InvalidOperation, ValueError):
                                valid = False
                            if not valid:
                                invalid.append({"t": row.get("t"), "field": k, "value": row.get(k)})
                    details = {
                        "rows": len(data),
                        "invalid_count": len(invalid),
                        "invalid_values": invalid[:25],
                        "latest": data[-2:],
                    }
                else:
                    details = {"rows": len(data), "latest": data[:2]}
                report["endpoints"][name] = {"ok": True, "data": details}
                print(name, "OK", json.dumps(details, ensure_ascii=False, default=str), flush=True)
            except Exception as exc:
                report["endpoints"][name] = {"ok": False, "error": str(exc)}
                print(name, "FAILED", str(exc), flush=True)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Public Gate SOL diagnostics; no keys, account or orders"
    )
    parser.add_argument("--report", type=Path)
    args = parser.parse_args(argv)
    result = probe()
    path = (
        args.report
        or Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share")))
        / "GateSolNews"
        / "gate-detail.json"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("Diagnostic JSON:", path)
    print("No orders, keys or account data; public SOL endpoints only.")
    return 0 if all(r["ok"] for r in result["endpoints"].values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
