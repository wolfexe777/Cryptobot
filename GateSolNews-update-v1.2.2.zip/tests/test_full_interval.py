"""Whole-quarter PAPER entries without artificial boundary exits; synthetic paths."""

# ruff: noqa: E402
import copy
import json
import sys
import unittest
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as fixtures
import test_adapted_strategies as adapted
from solbot import activity, strategies
from solbot.config import DEFAULT, SIGNALS, validate
from solbot.market import Candle
from solbot.service import Service
from test_adapted_strategies import drop_bars, trend_bars


class WholeIntervalSignalsTests(unittest.TestCase):
    def test_mgm_and_previous_strategy_can_signal_in_each_late_minute(self):
        for minute in (6, 8, 10, 12, 14):
            for side in (1, -1):
                now = fixtures.BASE + minute * 60000 + 10000
                for name in ("mgm_weighted", "confirmed_trend"):
                    result = strategies.evaluate(trend_bars(minute, side), now, name, SIGNALS)
                    self.assertIsNotNone(
                        result["candidate"], (name, minute, side, result["reason"])
                    )
                    self.assertEqual(result["candidate"]["direction"], side)

    def test_old_window_setting_is_retired_without_touching_other_settings(self):
        old = copy.deepcopy(DEFAULT)
        old["signals"]["entry_window_minutes"] = 5
        before = copy.deepcopy(old)
        new = validate(old)
        self.assertNotIn("entry_window_minutes", new["signals"])
        self.assertEqual(old, before)
        self.assertEqual(new["trade"], old["trade"])
        self.assertEqual(new["management"], old["management"])
        self.assertEqual(new["strategy"], old["strategy"])


class WholeIntervalExecutionTests(unittest.TestCase):
    setUp = fixtures.ActiveExecutionTests.setUp
    tearDown = fixtures.ActiveExecutionTests.tearDown
    now = fixtures.ActiveExecutionTests.now
    step = fixtures.ActiveExecutionTests.step
    packet = adapted.AdaptedExecutionTests.packet

    def test_mgm_entry_at_minute_fourteen_survives_boundary_and_exits_after_twelve(self):
        self.service.set_strategy("mgm_weighted")
        self.step(13)
        self.step(14)
        p = self.service.status()["position"]
        self.assertIsNotNone(p)
        self.assertEqual(p["time"], self.now())
        self.assertEqual(p["entry_reason"]["timing_policy"], "full-15m-entry-12m-hold-v1")
        self.assertEqual(p["exit_deadline"], p["time"] + 720000)
        self.assertGreater(p["exit_deadline"], (p["time"] // 900000 + 1) * 900000)
        fixed_price = self.packet()["bars"][-1].c

        def frozen():
            packet = self.packet()
            packet["quote"].update(bid=str(fixed_price - D(".01")), ask=str(fixed_price + D(".01")))
            return packet

        # Persist the deadline through a restart before crossing the quarter.
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.status()["position"]["exit_deadline"], p["exit_deadline"])
        with patch("solbot.service.market.packet", side_effect=frozen):
            self.step(15)
            self.assertIsNotNone(self.service.status()["position"])
            self.assertEqual(self.service.status()["summary"]["trades"], 0)
            self.step(25)
            self.assertIsNotNone(self.service.status()["position"])
            self.step(26)
        row = self.service.status()["history"][0]
        self.assertEqual(row["reason"], "time_limit")
        self.assertEqual(row["exit_time"] - row["entry_time"], 720000)

    def test_early_exit_does_not_allow_second_entry_in_same_quarter(self):
        from solbot.service import restore_book

        self.service.set_strategy("mgm_weighted")
        self.step(5)
        self.step(6)
        state = copy.deepcopy(self.service.state)
        book = restore_book(state)
        row = book.close(self.now() + 1, book.last_price, "fixture_exit")
        state["book"] = book.to_state()
        self.service.commit(state, [row])
        for minute in (8, 10, 12, 14):
            self.step(minute)
            self.assertIsNone(self.service.status()["position"])
        self.step(16)
        self.assertIsNotNone(self.service.status()["position"])

    def test_combined_can_enter_on_minute_ten(self):
        self.service.set_strategy("combined_bollinger")
        bars = [Candle(b.t - 300000, b.o, b.h, b.l, b.c, b.v) for b in drop_bars()]

        def packet():
            visible = [b for b in bars if b.t + 60000 <= self.now()]
            price = visible[-1].c
            return {
                "bars": visible,
                "spec": self.spec,
                "funding": [],
                "quote": {
                    "t": self.now(),
                    "bid": str(price - D(".01")),
                    "ask": str(price + D(".01")),
                },
            }

        with patch("solbot.service.market.packet", side_effect=packet):
            self.step(294)
            self.step(295)
        p = self.service.status()["position"]
        self.assertIsNotNone(p)
        self.assertEqual(p["entry_reason"]["rule"], "combined_bin_h_cluc")
        self.assertEqual(p["time"] % 900000, 610000)

    def test_saved_old_window_and_cached_reason_are_migrated_once(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["config"]["signals"]["entry_window_minutes"] = 5
        state["last_entry_check"] = {"reason": "entry_window_closed", "detail": "old window"}
        state["book"]["wallet"] = "99.8"
        state["book"]["limits"]["total_halt"] = True
        self.settings.write_text(json.dumps(state["config"]))
        settings_before = self.settings.read_bytes()
        self.service.commit(state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["book"], state["book"])
        self.assertEqual(self.service.state["session"], state["session"])
        self.assertNotIn("last_entry_check", self.service.state)
        self.assertNotIn("entry_window_minutes", self.service.state["config"]["signals"])
        self.assertEqual(self.settings.read_bytes(), settings_before)
        migrated = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state, migrated)

    def test_full_interval_does_not_bypass_stale_data_or_total_stop(self):
        self.service.set_strategy("mgm_weighted")
        self.step(5)
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["total_halt"] = True
        self.service.commit(state)
        self.step(10)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["risk_status"], "total_stop")
        result = activity.evaluate(fixtures.candles(6), fixtures.BASE + 550000)
        self.assertIsNone(result["candidate"])
        self.assertIn("устарела", result["reason"])
