"""Gate numeric errors must identify their public field without weakening checks."""

# ruff: noqa: E402

import contextlib
import importlib.util
import io
import sys
import unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from solbot import market


class GateValidationTests(unittest.TestCase):
    def test_invalid_numbers_report_exact_field_and_value(self):
        for value in ("0", "-1", "NaN", "Infinity", "bad", None):
            with self.subTest(value=value), self.assertRaises(market.MarketError) as error:
                market.number(value, field="contract.order_size_min")
            self.assertIn("contract.order_size_min", str(error.exception))
            self.assertIn(str(value), str(error.exception))

    def test_zero_fee_and_volume_remain_valid_but_zero_price_does_not(self):
        self.assertEqual(market.number("0", False, field="contract.taker_fee_rate"), Decimal(0))
        self.assertEqual(market.number("0", False, field="candlesticks.v"), Decimal(0))
        with self.assertRaises(market.MarketError):
            market.number("0", field="order_book.bids[0].p")

    def test_packet_identifies_failing_endpoint(self):
        with (
            patch("solbot.market.contract", side_effect=market.MarketError("contract.test=0")),
            patch("solbot.market.candles", return_value=[]),
            patch("solbot.market.quote", return_value={}),
            patch("solbot.market.funding", return_value=[]),
            self.assertRaises(market.MarketError) as error,
        ):
            market.packet()
        self.assertIn("Gate contract:", str(error.exception))
        self.assertIn("contract.test=0", str(error.exception))

    def test_detail_probe_collects_raw_endpoints_without_accounts(self):
        spec = importlib.util.spec_from_file_location(
            "_gate_detail_probe", ROOT / "tools/gate_detail.py"
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        def response(path, params):
            if path.startswith("/contracts/"):
                return {"name": "SOL_USDT", "order_size_min": 0}
            if path == "/candlesticks":
                return [{"t": 60, "o": "0", "h": "0", "l": "0", "c": "0", "v": "0"}]
            if path == "/order_book":
                return {"bids": [{"p": "100", "s": 1}], "asks": [{"p": "101", "s": -1}]}
            return [{"t": 60, "r": "-.0001"}]

        with (
            patch("solbot.market.get", side_effect=response),
            contextlib.redirect_stdout(io.StringIO()),
        ):
            result = module.probe()
        self.assertEqual(len(result["endpoints"]), 4)
        self.assertEqual(result["endpoints"]["contract"]["data"]["order_size_min"], 0)
        self.assertEqual(result["endpoints"]["candles"]["data"]["invalid_count"], 4)
        self.assertFalse(result["real_orders"])
        self.assertNotIn("control_token", result)
