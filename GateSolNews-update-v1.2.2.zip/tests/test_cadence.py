"""Deterministic PAPER cadence, costs, safeguards and release provenance."""

# ruff: noqa: E402
import copy
import math
import sys
import unittest
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as fixtures
from solbot import VERSION, cadence, strategies
from solbot.config import DEFAULT, SIGNALS, validate
from solbot.market import Candle
from solbot.service import Service, restore_book


def range_bars(end):
    rows = []
    for i in range(end - 400, end):
        o = D(str(100 + 0.04 * math.sin(2 * math.pi * (i - 1) / 16)))
        c = D(str(100 + 0.04 * math.sin(2 * math.pi * i / 16)))
        rows.append(
            Candle(
                fixtures.BASE + i * 60000, o, max(o, c) + D(".02"), min(o, c) - D(".02"), c, D(10)
            )
        )
    return rows


class CadenceSignalTests(unittest.TestCase):
    def test_no_mgm_score_or_trend_required_on_range_path(self):
        bars = range_bars(2)
        now = fixtures.BASE + 130000
        mgm = strategies.evaluate(bars, now, "mgm_weighted", SIGNALS)
        self.assertEqual(mgm["features"]["regime"], "range")
        self.assertIsNone(mgm["candidate"])
        signal = cadence.evaluate(bars, now, SIGNALS)
        self.assertIsNotNone(signal["candidate"])
        self.assertTrue(signal["candidate"]["frequency_experiment"])
        self.assertEqual(signal["candidate"]["rule"], "paper_cadence")

    def test_future_gap_stale_and_flat_do_not_create_fictitious_entries(self):
        bars = range_bars(2)
        now = fixtures.BASE + 130000
        expected = cadence.evaluate(bars, now, SIGNALS)
        future = Candle(now + 60000, D(100), D(200), D(100), D(200), D(10))
        self.assertEqual(cadence.evaluate(bars + [future], now, SIGNALS), expected)
        for case in (bars[:-5] + bars[-4:], bars + [bars[-1]], bars[-10:]):
            self.assertIsNone(cadence.evaluate(case, now, SIGNALS)["candidate"])
        self.assertIsNone(cadence.evaluate(bars, now + 180000, SIGNALS)["candidate"])
        flat = [Candle(b.t, D(100), D(100), D(100), D(100), D(10)) for b in bars]
        self.assertIsNone(cadence.evaluate(flat, now, SIGNALS)["candidate"])

    def test_migration_changes_old_mgm_but_respects_new_explicit_selection(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg["strategy"] = {"id": "mgm_weighted"}
        before = copy.deepcopy(cfg)
        self.assertEqual(validate(cfg)["strategy"]["id"], "paper_cadence")
        self.assertEqual(cfg, before)
        cfg["strategy"]["selection_revision"] = 2
        self.assertEqual(validate(cfg)["strategy"]["id"], "mgm_weighted")
        cfg["strategy"]["selection_revision"] = True
        with self.assertRaises(ValueError):
            validate(cfg)


class CadenceExecutionTests(unittest.TestCase):
    setUp = fixtures.ActiveExecutionTests.setUp
    tearDown = fixtures.ActiveExecutionTests.tearDown
    now = fixtures.ActiveExecutionTests.now
    step = fixtures.ActiveExecutionTests.step

    def packet(self):
        bars = range_bars(self.minute)
        p = bars[-1].c
        spread = D(".5") if self.wide else D(".001")
        return {
            "bars": bars,
            "spec": self.spec,
            "funding": [],
            "quote": {"t": self.now(), "bid": str(p - spread), "ask": str(p + spread)},
        }

    def test_range_can_complete_four_charged_trades_without_a_series_pause(self):
        self.service.set_strategy("paper_cadence")
        # Isolate cadence from risk stops; a separate regression keeps the pause.
        state = copy.deepcopy(self.service.state)
        state["config"]["trade"].update(loss_streak=0, daily_loss_pct="0")
        self.service.commit(state)
        for minute in range(1, 60):
            self.step(minute)
        s = self.service.status()
        self.assertEqual(s["activity"]["closed_last_hour"], 4)
        self.assertEqual(s["activity"]["opened_last_hour"], 4)
        self.assertGreater(D(s["summary"]["fees"]), 0)
        self.assertLess(D(s["summary"]["net_pnl"]), 0)  # frequency is not profitable alpha
        self.assertTrue(all(r["entry_reason"]["rule"] == "paper_cadence" for r in s["history"]))

    def test_series_pause_can_still_skip_a_cadence_slot(self):
        self.service.set_strategy("paper_cadence")
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["streak_pause_until"] = self.now() + 900000
        self.service.commit(state)
        self.step(2)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["risk_status"], "streak_pause")

    def test_spread_rejection_can_retry_in_the_same_unused_quarter(self):
        self.service.set_strategy("paper_cadence")
        self.step(1)
        self.wide = True
        self.step(2)
        self.assertIsNone(self.service.status()["position"])
        self.wide = False
        self.step(3)
        self.assertIsNotNone(self.service.status()["position"])

    def test_closed_trade_cannot_reopen_same_quarter_even_after_restart(self):
        self.service.set_strategy("paper_cadence")
        self.step(1)
        self.step(2)
        state = copy.deepcopy(self.service.state)
        book = restore_book(state)
        row = book.close(self.now() + 1, book.last_price, "fixture_exit")
        state["book"] = book.to_state()
        self.service.commit(state, [row])
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        for minute in (3, 7, 10, 14):
            self.step(minute)
            self.assertIsNone(self.service.status()["position"])
        self.step(16)
        self.assertIsNotNone(self.service.status()["position"])

    def test_total_stop_and_user_pause_remain_effective(self):
        self.service.set_strategy("paper_cadence")
        self.step(1)
        self.service.set_entries(False)
        self.step(2)
        self.assertIsNone(self.service.status()["position"])
        self.service.set_entries(True)
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["total_halt"] = True
        self.service.commit(state)
        self.step(3)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["risk_status"], "total_stop")

    def test_confirmed_news_can_still_block_opposing_cadence_entry(self):
        from test_sol import article

        self.service.set_strategy("paper_cadence")
        self.step(1)
        self.service.store_news_updates([("solana_status", self.now(), [], None, 0)])
        self.minute = 2
        row = article("Solana network halted", stamp=self.now() - 30000, seen=self.now() - 1000)
        self.service.store_news_updates([("solana_status", self.now() - 1000, [row], None, 0)])
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertTrue(
            any(d["kind"] == "technical_blocked_news" for d in self.service.status()["decisions"])
        )

    def test_versioned_intervals_and_old_csv_remain_readable(self):
        self.step(1)
        self.assertEqual(self.service.status()["software_version"], VERSION)
        self.assertEqual(
            self.service.status()["activity"]["windows"][0]["software_version"], VERSION
        )
        row = copy.deepcopy(self.service.status()["activity"]["windows"][0])
        row.pop("software_version")
        row["slot_t"] -= 900000
        row["slot_end"] -= 900000
        self.service.commit(copy.deepcopy(self.service.state), window=row)
        csv = self.service.export_activity_csv()
        self.assertIn(b"software_version", csv)
        self.assertIn(VERSION.encode(), csv)

    def test_old_mgm_ledger_migrates_without_clearing_losses_or_halt(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["config"]["strategy"] = {"id": "mgm_weighted"}
        state["book"]["wallet"] = "99.6"
        state["book"]["limits"]["total_halt"] = True
        self.service.commit(state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["config"]["strategy"]["id"], "paper_cadence")
        self.assertEqual(self.service.state["book"], state["book"])
        self.assertEqual(self.service.state["session"], state["session"])
