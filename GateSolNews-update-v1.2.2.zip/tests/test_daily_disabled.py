"""Explicit PAPER daily-cap removal must resume the same ledger, not reset it."""

# ruff: noqa: E402
import copy
import json
import sys
import unittest
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as fixtures
from solbot.config import DEFAULT, validate
from solbot.service import Service, restore_book


class PaperLimitConfigTests(unittest.TestCase):
    def test_old_settings_disable_daily_only_without_mutating_input(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg.pop("paper_limits")
        cfg["trade"]["daily_loss_pct"] = "0.3"
        before = copy.deepcopy(cfg)
        new = validate(cfg)
        self.assertEqual(new["trade"]["daily_loss_pct"], "0")
        self.assertEqual(new["trade"]["total_loss_pct"], before["trade"]["total_loss_pct"])
        self.assertEqual(new["trade"]["loss_streak"], before["trade"]["loss_streak"])
        self.assertEqual(new["management"], before["management"])
        self.assertEqual(cfg, before)
        self.assertEqual(new["trade"]["balance"], "100")
        self.assertEqual(new["trade"]["leverage"], 5)

    def test_explicit_opt_in_can_still_test_original_daily_policy(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg["paper_limits"]["daily_loss_enabled"] = True
        cfg["trade"]["daily_loss_pct"] = ".3"
        self.assertEqual(validate(cfg)["trade"]["daily_loss_pct"], "0.3")
        for value in ("false", 0, None):
            cfg["paper_limits"]["daily_loss_enabled"] = value
            with self.assertRaises(ValueError):
                validate(cfg)

    def test_limit_removal_does_not_enable_live_or_another_contract(self):
        for changes in ({"mode": "live"}, {"contract": "ZEC_USDT"}):
            cfg = copy.deepcopy(DEFAULT)
            cfg.update(changes)
            with self.assertRaises(ValueError):
                validate(cfg)


class DailyRemovalMigrationTests(unittest.TestCase):
    setUp = fixtures.ActiveExecutionTests.setUp
    tearDown = fixtures.ActiveExecutionTests.tearDown
    now = fixtures.ActiveExecutionTests.now
    packet = fixtures.ActiveExecutionTests.packet
    step = fixtures.ActiveExecutionTests.step
    open = fixtures.ActiveExecutionTests.open

    def old_halt(self, reason="daily_loss", total=False, paused=False, position=False):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        book = restore_book(state)
        book.open(self.now() + 1000, D(100), 1)
        self.assertIsNotNone(book.position)
        records = []
        if not position:
            records = [book.close(self.now() + 2000, D("98.8"), "fixture_loss")]
            book.last_t = self.now() + 2000
            book.last_price = D("98.8")
            book.check_limits()
            self.assertTrue(book.limits["daily_halt"])
        book.limits.update(daily_halt=True, daily_halt_reason=reason, total_halt=total)
        state["book"] = book.to_state()
        state["config"].pop("paper_limits")
        state["entries_enabled"] = not paused
        self.service.commit(state, records)
        self.before = copy.deepcopy(self.service.state)
        self.old_settings = copy.deepcopy(state["config"])
        self.settings.write_text(json.dumps(self.old_settings))
        self.settings_bytes = self.settings.read_bytes()
        self.service.close()
        self.service = Service(self.root / "data", self.settings)

    def test_migration_clears_known_daily_halt_and_preserves_losses_and_history(self):
        self.old_halt()
        s = self.service.state
        self.assertFalse(s["book"]["limits"]["daily_halt"])
        self.assertIsNone(s["book"]["limits"]["daily_halt_reason"])
        self.assertEqual(s["config"]["trade"]["daily_loss_pct"], "0")
        self.assertEqual(s["book"]["config"]["daily_loss_pct"], "0")
        for field in (
            "wallet",
            "fees",
            "funding",
            "realized",
            "gains",
            "losses",
            "trades",
            "wins",
            "history",
            "curve",
            "position",
        ):
            self.assertEqual(s["book"][field], self.before["book"][field])
        self.assertEqual(s["session"], self.before["session"])
        self.assertEqual(self.settings.read_bytes(), self.settings_bytes)
        self.assertEqual(len(self.service.status()["history"]), 1)
        self.assertEqual(self.service.db.execute("SELECT COUNT(*) FROM archives").fetchone()[0], 0)

    def test_next_window_opens_same_day_without_waiting_for_utc_reset(self):
        self.old_halt()
        day = self.service.state["book"]["limits"]["day"]
        self.step(2)
        self.step(16)
        self.assertIsNotNone(self.service.status()["position"])
        self.assertEqual(self.service.state["book"]["limits"]["day"], day)
        self.assertLess(D(self.service.state["book"]["wallet"]), D(100))
        self.assertIsNone(self.service.status()["summary"]["remaining_daily_loss_usdt"])

    def test_global_stop_is_not_cleared(self):
        self.old_halt(total=True)
        self.assertTrue(self.service.state["book"]["limits"]["total_halt"])
        self.step(2)
        self.step(16)
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["risk_status"], "total_stop")

    def test_user_pause_and_series_pause_are_preserved(self):
        self.old_halt(paused=True)
        self.assertFalse(self.service.state["entries_enabled"])
        self.step(2)
        self.step(16)
        self.assertIsNone(self.service.status()["position"])
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"]["streak_pause_until"] = self.now() + 900000
        self.service.commit(state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(
            self.service.state["book"]["limits"]["streak_pause_until"],
            state["book"]["limits"]["streak_pause_until"],
        )

    def test_other_or_unknown_daily_halt_causes_are_not_erased(self):
        self.old_halt(reason="legacy_unknown")
        self.assertTrue(self.service.state["book"]["limits"]["daily_halt"])
        self.assertEqual(
            self.service.state["book"]["limits"]["daily_halt_reason"], "legacy_unknown"
        )

    def test_open_position_and_protective_levels_are_preserved(self):
        self.old_halt(position=True)
        self.assertEqual(self.service.state["book"]["position"], self.before["book"]["position"])
        self.assertEqual(self.service.state["book"]["wallet"], self.before["book"]["wallet"])
        self.assertFalse(self.service.state["book"]["limits"]["daily_halt"])

    def test_restart_and_profile_switch_do_not_reset_balance_or_reenable_cap(self):
        self.old_halt()
        before = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state, before)
        self.service.set_activity("retest")
        self.service.set_activity("active")
        self.assertEqual(self.service.state["book"]["wallet"], before["book"]["wallet"])
        self.assertEqual(self.service.state["config"]["trade"]["daily_loss_pct"], "0")
        self.assertEqual(self.service.state["config"]["trade"]["total_loss_pct"], "1")
        self.assertFalse(self.service.status()["settings_changed"])
