"""Causal trading behavior with synthetic quotes/candles, not market results."""

import copy
import json
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal as D
from email.utils import format_datetime
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from solbot import market, news, technical
from solbot.config import DEFAULT, validate
from solbot.service import Service

START = 1793400000000 // 300000 * 300000
SPEC = {
    "multiplier": ".01",
    "minimum": 1,
    "maintenance": ".003",
    "tick": ".01",
    "fee": ".00075",
    "funding_interval": 28800,
    "funding_offset": 0,
}


def append_bar(bars, start, opening, close, volume=10):
    for j in range(5):
        o = opening + (close - opening) * j / 5
        c = opening + (close - opening) * (j + 1) / 5
        bars.append(
            market.Candle(
                start + j * 60000, o, max(o, c) + D(".12"), min(o, c) - D(".12"), c, D(volume)
            )
        )


def setup_bars(side=1):
    bars = []
    last = D(100)
    for i in range(31):
        close = D(100) + D(".02") * i + (D(".08") if i % 2 else -D(".08"))
        if i == 29:
            close += D(".35")
        if i == 30:
            last = D("100.85") if side == 1 else D("99.15")
            close = D("100.96")
        if side == -1:
            close = 200 - close
        append_bar(bars, START + i * 300000, last, close, 20 if i == 29 else 10)
        last = close
    return bars


class TechnicalTests(unittest.TestCase):
    def test_both_directions_have_market_setups_without_articles(self):
        for side in (1, -1):
            result = technical.evaluate(setup_bars(side), START + 31 * 300000 + 10000)
            self.assertEqual(result["candidate"]["direction"], side)
            self.assertEqual(result["candidate"]["rule"], "breakout_retest")
            self.assertGreater(D(result["features"]["atr14_pct"]), D(".15"))

    def test_future_prices_cannot_change_current_signal(self):
        bars = setup_bars()
        now = START + 31 * 300000 + 10000
        expected = technical.evaluate(bars, now)
        future = copy.deepcopy(bars)
        append_bar(future, START + 31 * 300000, D(101), D(200), 1000)
        self.assertEqual(technical.evaluate(future, now), expected)

    def test_incomplete_or_stale_candle_cannot_open_a_position(self):
        now = START + 31 * 300000 + 10000
        self.assertIsNone(technical.evaluate(setup_bars()[:-1], now)["candidate"])
        self.assertIsNone(technical.evaluate(setup_bars(), now + 120000)["candidate"])

    def test_low_volume_and_flat_market_do_not_force_a_trade(self):
        bars = setup_bars()
        for i in range(-5, 0):
            b = bars[i]
            bars[i] = market.Candle(b.t, b.o, b.h, b.l, b.c, D(5))
        self.assertIsNone(technical.evaluate(bars, START + 31 * 300000 + 10000)["candidate"])
        flat = []
        for i in range(30):
            append_bar(flat, START + i * 300000, D(100), D(100))
        self.assertIsNone(technical.evaluate(flat, START + 31 * 300000 + 10000)["candidate"])


class HybridTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.settings = self.root / "settings.json"
        self.cfg = copy.deepcopy(DEFAULT)
        self.cfg["activity"]["profile"] = "retest"
        self.cfg["sources"] = ["solana_status"]
        self.settings.write_text(json.dumps(self.cfg))
        self.clock = START + 30 * 300000 + 10000
        self.bars = setup_bars()
        self.price = D("100.48")
        self.packet_patch = patch("solbot.service.market.packet", side_effect=self.packet)
        self.clock_patch = patch("solbot.service.time.time", side_effect=lambda: self.clock / 1000)
        self.packet_patch.start()
        self.clock_patch.start()
        self.service = Service(self.root / "data", self.settings)
        self.service.store_news_updates([("solana_status", self.clock, [], None, 0)])

    def tearDown(self):
        self.service.close()
        self.clock_patch.stop()
        self.packet_patch.stop()
        self.tmp.cleanup()

    def packet(self):
        bars = [b for b in self.bars if b.t + 65000 <= self.clock]
        return {
            "bars": bars,
            "quote": {
                "t": self.clock,
                "bid": str(self.price - D(".01")),
                "ask": str(self.price + D(".01")),
            },
            "spec": dict(SPEC),
            "funding": [],
        }

    def bootstrap(self):
        self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])

    def advance(self):
        self.clock = START + 31 * 300000 + 10000
        self.price = self.bars[-1].c

    def story(self, positive=True):
        title = "Solana v3.0 activated" if positive else "Solana network halted"
        stamp = format_datetime(datetime.fromtimestamp((self.clock - 30000) / 1000, timezone.utc))
        xml = f"<rss><channel><item><title>{title}</title><link>https://status.solana.com/story-{positive}</link><pubDate>{stamp}</pubDate></item></channel></rss>".encode()
        rows = news.parse_feed(xml, "solana_status", self.clock - 1000)
        self.service.store_news_updates([("solana_status", self.clock - 1000, rows, None, 0)])

    def test_market_entry_without_any_news_and_with_failed_feed(self):
        self.bootstrap()
        self.advance()
        self.service.store_news_updates([("solana_status", self.clock, [], "offline fixture", 0)])
        self.service.tick()
        p = self.service.status()["position"]
        self.assertEqual(p["side"], 1)
        self.assertEqual(p["time"], self.clock)
        self.assertEqual(p["entry_reason"]["kind"], "technical")
        self.assertIsNone(p["news_event"])
        self.assertEqual(self.service.status()["news"], [])
        self.assertLess(D(self.service.status()["summary"]["net_pnl"]), 0)  # fees/spread at entry

    def test_market_short_also_works_without_news(self):
        self.bars = setup_bars(-1)
        self.price = 200 - D("100.48")
        self.bootstrap()
        self.advance()
        self.service.tick()
        self.assertEqual(self.service.status()["position"]["side"], -1)
        self.assertEqual(self.service.status()["position"]["entry_reason"]["kind"], "technical")

    def test_first_start_does_not_replay_historical_market_signal(self):
        self.advance()
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.clock += 1000
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])

    def test_confirmed_bad_news_blocks_long_then_persists_during_feed_outage(self):
        self.bootstrap()
        self.advance()
        self.story(False)
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertTrue(
            any(r["kind"] == "technical_blocked_news" for r in self.service.status()["decisions"])
        )
        self.service.store_news_updates([("solana_status", self.clock, [], "offline fixture", 0)])
        append_bar(self.bars, START + 31 * 300000, self.bars[-1].c, D("101.4"), 20)
        self.clock += 300000
        self.price = D("101.4")
        self.service.tick()
        self.assertTrue(self.service.state["news_context"])
        self.assertIsNone(self.service.status()["position"])

    def test_aligned_news_annotates_market_entry_without_backdating_news_price_reaction(self):
        self.bootstrap()
        self.advance()
        self.story(True)
        self.service.tick()
        p = self.service.status()["position"]
        plan = p["entry_reason"]
        self.assertEqual(plan["kind"], "technical_news")
        self.assertLess(plan["bar_end"], plan["news_event"]["first_seen"])
        self.assertGreater(p["time"], plan["news_event"]["first_seen"])
        self.assertIsNotNone(p["news_event"])

    def test_confirmed_news_can_close_a_pure_market_position(self):
        self.bootstrap()
        self.advance()
        self.service.tick()
        self.clock += 10000
        self.story(False)
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        trade = self.service.status()["history"][0]
        self.assertEqual(trade["reason"], "news_reversal")
        self.assertEqual(trade["entry_reason"]["kind"], "technical")
        self.assertIsNotNone(trade["exit_news"])

    def test_same_signal_never_reopens_after_stop_even_with_zero_cooldown(self):
        self.service.state["config"]["trade"]["cooldown"] = 0
        self.bootstrap()
        self.advance()
        self.service.tick()
        self.clock += 10000
        self.price = D(98)
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.clock += 10000
        self.price = D("101.01")
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["trades"], 1)

    def test_same_breakout_id_cannot_be_reused_on_a_later_bar(self):
        self.service.state["config"]["trade"]["cooldown"] = 0
        self.bootstrap()
        self.advance()
        self.service.tick()
        original = copy.deepcopy(self.service.state["technical"])
        self.clock += 10000
        self.price = D(98)
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.clock += 300000
        self.price = D("100.96")
        original["bar_t"] += 300000
        original["bar_end"] += 300000
        with patch("solbot.service.technical.evaluate", return_value=original):
            self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["summary"]["trades"], 1)

    def test_paused_market_signal_is_not_queued_for_later(self):
        self.bootstrap()
        self.service.set_entries(False)
        self.advance()
        self.service.tick()
        self.service.set_entries(True)
        self.clock += 1000
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])

    def test_news_only_remains_an_explicit_optional_mode(self):
        self.cfg["trading"]["mode"] = "news_only"
        self.settings.write_text(json.dumps(self.cfg))
        self.service.set_entries(False)
        self.service.reset("ARCHIVE_SOL_PAPER")
        self.service.set_entries(True)
        self.bootstrap()
        self.advance()
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])

    def test_news_context_expires_without_inventing_new_articles(self):
        self.bootstrap()
        self.advance()
        self.story(False)
        self.service.tick()
        self.assertTrue(self.service.state["news_context"])
        self.clock += 31 * 60000
        self.service.tick()
        self.assertEqual(self.service.state["news_context"], {})

    def test_market_entry_metadata_and_cursor_survive_restart_and_csv(self):
        self.bootstrap()
        self.advance()
        self.service.tick()
        before = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state, before)
        self.clock += 10000
        self.price = D(98)
        self.service.tick()
        csv = self.service.export_csv()
        self.assertIn(b"entry_reason_json", csv)
        self.assertIn(b"technical", csv)

    def test_wide_spread_blocks_technical_setup(self):
        self.bootstrap()
        self.advance()
        packet = self.packet()
        packet["quote"].update(bid="100.8", ask="101.2")
        with patch("solbot.service.market.packet", return_value=packet):
            self.service.tick()
        self.assertIsNone(self.service.status()["position"])

    def test_old_v11_config_gains_hybrid_without_resetting_wallet(self):
        self.bootstrap()
        self.advance()
        self.service.tick()
        old = copy.deepcopy(self.service.state)
        old["book"]["position"].pop("entry_reason", None)
        old["book"]["position"]["news_event"] = {
            "id": "fixture-old-news",
            "direction": 1,
            "article_ids": [],
            "titles": ["Synthetic old headline"],
        }
        old["config"].pop("trading")
        old.pop("technical_cursor", None)
        old.pop("news_context", None)
        old["entries_enabled"] = False
        self.service.commit(old)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["session"], old["session"])
        self.assertEqual(self.service.state["book"], old["book"])
        self.assertIsNotNone(self.service.state["book"]["position"])
        self.assertEqual(self.service.state["config"]["trade"], old["config"]["trade"])
        self.assertEqual(self.service.state["config"]["trading"]["mode"], "hybrid")
        self.assertFalse(self.service.state["entries_enabled"])

    def test_quote_drift_blocks_late_market_entry(self):
        self.bootstrap()
        self.advance()
        self.price = D("103")
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertTrue(
            any(r["kind"] == "technical_blocked_drift" for r in self.service.status()["decisions"])
        )

    def test_new_market_trend_can_close_position_before_time_limit(self):
        self.bootstrap()
        self.advance()
        self.service.tick()
        for i in range(6):
            append_bar(self.bars, START + (31 + i) * 300000, self.bars[-1].c, D("100.15"))
        self.clock += 6 * 300000
        self.price = D("100.15")
        self.service.tick()
        self.assertIsNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["history"][0]["reason"], "technical_trend_exit")

    def test_strategy_mode_does_not_enable_real_orders(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg["trading"]["mode"] = "live"
        with self.assertRaises(ValueError):
            validate(cfg)


if __name__ == "__main__":
    unittest.main()
