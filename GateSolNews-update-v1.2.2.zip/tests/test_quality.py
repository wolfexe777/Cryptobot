"""Causal quality and remaining-risk regressions, using synthetic market paths."""

# ruff: noqa: E402
import copy
import json
import sys
import unittest
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as fixtures
from solbot import activity, market
from solbot.broker import Broker, TradeConfig
from solbot.config import DEFAULT, upgrade_sources, validate
from solbot.service import Service, management_plan
from test_decimal_contracts import actual_spec


def path(slope, amplitude, wick):
    bars = []
    for i in range(-29, 2):
        c = D(100) + slope * i + (amplitude if i % 2 else -amplitude)
        o = D(100) + slope * (i - 1) + (amplitude if (i - 1) % 2 else -amplitude)
        bars.append(
            market.Candle(
                fixtures.BASE + i * 60000, o, max(o, c) + wick, min(o, c) - wick, c, D(10)
            )
        )
    return bars


class ConfirmedTrendTests(unittest.TestCase):
    def test_noise_smaller_than_one_atr_is_rejected(self):
        r = activity.evaluate(path(D(".01"), D(".08"), D(".12")), fixtures.BASE + 130000)
        self.assertEqual(r["trend"], 1)
        self.assertLess(D(r["features"]["momentum_atr_ratio"]), 1)
        self.assertIsNone(r["candidate"])

    def test_long_and_short_both_require_macro_alignment(self):
        for side in (1, -1):
            r = activity.evaluate(fixtures.candles(2, side), fixtures.BASE + 130000)
            self.assertEqual(r["candidate"]["direction"], side)
            self.assertEqual(r["candidate"]["rule"], "confirmed_trend")
            self.assertEqual(r["candidate"]["strategy_revision"], activity.STRATEGY_REVISION)
            f = r["features"]
            self.assertGreater(side * (D(f["sma9"]) - D(f["sma21"])), 0)
            self.assertGreater(side * (D(f["sma21"]) - D(f["sma30"])), 0)

    def test_single_red_candle_in_uptrend_is_not_a_countertrend_short(self):
        bars = path(D(".015"), D(".03"), D(".01"))
        b = bars[-1]
        bars[-1] = market.Candle(b.t, b.c + D(".02"), max(b.h, b.c + D(".03")), b.l, b.c, b.v)
        r = activity.evaluate(bars, fixtures.BASE + 130000)
        self.assertEqual(r["trend"], 1)
        self.assertIsNone(r["candidate"])

    def test_late_window_allows_entry_and_preserves_protective_trend(self):
        r = activity.evaluate(fixtures.candles(6), fixtures.BASE + 370000)
        self.assertEqual(r["trend"], 1)
        self.assertIsNotNone(r["features"])
        self.assertIsNotNone(r["candidate"])
        self.assertNotIn("Окно входа закрыто", r["reason"])

    def test_future_candles_cannot_change_current_decision(self):
        now = fixtures.BASE + 130000
        bars = fixtures.candles(2)
        self.assertEqual(
            activity.evaluate(bars, now), activity.evaluate(bars + fixtures.candles(100), now)
        )

    def test_invalid_or_weaker_quality_settings_rejected(self):
        for key, value in [
            ("min_momentum_atr", "NaN"),
            ("min_momentum_atr", ".5"),
        ]:
            cfg = copy.deepcopy(DEFAULT)
            cfg["signals"][key] = value
            with self.assertRaises(ValueError):
                validate(cfg)

    def test_upgrade_adds_quality_rules_without_replacing_wallet_risk(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg.pop("signals")
        result = upgrade_sources(cfg)
        self.assertIn("signals", result)
        self.assertNotIn("signals", cfg)
        self.assertEqual(result["trade"], cfg["trade"])
        self.assertEqual(result["management"], cfg["management"])


class RemainingRiskTests(unittest.TestCase):
    def book(self, wallet="100", **updates):
        cfg = dict(DEFAULT["trade"], daily_loss_pct="0.3")
        cfg.update(updates)
        b = Broker(TradeConfig(**cfg), actual_spec())
        from types import SimpleNamespace

        b.process(SimpleNamespace(t=fixtures.BASE, o=D(85), h=D(85), l=D(85), c=D(85)), 0)
        b.wallet = D(wallet)
        b.entry_management = management_plan(DEFAULT["management"], D(".2"), b.fee, b.slip)
        return b

    def test_near_daily_limit_blocks_before_even_minimum_entry_fee(self):
        b = self.book("99.705")
        self.assertGreater(D(".1") * D(85) * b.fee, D(".005"))
        b.open(fixtures.BASE + 60000, D(85), -1)
        self.assertIsNone(b.position)
        self.assertEqual(b.wallet, D("99.705"))
        self.assertEqual(b.fees, 0)
        self.assertEqual(b.limits["entries"], 0)
        self.assertIn("остаток", b.last_entry_block)

    def test_size_is_reduced_to_remaining_daily_budget(self):
        b = self.book("99.79")
        b.open(fixtures.BASE + 60000, D(100), 1)
        self.assertEqual(b.position["quantity"], D(".1"))
        self.assertLessEqual(D(b.position["planned_risk_usdt"]), D(".09"))
        stop = b.price(b.position["protective_stop"], False)
        loss = (
            b.position["quantity"] * (b.position["entry"] - stop)
            + b.position["entry_fee"]
            + stop * b.position["quantity"] * b.fee
        )
        self.assertLessEqual(loss, D(".09"))

    def test_metrics_show_small_remaining_budget_precisely(self):
        b = self.book("99.705")
        self.assertEqual(D(b.metrics()["remaining_daily_loss_usdt"]), D(".005"))
        self.assertEqual(D(b.metrics()["remaining_total_loss_usdt"]), D(".705"))

    def test_remaining_total_budget_is_enforced_even_without_daily_limit(self):
        b = self.book("99.04", daily_loss_pct="0")
        b.open(fixtures.BASE + 60000, D(100), 1)
        self.assertIsNone(b.position)
        self.assertFalse(b.limits["total_halt"])
        self.assertEqual(b.fees, 0)

    def test_new_utc_day_restores_daily_headroom_but_not_total_stop(self):
        b = self.book("99.705")
        tomorrow = (fixtures.BASE // 86400000 + 1) * 86400000
        b.roll_limits(tomorrow)
        b.open(tomorrow, D(85), 1)
        self.assertIsNotNone(b.position)
        b = self.book("99.705")
        b.limits["total_halt"] = True
        b.roll_limits(tomorrow)
        b.open(tomorrow, D(85), 1)
        self.assertIsNone(b.position)
        self.assertTrue(b.limits["total_halt"])


class QualityServiceTests(unittest.TestCase):
    setUp = fixtures.ActiveExecutionTests.setUp
    tearDown = fixtures.ActiveExecutionTests.tearDown
    now = fixtures.ActiveExecutionTests.now
    packet = fixtures.ActiveExecutionTests.packet
    step = fixtures.ActiveExecutionTests.step
    open = fixtures.ActiveExecutionTests.open

    def test_service_allows_late_entry_when_evaluator_returns_candidate(self):
        self.step(1)
        self.minute = 6
        signal = activity.evaluate(fixtures.candles(2), fixtures.BASE + 130000)
        signal["bar_t"] = self.now() - 70000
        signal["bar_end"] = self.now() - 10000
        with patch("solbot.service.activity.evaluate", return_value=signal):
            self.service.tick()
        self.assertIsNotNone(self.service.status()["position"])
        self.assertGreater(D(self.service.status()["summary"]["fees"]), 0)

    def test_confirmed_news_entry_is_allowed_after_first_five_minutes(self):
        self.step(1)
        self.minute = 6
        event = {
            "id": "synthetic-news",
            "direction": 1,
            "first_seen": self.now() - 60000,
            "published_at": self.now() - 90000,
            "titles": ["Synthetic Solana event"],
            "article_ids": [],
            "basis": "fixture",
        }
        with (
            patch("solbot.service.news.confirmed_events", return_value=[event]),
            patch("solbot.service.price_confirmation", return_value=(True, "fixture confirmation")),
        ):
            self.service.tick()
        self.assertIsNotNone(self.service.status()["position"])
        self.assertEqual(self.service.status()["position"]["entry_reason"]["kind"], "news_price")

    def test_entry_contains_cost_and_stop_plan_for_next_analysis(self):
        self.open()
        p = self.service.status()["position"]
        reason = p["entry_reason"]
        self.assertEqual(reason["strategy_revision"], activity.STRATEGY_REVISION)
        self.assertEqual(reason["risk_plan"]["planned_loss_usdt"], p["planned_risk_usdt"])
        self.assertGreater(D(reason["risk_plan"]["fee_rate"]), 0)
        self.assertGreater(D(reason["risk_plan"]["target"]), D(p["entry"]))

    def test_evidence_export_has_observed_bars_quotes_and_no_control_token(self):
        self.open()
        data = json.loads(self.service.export_research())
        self.assertEqual(len(data["quotes"]), 2)
        self.assertEqual(len(data["spec"]), 2)
        self.assertGreater(len(data["bar"]), 30)
        self.assertFalse(data["news_backtest_supported"])
        self.assertNotIn("control_token", json.dumps(data))
        for b in data["bar"]:
            self.assertGreaterEqual(b["observed_at"], b["data"]["t"] + 60000)

    def test_first_observation_is_not_promoted_by_later_poll(self):
        self.open()
        before = json.loads(self.service.export_research())["bar"]
        packet = self.packet()
        packet["quote"]["t"] += 1000
        with (
            patch("solbot.service.market.packet", return_value=packet),
            patch("solbot.service.time.time", return_value=packet["quote"]["t"] / 1000),
        ):
            self.service.tick()
        self.assertEqual(json.loads(self.service.export_research())["bar"], before)

    def test_rejected_entry_reason_survives_quotes_without_a_new_bar(self):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["book"]["wallet"] = "99.705"
        self.service.commit(state)
        self.step(2)
        message = self.service.state["message"]
        self.assertIn("остаток", message)
        packet = self.packet()
        packet["quote"]["t"] += 1000
        with (
            patch("solbot.service.market.packet", return_value=packet),
            patch("solbot.service.time.time", return_value=packet["quote"]["t"] / 1000),
        ):
            self.service.tick()
        self.assertEqual(self.service.state["message"], message)
        self.assertEqual(
            self.service.status()["activity"]["windows"][0]["reason"],
            "entry_blocked_risk_or_cooldown",
        )
        self.assertIsNone(self.service.status()["position"])

    def test_archived_quotes_not_exported_as_current_experiment(self):
        self.step(1)
        self.service.set_entries(False)
        self.service.reset("ARCHIVE_SOL_PAPER")
        data = json.loads(self.service.export_research())
        self.assertEqual(data["bar"], [])
        self.assertEqual(data["quotes"], [])
        self.assertEqual(data["trades"], [])

    def test_old_monetary_halt_and_wallet_survive_strategy_upgrade(self):
        self.step(1)
        old = copy.deepcopy(self.service.state)
        old["config"].pop("signals")
        old["book"]["wallet"] = "99.67"
        old["book"]["limits"].update(daily_halt=True, daily_halt_reason="daily_loss")
        self.service.commit(old)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state["session"], old["session"])
        self.assertEqual(self.service.state["book"]["wallet"], "99.67")
        self.assertTrue(self.service.state["book"]["limits"]["daily_halt"])
        self.assertEqual(self.service.state["book"]["limits"]["daily_halt_reason"], "daily_loss")
