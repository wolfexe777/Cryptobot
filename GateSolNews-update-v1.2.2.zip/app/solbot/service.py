"""Persistent news-aware quote PAPER execution. No backdated news orders."""

import copy
import csv
import io
import json
import logging
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from decimal import Decimal, localcontext
from types import SimpleNamespace

from . import VERSION, activity, market, news, strategies, technical
from .broker import Broker, TradeConfig
from .config import apply_activity, digest, read, upgrade_sources

LOGGER = logging.getLogger("solbot")


def restore_book(state):
    if not state.get("book"):
        return None
    book = Broker.restore(state["book"])
    book.slip = Decimal(state.get("execution_slippage", book.config.slippage))
    book.fee = Decimal(state.get("execution_fee", book.config.fee))
    return book


def apply_book_config(book, trade):
    """Disable only a known daily monetary halt when its limit is switched off."""
    book.config = TradeConfig(**trade)
    if (
        book.limits
        and book.limits["daily_halt"]
        and book.limits.get("daily_halt_reason") == "daily_loss"
        and Decimal(book.config.daily_loss_pct) == 0
    ):
        book.limits.update(daily_halt=False, daily_halt_reason=None)
        return True
    return False


def position_reason(position):
    if not position:
        return None
    return position.get("entry_reason") or {
        "kind": "news_price" if position.get("news_event") else "legacy",
        "direction": position["side"],
        "news_event": position.get("news_event"),
    }


def management_plan(settings, atr_pct, fee, slippage):
    """Percent risk adapts to SOL's volatility and observed execution costs."""
    costs = (2 * fee + 2 * slippage) * 100
    floor = max(Decimal(settings["min_stop_pct"]), costs * Decimal(settings["cost_stop_multiple"]))
    if floor > Decimal(settings["max_stop_pct"]):
        return None
    stop_pct = min(
        Decimal(settings["max_stop_pct"]), max(floor, atr_pct * Decimal(settings["atr_multiple"]))
    )
    return {
        "risk_fraction": str(Decimal(settings["risk_per_trade_pct"]) / 100),
        "stop_fraction": str(stop_pct / 100),
        "estimated_roundtrip_cost_pct": str(costs),
    }


def trend_exit_due(position, tech, active):
    """Range setups must not immediately exit on the trend they faded."""
    if (position.get("entry_reason") or {}).get("rule") == "combined_bin_h_cluc":
        return bool(
            tech.get("strategy") == "combined_bollinger"
            and tech.get("exit_long")
            and tech["bar_end"] > position["time"]
        )
    opposite = tech["trend"] == -position["side"]
    if not active:
        return opposite
    if (position.get("entry_reason") or {}).get("rule") == "active_range_reversal":
        return False
    stamp = tech["bar_t"]
    if (
        stamp is None
        or tech["bar_end"] <= position["time"]
        or stamp == position.get("trend_check_bar")
    ):
        return False
    consecutive = position.get("trend_check_bar") == stamp - 60000
    position["opposite_trend_count"] = (
        (position.get("opposite_trend_count", 0) + 1 if consecutive else 1) if opposite else 0
    )
    position["trend_check_bar"] = stamp
    return position["opposite_trend_count"] >= 2


def price_confirmation(arm, bars, quote, settings):
    now = quote["t"]
    if now > arm["expires"]:
        return False, "Срок реакции на новость истёк"
    eligible = [b for b in bars if b.t >= arm["anchor_t"] and b.t + 60000 <= now]
    if not eligible:
        return False, "Ожидаем завершённую минуту после получения новости"
    bar = eligible[-1]
    prior = [b for b in bars if b.t < bar.t][-20:]
    if len(prior) < 20:
        return False, "Не хватает данных для подтверждения"
    side = arm["event"]["direction"]
    mid = (Decimal(quote["bid"]) + Decimal(quote["ask"])) / 2
    move = side * (mid / Decimal(arm["anchor_price"]) - 1) * 100
    if move < Decimal(settings["min_move_pct"]):
        return False, "Цена ещё не подтвердила направление новости"
    if move > Decimal(settings["max_move_pct"]):
        return False, "Цена уже прошла слишком далеко после сигнала"
    old = sum((b.v for b in prior), Decimal(0)) / 20
    mean = sum((b.c for b in prior), Decimal(0)) / 20
    if old <= 0 or bar.v < old * Decimal(settings["volume_ratio"]):
        return False, "Нет подтверждения объёмом"
    if side * (bar.c - bar.o) <= 0 or side * (bar.c - mean) <= 0:
        return False, "Свеча/средняя цена не подтверждают направление"
    return True, "Новость и последующая реакция цены подтверждены"


class Service:
    def __init__(self, directory, settings):
        self.directory, self.settings = directory, settings
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.shutdown = threading.Event()
        self.threads = []
        self.db = sqlite3.connect(
            directory / "sol-news.sqlite3", check_same_thread=False, isolation_level=None
        )
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
CREATE TABLE IF NOT EXISTS snapshot(id INTEGER PRIMARY KEY,body TEXT NOT NULL,revision INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS articles(id TEXT PRIMARY KEY,seen INTEGER NOT NULL,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS trades(session TEXT,entry_t INTEGER,exit_t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,entry_t,exit_t));
CREATE TABLE IF NOT EXISTS quotes(session TEXT,t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,t));
CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY,t INTEGER,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS archives(id INTEGER PRIMARY KEY,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS market_evidence(session TEXT,kind TEXT,t INTEGER,observed_t INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,kind,t));
CREATE TABLE IF NOT EXISTS activity_windows(session TEXT,slot INTEGER,body TEXT NOT NULL,PRIMARY KEY(session,slot));
""")
        row = self.db.execute("SELECT body,revision FROM snapshot WHERE id=1").fetchone()
        self.state, self.revision = (
            (json.loads(row[0]), row[1])
            if row
            else (self.new_state(read(settings), requested_profile=True), 0)
        )
        if self.state.get("version") != 1 or self.state["config"]["contract"] != "SOL_USDT":
            self.db.close()
            raise ValueError("Неизвестная база SOL; данные не сброшены")
        if not row:
            self.commit(self.state)
        elif self.state.get("arm") or upgrade_sources(self.state["config"]) != self.state["config"]:
            state = copy.deepcopy(self.state)
            state["arm"] = None
            state["config"] = upgrade_sources(state["config"])
            state["config_sha256"] = digest(state["config"])
            state["technical_cursor"] = None
            state["technical"] = None
            state.pop("last_entry_check", None)
            book = restore_book(state)
            if book:
                entries = [r["entry_time"] for r in book.history]
                if book.position:
                    entries.append(book.position["time"])
                if entries:
                    state["activity_last_slot"] = max(
                        state.get("activity_last_slot") or 0, max(entries) // 900000
                    )
                cleared = apply_book_config(book, state["config"]["trade"])
                state["book"] = book.to_state()
                if cleared:
                    state.pop("last_entry_check", None)
                    state["message"] = (
                        "Дневной лимит убытка PAPER отключён; кошелёк и история сохранены"
                    )
            self.commit(state)
        # The user requested a new 100 USDT / 5x PAPER profile. Never reinterpret
        # a large old position at the new balance or discard its losses.
        if self.state.get("account_profile") != "sol-100-usdt-5x-v1":
            state = copy.deepcopy(self.state)
            book = restore_book(state)
            if book and book.position:
                state["profile_pending"] = True
                state.setdefault("profile_resume", state["entries_enabled"])
                state["entries_enabled"] = False
                state["arm"] = None
                state["message"] = (
                    "Переход на 100 USDT / 5×: ожидаем свежую цену для закрытия старой PAPER-позиции"
                )
                self.commit(state)
            else:
                self.activate_profile()
        self.market_error = None
        self.last_market_attempt = None

    @staticmethod
    def new_state(config, requested_profile=False):
        config = copy.deepcopy(config)
        if requested_profile:
            config["trade"].update(balance="100", leverage=5)
        return {
            "version": 1,
            "account_profile": "sol-100-usdt-5x-v1",
            "session": uuid.uuid4().hex,
            "config": config,
            "config_sha256": digest(config),
            "entries_enabled": config["auto_start"],
            "started_at": int(time.time() * 1000),
            "book": None,
            "spec": None,
            "quote": None,
            "funding_cursor": None,
            "arm": None,
            "consumed": {},
            "message": "Ожидаем новости и котировки SOL",
            "technical_cursor": None,
            "technical": None,
            "news_context": {},
        }

    def activate_profile(self):
        """Archive the OLD ledger first; only a flat portfolio may switch."""
        old = self.state
        book = restore_book(old)
        if book and book.position:
            raise ValueError("Старая PAPER-позиция ещё открыта")
        state = self.new_state(upgrade_sources(old["config"]), requested_profile=True)
        state["entries_enabled"] = old.get("profile_resume", old["entries_enabled"])
        state["message"] = "Новый PAPER-счёт: 100 USDT / 5×. Прежний счёт сохранён в архиве"
        self.commit(state, archive=True)

    def commit(
        self, state, trades=(), quote=None, decisions=(), archive=False, window=None, evidence=()
    ):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            old = self.db.execute("SELECT revision FROM snapshot WHERE id=1").fetchone()
            if (old[0] if old else 0) != self.revision:
                raise ValueError("База изменилась другим процессом")
            if archive:
                self.db.execute("INSERT INTO archives(body) VALUES(?)", (json.dumps(self.state),))
            for row in trades:
                self.db.execute(
                    "INSERT INTO trades VALUES(?,?,?,?)",
                    (
                        state["session"],
                        row["entry_time"],
                        row["exit_time"],
                        json.dumps(row, ensure_ascii=False),
                    ),
                )
            if quote:
                self.db.execute(
                    "INSERT INTO quotes VALUES(?,?,?)",
                    (state["session"], quote["t"], json.dumps(quote)),
                )
            for row in decisions:
                self.db.execute(
                    "INSERT INTO decisions(t,body) VALUES(?,?)",
                    (row["t"], json.dumps(row, ensure_ascii=False)),
                )
            if window:
                old_window = self.db.execute(
                    "SELECT body FROM activity_windows WHERE session=? AND slot=?",
                    (state["session"], window["slot_t"]),
                ).fetchone()
                if old_window:
                    previous = json.loads(old_window[0])
                    window["first_observed"] = previous["first_observed"]
                    window["entries"] = max(previous["entries"], window["entries"])
                self.db.execute(
                    "INSERT OR REPLACE INTO activity_windows VALUES(?,?,?)",
                    (state["session"], window["slot_t"], json.dumps(window, ensure_ascii=False)),
                )
            for kind, stamp, observed, body in evidence:
                self.db.execute(
                    "INSERT OR IGNORE INTO market_evidence VALUES(?,?,?,?,?)",
                    (state["session"], kind, stamp, observed, json.dumps(body, ensure_ascii=False)),
                )
            revision = self.revision + 1
            self.db.execute(
                "INSERT OR REPLACE INTO snapshot VALUES(1,?,?)",
                (json.dumps(state, ensure_ascii=False, allow_nan=False), revision),
            )
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
        self.state, self.revision = state, revision

    def poll_news(self):
        with self.lock:
            enabled = list(self.state["config"]["sources"])
            timeout = self.state["config"].get("news_timeout_seconds", 20)

        def fetch(source):
            start = time.monotonic()
            try:
                observed, rows = news.fetch(source, timeout=timeout)
                return source, observed, rows, None, int((time.monotonic() - start) * 1000)
            except Exception as exc:
                return (
                    source,
                    int(time.time() * 1000),
                    [],
                    str(exc),
                    int((time.monotonic() - start) * 1000),
                )

        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = [pool.submit(fetch, source) for source in enabled]
            for future in as_completed(futures):
                self.store_news_updates([future.result()])

    def store_news_updates(self, updates):
        with self.lock:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                for source, observed, rows, error, elapsed_ms in updates:
                    old = self.db.execute(
                        "SELECT body FROM sources WHERE id=?", (source,)
                    ).fetchone()
                    status = json.loads(old[0]) if old else {"initialized": False, "last_ok": None}
                    status.update(
                        last_attempt=observed, error=error, count=len(rows), elapsed_ms=elapsed_ms
                    )
                    if error is None:
                        for row in rows:
                            row["baseline"] = not status["initialized"]
                            previous = self.db.execute(
                                "SELECT body FROM articles WHERE id=?", (row["id"],)
                            ).fetchone()
                            if previous:
                                previous = json.loads(previous[0])
                                if previous["classification"] != row["classification"]:
                                    previous["updated_at"] = observed
                                    previous["title"] = row["title"]
                                    previous["invalidated_event"] = previous.get(
                                        "invalidated_event"
                                    ) or previous["classification"].get("event_key")
                                    previous["classification"] = {
                                        "direction": 0,
                                        "event_key": None,
                                        "reason": "Смысл публикации изменился: прежний сигнал отозван",
                                    }
                                    self.db.execute(
                                        "UPDATE articles SET body=? WHERE id=?",
                                        (json.dumps(previous, ensure_ascii=False), row["id"]),
                                    )
                                continue
                            self.db.execute(
                                "INSERT OR IGNORE INTO articles VALUES(?,?,?)",
                                (row["id"], row["first_seen"], json.dumps(row, ensure_ascii=False)),
                            )
                        status.update(initialized=True, last_ok=observed)
                    self.db.execute(
                        "INSERT OR REPLACE INTO sources VALUES(?,?)",
                        (source, json.dumps(status, ensure_ascii=False)),
                    )
                self.db.execute("COMMIT")
            except BaseException:
                self.db.execute("ROLLBACK")
                raise

    def news_snapshot(self):
        articles = [
            json.loads(r[0])
            for r in self.db.execute("SELECT body FROM articles ORDER BY seen DESC LIMIT 1000")
        ]
        health = {r[0]: json.loads(r[1]) for r in self.db.execute("SELECT id,body FROM sources")}
        return articles, health

    def tick(self):
        with self.lock:
            state = copy.deepcopy(self.state)
            revision = self.revision
        packet = market.packet()
        quote = packet["quote"]
        spec = packet["spec"]
        bars = packet["bars"]
        now = quote["t"]
        if state["quote"] and now <= state["quote"]["t"]:
            return
        cfg = TradeConfig(**state["config"]["trade"])
        book = restore_book(state) or Broker(cfg, spec)
        if state["spec"] and any(
            state["spec"].get(k) != spec[k]
            for k in ("multiplier", "tick", "maintenance", "funding_interval", "funding_offset")
        ):
            raise market.MarketError("Изменились параметры SOL контракта; счёт сохранён")
        book.spec.update(spec)
        cursor = state["funding_cursor"]
        due = []
        expected = []
        if book.position and cursor is not None:
            step = spec["funding_interval"] * 1000
            offset = spec["funding_offset"] * 1000
            first = ((cursor - offset) // step + 1) * step + offset
            mapping = {r["t"]: r for r in packet["funding"]}
            expected = [t for t in range(first, now + 1, step) if t > book.position["time"]]
            if any(t not in mapping for t in expected):
                raise market.MarketError(
                    "Ожидаем опубликованный funding: финансовый результат не выдумывается"
                )
            due = [mapping[t] for t in expected]
        settlement = market.funding_prices(due, bars)
        # Slow historical requests must never turn a stale quote into an entry.
        if int(time.time() * 1000) - quote["t"] > 2000:
            fresh = market.quote()
            if fresh["t"] <= quote["t"]:
                raise market.MarketError("Нет новой котировки после загрузки истории")
            if book.position and cursor is not None:
                latest = [
                    t for t in range(first, fresh["t"] + 1, step) if t > book.position["time"]
                ]
                if latest != expected:
                    raise market.MarketError(
                        "Новый период funding: ожидаем следующую полную загрузку"
                    )
            quote = fresh
            now = quote["t"]
        with self.lock:
            if self.revision != revision or self.shutdown.is_set():
                return
            articles, health = self.news_snapshot()
            settings = state["config"]["news"]
            trading = state["config"]["trading"]
            active = state["config"]["activity"]["profile"] == "active"
            if active:
                chosen = state["config"]["strategy"]["id"]
                # An old position retains the trend policy it entered with.
                held_rule = ((book.position or {}).get("entry_reason") or {}).get("rule")
                evaluating = (
                    "confirmed_trend"
                    if held_rule == "confirmed_trend"
                    else "mgm_weighted"
                    if held_rule == "mgm_weighted"
                    else chosen
                )
                tech = (
                    activity.evaluate(bars, now, state["config"]["signals"])
                    if evaluating == "confirmed_trend"
                    else strategies.evaluate(bars, now, evaluating, state["config"]["signals"])
                )
                if evaluating != chosen:
                    tech["candidate"] = None
            else:
                tech = technical.evaluate(bars, now)
            previous_cursor = state.get("technical_cursor")
            fresh_bar = (
                previous_cursor is not None
                and tech["bar_t"] is not None
                and tech["bar_t"] > previous_cursor
            )
            if tech["bar_t"] is not None:
                state["technical_cursor"] = max(previous_cursor or 0, tech["bar_t"])
            tech["new_bar"] = fresh_bar
            if previous_cursor is None:
                tech["candidate"] = None
                tech["reason"] = "Начальный срез: ждём новую завершённую свечу"
            state["technical"] = tech
            context_settings = {**settings, "confirmation_minutes": trading["news_bias_minutes"]}
            observed = news.confirmed_events(articles, health, now, context_settings)
            invalidated = {
                a["invalidated_event"]
                for a in articles
                if a.get("invalidated_event")
                and now - settings["max_age_minutes"] * 60000 <= a.get("updated_at", 0) <= now
            }
            contexts = {
                k: v
                for k, v in state.get("news_context", {}).items()
                if v["expires"] > now and v["event"]["id"] not in invalidated
            }
            for event in observed:
                if event["first_seen"] >= state["started_at"] and event["id"] not in invalidated:
                    expiry = min(
                        event["first_seen"] + trading["news_bias_minutes"] * 60000,
                        event["published_at"] + settings["max_age_minutes"] * 60000,
                    )
                    if expiry > now:
                        contexts[event["id"] + ":" + str(event["direction"])] = {
                            "event": event,
                            "expires": expiry,
                        }
            state["news_context"] = contexts
            bias = [v["event"] for v in contexts.values()]
            events = news.confirmed_events(articles, health, now, settings)
            events = [
                e
                for e in events
                if e["first_seen"] >= state["started_at"]
                and now - e["first_seen"] <= settings["signal_ttl_minutes"] * 60000
            ]
            bid, ask = Decimal(quote["bid"]), Decimal(quote["ask"])
            mid = (bid + ask) / 2
            spread = (ask - bid) / mid * 100
            book.fee = max(Decimal(cfg.fee), Decimal(spec["fee"]))
            book.slip = Decimal(cfg.slippage) + (ask - bid) / (ask + bid)
            state["consumed"] = {k: v for k, v in state["consumed"].items() if v > now}
            records = []
            decisions = []
            with localcontext() as context:
                context.prec = 40
                for event in due:
                    p = book.position
                    cost = (
                        p["side"]
                        * p["quantity"]
                        * Decimal(settlement[event["t"]])
                        * Decimal(event["rate"])
                    )
                    book.wallet -= cost
                    book.funding += cost
                    p["funding"] += cost
                if state.get("profile_pending"):
                    if book.position:
                        reason = position_reason(book.position)
                        tag = book.position.get("news_event")
                        row = book.close(now, mid, "profile_change")
                        row.update(entry_reason=reason, entry_news=tag)
                        records.append(row)
                    book.last_t, book.last_price = now, mid
                    state.update(book=book.to_state(), spec=spec, quote=quote, funding_cursor=now)
                    # Separate commits preserve old-session trade attribution.
                    # A crash here is resumed safely from the flat old ledger.
                    self.commit(state, records, quote)
                    self.activate_profile()
                    self.market_error = None
                    return
                # An explicit legacy recheck uses fresh equity; normal stop
                # precedence and the broker's daily rollover remain unchanged.
                if state.pop("resume_legacy_requested", False):
                    book.last_price = mid
                    book.roll_limits(now)
                    book.check_limits()
                    limits = book.limits
                    if (
                        limits
                        and limits.get("daily_halt_reason") == "legacy_unknown"
                        and not limits["total_halt"]
                    ):
                        limits.update(
                            daily_halt=False, daily_halt_reason=None, streak=0, streak_pause_until=0
                        )
                        decisions.append(
                            {
                                "t": now,
                                "kind": "legacy_pause_resumed",
                                "equity": str(book.risk_equity()),
                            }
                        )
                    else:
                        decisions.append(
                            {
                                "t": now,
                                "kind": "legacy_pause_rejected",
                                "risk": book.metrics().get("risk_status"),
                            }
                        )
                if active and book.position:
                    book.position.setdefault(
                        "exit_deadline",
                        min(
                            book.position["time"] + cfg.max_hold * 60000,
                            (book.position["time"] // 900000 + 1) * 900000,
                        ),
                    )
                # Confirmed contrary news can reduce an existing exposure. An
                # opposite new position still needs its own later price reaction.
                retracted = any(
                    a.get("invalidated_event")
                    and book.position
                    and book.position.get("news_event")
                    and a["id"] in book.position["news_event"]["article_ids"]
                    for a in articles
                )
                if retracted:
                    tag = book.position.get("news_event")
                    reason = position_reason(book.position)
                    row = book.close(now, mid, "news_retraction")
                    row.update(entry_news=tag, exit_news=None, entry_reason=reason)
                    records.append(row)
                    decisions.append({"t": now, "kind": "news_retraction", "event": tag})
                opposing = next(
                    (e for e in bias if book.position and e["direction"] != book.position["side"]),
                    None,
                )
                if opposing:
                    tag = book.position.get("news_event")
                    reason = position_reason(book.position)
                    row = book.close(now, mid, "news_reversal")
                    row.update(entry_news=tag, exit_news=opposing, entry_reason=reason)
                    records.append(row)
                    decisions.append({"t": now, "kind": "news_reversal", "event": opposing})
                if (
                    book.position
                    and trading["mode"] == "hybrid"
                    and fresh_bar
                    and trend_exit_due(book.position, tech, active)
                ):
                    tag = book.position.get("news_event")
                    reason = position_reason(book.position)
                    exit_reason = (
                        "strategy_mean_exit"
                        if reason.get("rule") == "combined_bin_h_cluc"
                        else "technical_trend_exit"
                    )
                    row = book.close(now, mid, exit_reason)
                    row.update(entry_news=tag, entry_reason=reason, exit_technical=tech)
                    records.append(row)
                    decisions.append({"t": now, "kind": exit_reason, "technical": tech})
                if records:
                    book.check_limits()
                available = [
                    e
                    for e in events
                    if state["consumed"].get(e["id"] + ":" + str(e["direction"]), 0) <= now
                ]
                mixed = len({e["direction"] for e in bias}) > 1
                if mixed:
                    available = []
                if state["arm"] and not any(
                    e["id"] == state["arm"]["event"]["id"]
                    and e["direction"] == state["arm"]["event"]["direction"]
                    for e in available
                ):
                    state["arm"] = None
                if state["arm"] and now > state["arm"]["expires"]:
                    state["arm"] = None
                if (
                    state["entries_enabled"]
                    and not book.position
                    and not state["arm"]
                    and available
                ):
                    event = available[0]
                    # A large move since publication is not a fresh opportunity.
                    reference = next(
                        (b.o for b in bars if b.t <= event["published_at"] < b.t + 60000), None
                    )
                    if reference is not None and abs(mid / reference - 1) * 100 <= Decimal(
                        settings["max_move_pct"]
                    ):
                        state["arm"] = {
                            "event": event,
                            "anchor_t": now,
                            "anchor_price": str(mid),
                            "expires": event["first_seen"] + settings["signal_ttl_minutes"] * 60000,
                        }
                        decisions.append(
                            {"t": now, "kind": "armed", "event": event, "anchor_price": str(mid)}
                        )
                signal = 0
                plan = None
                message = (
                    tech["reason"]
                    if trading["mode"] == "hybrid"
                    else "Ожидаем свежее подтверждённое событие Solana"
                )
                if mixed:
                    message = "Противоречивые новости: новые входы запрещены"
                if state["arm"]:
                    okay, message = price_confirmation(state["arm"], bars, quote, settings)
                    if spread > Decimal(settings["max_spread_pct"]):
                        okay = False
                        message = "Спред SOL слишком широк для нового входа"
                    if okay and state["entries_enabled"]:
                        signal = state["arm"]["event"]["direction"]
                        plan = {
                            "kind": "news_price",
                            "direction": signal,
                            "news_event": state["arm"]["event"],
                            "id": "news:" + state["arm"]["event"]["id"],
                            "anchor_t": state["arm"]["anchor_t"],
                        }
                candidate = tech["candidate"] if fresh_bar and trading["mode"] == "hybrid" else None
                if candidate:
                    if state["consumed"].get(candidate["id"], 0) > now:
                        candidate = None
                    else:
                        # A later ATR change must not resurrect the same setup,
                        # including when its first opportunity was blocked.
                        if candidate["rule"] != "paper_cadence":
                            state["consumed"][candidate["id"]] = now + 86400000
                if candidate and state["entries_enabled"] and not book.position and plan is None:
                    contrary = [e for e in bias if e["direction"] != candidate["direction"]]
                    if mixed or contrary:
                        message = "Рыночный вход заблокирован подтверждённым новостным фоном"
                        decisions.append(
                            {
                                "t": now,
                                "kind": "technical_blocked_news",
                                "technical": candidate,
                                "events": bias,
                            }
                        )
                    elif spread > Decimal(settings["max_spread_pct"]):
                        message = "Спред SOL слишком широк для рыночного входа"
                        decisions.append(
                            {"t": now, "kind": "technical_blocked_spread", "technical": candidate}
                        )
                    elif abs(mid / Decimal(candidate["features"]["close"]) - 1) * 100 > Decimal(
                        ".5"
                    ):
                        message = "Цена ушла более чем на 0,5% от рыночного сигнала"
                        decisions.append(
                            {"t": now, "kind": "technical_blocked_drift", "technical": candidate}
                        )
                    else:
                        aligned = next(
                            (e for e in bias if e["direction"] == candidate["direction"]), None
                        )
                        signal = candidate["direction"]
                        plan = {
                            **candidate,
                            "kind": "technical_news" if aligned else "technical",
                            "news_event": aligned,
                        }
                        message = (
                            "Рыночный сигнал и новости одного направления"
                            if aligned
                            else "Рыночный сигнал без обязательной новости"
                        )
                if active and plan and not book.position:
                    slot = now // 900000
                    if (
                        state.get("activity_last_slot") is not None
                        and slot <= state["activity_last_slot"]
                    ):
                        message = "В этой 15-минутной свече вход уже был; ждём следующую"
                        signal, plan = 0, None
                    elif plan["kind"] != "news_price" and plan.get("rule") != "paper_cadence":
                        # A rough volatility budget must exceed observed round-trip
                        # costs. This is a filter, not an expected-profit estimate.
                        costs_pct = (2 * book.fee + 2 * book.slip) * 100
                        movement = Decimal(
                            plan["features"].get(
                                "range_15m_pct", str(Decimal(plan["features"]["atr14_pct"]) * 4)
                            )
                        )
                        if movement < costs_pct * Decimal("1.5"):
                            message = (
                                "Наблюдённый диапазон за 15 минут слишком мал относительно затрат"
                            )
                            decisions.append(
                                {"t": now, "kind": "active_blocked_costs", "technical": plan}
                            )
                            signal, plan = 0, None
                tag = (
                    book.position.get("news_event")
                    if book.position
                    else (plan.get("news_event") if plan else None)
                )
                reason = position_reason(book.position) if book.position else plan
                if active and plan:
                    plan["timing_policy"] = "full-15m-entry-12m-hold-v1"
                # Signal and all evidence predate this observed quote. Fills use
                # bid/ask plus adverse slippage at now, never a past candle open.
                management = state["config"]["management"]
                atr_pct = Decimal((tech.get("features") or {}).get("atr14_pct", "0"))
                book.entry_management = management_plan(management, atr_pct, book.fee, book.slip)
                if plan and book.entry_management is None:
                    message = "Затраты слишком велики для допустимого SOL-стопа"
                    decisions.append({"t": now, "kind": "active_blocked_costs", "reason": message})
                    signal, plan = 0, None
                book.pending = signal
                tick = SimpleNamespace(t=now, o=mid, h=mid, l=mid, c=mid)
                for row in book.process(tick, 0, "0"):
                    row["entry_news"] = tag
                    row["entry_reason"] = reason
                    records.append(row)
                book.update_protection(mid)
                opened = (book.position and book.position["time"] == now) or any(
                    r["entry_time"] == now for r in records
                )
                if opened and plan:
                    if active:
                        state["activity_last_slot"] = now // 900000
                    event = plan.get("news_event")
                    if book.position:
                        book.position["news_event"] = event
                        plan["risk_plan"] = {
                            "planned_loss_usdt": book.position.get("planned_risk_usdt"),
                            "initial_stop_fraction": book.entry_management["stop_fraction"],
                            "initial_stop": str(book.position.get("protective_stop")),
                            "target": str(
                                book.position["entry"]
                                * (
                                    1
                                    + book.position["side"]
                                    * book.position.get("target_fraction", book.take)
                                )
                            ),
                            "fee_rate": str(book.fee),
                            "slippage_with_halfspread": str(book.slip),
                        }
                        book.position["entry_reason"] = plan
                        if active:
                            book.position["exit_deadline"] = now + cfg.max_hold * 60000
                    if event:
                        state["consumed"][event["id"] + ":" + str(event["direction"])] = (
                            now + 86400000
                        )
                    decisions.append(
                        {
                            "t": now,
                            "kind": "opened",
                            "session": state["session"],
                            "event": event,
                            "quote": quote,
                            "entry_reason": plan,
                        }
                    )
                    state["arm"] = None
                elif plan:
                    message = book.last_entry_block or "Вход запрещён текущими ограничениями"
                    decisions.append(
                        {
                            "t": now,
                            "kind": "entry_blocked_risk_or_cooldown",
                            "entry_reason": plan,
                            "reason": message,
                        }
                    )
                last_check = state.get("last_entry_check") or {}
                carry_check = bool(
                    not fresh_bar
                    and previous_cursor is not None
                    and not records
                    and not plan
                    and not book.position
                    and not state["arm"]
                    and last_check.get("bar_t") == tech["bar_t"]
                    and last_check.get("reason")
                    in (
                        "entry_blocked_risk_or_cooldown",
                        "technical_blocked_spread",
                        "technical_blocked_news",
                        "active_blocked_costs",
                    )
                )
                if carry_check:
                    message = last_check["detail"]
                if active and book.position:
                    message = "Активная PAPER-позиция: стоп, цель или закрытие не позднее 12 минут"
                elif active and state.get("activity_last_slot") == now // 900000:
                    message = "В этой 15-минутной свече вход уже был; ждём следующую"
                if not state["entries_enabled"]:
                    message = "Новые входы выключены; новости и защита открытой позиции работают"
                if book.metrics().get("risk_status") not in (None, "active"):
                    message = "Сработало ограничение риска: " + book.metrics()["risk_status"]
                book.curve = book.curve[-600:]
                book.history = book.history[-200:]
                state.update(
                    book=book.to_state(),
                    spec=spec,
                    quote=quote,
                    funding_cursor=now,
                    execution_fee=str(book.fee),
                    execution_slippage=str(book.slip),
                    message=message,
                )
                risk = book.metrics().get("risk_status", "active")
                code = (
                    risk
                    if risk != "active"
                    else "paused"
                    if not state["entries_enabled"]
                    else "holding"
                    if book.position
                    else "quarter_used"
                    if state.get("activity_last_slot") == now // 900000
                    else (decisions[-1]["kind"] if decisions else "no_signal")
                )
                if (
                    carry_check
                    and risk == "active"
                    and state["entries_enabled"]
                    and not book.position
                    and state.get("activity_last_slot") != now // 900000
                ):
                    code = last_check["reason"]
                if fresh_bar:
                    state["last_entry_check"] = {
                        "t": now,
                        "bar_t": tech["bar_t"],
                        "reason": code,
                        "detail": message,
                    }
                window = {
                    "software_version": VERSION,
                    "slot_t": now // 900000 * 900000,
                    "slot_end": (now // 900000 + 1) * 900000,
                    "first_observed": now,
                    "last_observed": now,
                    "entries": int(state.get("activity_last_slot") == now // 900000),
                    "reason": code,
                    "detail": message,
                }
                evidence = [
                    (
                        "bar",
                        b.t,
                        now,
                        dict(zip(("t", "o", "h", "l", "c", "v"), b.row(), strict=True)),
                    )
                    for b in bars
                ]
                evidence += [("funding", r["t"], now, r) for r in packet["funding"]]
                evidence.append(
                    (
                        "spec",
                        now,
                        now,
                        {
                            **spec,
                            "execution_fee": str(book.fee),
                            "execution_slippage": str(book.slip),
                            "settlements": settlement,
                        },
                    )
                )
                self.commit(
                    state,
                    records,
                    quote,
                    decisions,
                    window=window if active else None,
                    evidence=evidence,
                )
                self.market_error = None
                self.last_market_attempt = int(time.time() * 1000)

    def start_workers(self):
        def loop(action, interval, kind):
            while not self.shutdown.is_set():
                start = time.monotonic()
                try:
                    action()
                except Exception as exc:
                    LOGGER.exception("%s poll failed", kind)
                    if kind == "market":
                        with self.lock:
                            self.market_error = str(exc)
                            self.last_market_attempt = int(time.time() * 1000)
                self.shutdown.wait(max(0, interval - (time.monotonic() - start)))

        for action, period, kind in (
            (self.poll_news, self.state["config"]["news_poll_seconds"], "news"),
            (self.tick, self.state["config"]["market_poll_seconds"], "market"),
        ):
            thread = threading.Thread(target=loop, args=(action, period, kind), daemon=True)
            self.threads.append(thread)
            thread.start()

    def status(self):
        with self.lock:
            book = restore_book(self.state)
            articles, health = self.news_snapshot()
            try:
                disk_config = read(self.settings)
                if self.state.get("strategy_override"):
                    disk_config["strategy"] = self.state["config"]["strategy"]
                # This release fixes the requested account profile even when a
                # patch leaves the original settings.json in place.
                if (
                    self.state["config"]["trade"]["balance"] == "100"
                    and self.state["config"]["trade"]["leverage"] == 5
                ):
                    disk_config["trade"].update(balance="100", leverage=5)
                changed = digest(disk_config) != self.state["config_sha256"]
            except Exception:
                changed = True
            return {
                "application": "gate-sol-news",
                "software_version": VERSION,
                "mode": "paper",
                "real_orders": False,
                "entries_enabled": self.state["entries_enabled"],
                "session": self.state["session"],
                "quote": self.state["quote"],
                "spec": self.state["spec"],
                "execution_fee": self.state.get("execution_fee"),
                "execution_slippage": self.state.get("execution_slippage"),
                "config": self.state["config"],
                "strategies": strategies.CATALOG,
                "summary": book.metrics() if book else None,
                "activity": self.activity_status(),
                "position": book.to_state()["position"] if book else None,
                "history": [
                    json.loads(r[0])
                    for r in self.db.execute(
                        "SELECT body FROM trades WHERE session=? ORDER BY exit_t DESC LIMIT 100",
                        (self.state["session"],),
                    )
                ],
                "news": articles[:150],
                "sources": {
                    s: {**news.SOURCES[s], **health.get(s, {})}
                    for s in self.state["config"]["sources"]
                },
                "news_health": news.readiness(
                    health, int(time.time() * 1000), self.state["config"]["sources"]
                ),
                "decisions": [
                    json.loads(r[0])
                    for r in self.db.execute(
                        "SELECT body FROM decisions ORDER BY id DESC LIMIT 100"
                    )
                ],
                "arm": self.state["arm"],
                "technical": self.state.get("technical"),
                "news_context": list(self.state.get("news_context", {}).values()),
                "message": self.state["message"],
                "error": self.market_error,
                "settings_changed": changed,
                "profile_pending": self.state.get("profile_pending", False),
                "archives": [
                    {
                        "id": row[0],
                        "started_at": json.loads(row[1])["started_at"],
                        "session": json.loads(row[1])["session"],
                    }
                    for row in self.db.execute(
                        "SELECT id,body FROM archives ORDER BY id DESC LIMIT 50"
                    )
                ],
                "last_market_attempt": self.last_market_attempt,
                "data_directory": str(self.directory),
                "news_rules": "headline heuristics; not a fact checker",
                "funding_model": "Published rate × trade candle open at settlement, a mark-price approximation",
            }

    def activity_status(self):
        now = int(time.time() * 1000)
        session = self.state["session"]
        closed = self.db.execute(
            "SELECT COUNT(*) FROM trades WHERE session=? AND exit_t>? AND exit_t<=?",
            (session, now - 3600000, now),
        ).fetchone()[0]
        opened = self.db.execute(
            "SELECT COUNT(*) FROM trades WHERE session=? AND entry_t>? AND entry_t<=?",
            (session, now - 3600000, now),
        ).fetchone()[0]
        position = (self.state.get("book") or {}).get("position")
        if position and now - 3600000 < position["time"] <= now:
            opened += 1
        active = self.state["config"]["activity"]["profile"] == "active"
        last_slot = self.state.get("activity_last_slot")
        next_t = (last_slot + 1) * 900000 if last_slot is not None else now
        return {
            "profile": self.state["config"]["activity"]["profile"],
            "target_closed_per_hour": 4,
            "closed_last_hour": closed,
            "opened_last_hour": opened,
            "target_met": closed >= 4,
            "next_window_at": max(now, next_t) if active else None,
            "message": self.market_error or self.state["message"],
            "frequency_guaranteed": False,
            "streak_pause_until": ((self.state.get("book") or {}).get("limits") or {}).get(
                "streak_pause_until", 0
            ),
            "legacy_pause": ((self.state.get("book") or {}).get("limits") or {}).get(
                "daily_halt_reason"
            )
            == "legacy_unknown",
            "resume_pending": self.state.get("resume_legacy_requested", False),
            "windows": [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT body FROM activity_windows WHERE session=? ORDER BY slot DESC LIMIT 12",
                    (session,),
                )
            ],
        }

    def resume_legacy_pause(self):
        """Explicit local action: unknown old halt is rechecked at a fresh quote."""
        with self.lock:
            book = restore_book(self.state)
            if (
                not book
                or not book.limits
                or book.limits.get("daily_halt_reason") != "legacy_unknown"
            ):
                raise ValueError("Старой блокировки без причины нет; текущие лимиты не сброшены")
            if book.position or book.limits["total_halt"]:
                raise ValueError("Открытая позиция или общий стоп: разблокировка запрещена")
            state = copy.deepcopy(self.state)
            state.update(
                resume_legacy_requested=True,
                message="Ожидаем свежую котировку для повторной проверки старой паузы",
            )
            self.commit(state)

    def export_research(self):
        """User-initiated local export; never includes control tokens or keys."""
        with self.lock:
            session = self.state["session"]
            data = {
                "schema": 1,
                "contract": "SOL_USDT",
                "session": session,
                "exported_at": int(time.time() * 1000),
                "config": copy.deepcopy(self.state["config"]),
                "book": copy.deepcopy(self.state["book"]),
                "news_backtest_supported": False,
                "note": "Observed quotes and first-observed closed bars; no inferred intra-poll prices",
                "truncated": {},
            }
            for kind, limit in (("bar", 10000), ("funding", 1000), ("spec", 20000)):
                rows = self.db.execute(
                    "SELECT observed_t,body FROM market_evidence WHERE session=? AND kind=? ORDER BY t DESC LIMIT ?",
                    (session, kind, limit),
                ).fetchall()
                data[kind] = [
                    {"observed_at": r[0], "data": json.loads(r[1])} for r in reversed(rows)
                ]
                data["truncated"][kind] = (
                    self.db.execute(
                        "SELECT COUNT(*) FROM market_evidence WHERE session=? AND kind=?",
                        (session, kind),
                    ).fetchone()[0]
                    > limit
                )
            for table, key, order, limit in (
                ("quotes", "quotes", "t", 20000),
                ("trades", "trades", "exit_t", 5000),
            ):
                rows = self.db.execute(
                    f"SELECT body FROM {table} WHERE session=? ORDER BY {order} DESC LIMIT ?",
                    (session, limit),
                ).fetchall()
                data[key] = [json.loads(r[0]) for r in reversed(rows)]
                data["truncated"][key] = (
                    self.db.execute(
                        f"SELECT COUNT(*) FROM {table} WHERE session=?", (session,)
                    ).fetchone()[0]
                    > limit
                )
            return json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2).encode("utf-8")

    def export_activity_csv(self):
        with self.lock:
            rows = [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT body FROM activity_windows WHERE session=? ORDER BY slot",
                    (self.state["session"],),
                )
            ]
        out = io.StringIO(newline="")
        writer = csv.DictWriter(
            out,
            fieldnames=[
                "software_version",
                "slot_t",
                "slot_end",
                "first_observed",
                "last_observed",
                "entries",
                "reason",
                "detail",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)
        return out.getvalue().encode("utf-8-sig")

    def set_strategy(self, strategy):
        if not isinstance(strategy, str) or strategy not in strategies.CATALOG:
            raise ValueError("Неизвестная стратегия PAPER")
        with self.lock:
            if self.state.get("profile_pending"):
                raise ValueError("Дождитесь завершения перехода счёта")
            if (self.state.get("book") or {}).get("position"):
                raise ValueError("Дождитесь закрытия позиции перед сменой стратегии")
            if self.state["config"]["activity"]["profile"] != "active":
                raise ValueError("Сначала выберите активный профиль")
            if strategy == self.state["config"]["strategy"]["id"]:
                return
            state = copy.deepcopy(self.state)
            state["config"]["strategy"] = {"id": strategy, "selection_revision": 2}
            state["strategy_override"] = True
            state["config_sha256"] = digest(state["config"])
            state.update(
                technical_cursor=None,
                technical=None,
                arm=None,
                message="Стратегия изменена; ждём новую свечу. Счёт и история сохранены",
            )
            state.pop("last_entry_check", None)
            self.commit(state)

    def set_activity(self, profile):
        if profile not in ("active", "retest"):
            raise ValueError("Неизвестный профиль активности")
        with self.lock:
            if self.state.get("profile_pending"):
                raise ValueError("Дождитесь завершения перехода на 100 USDT / 5×")
            state = copy.deepcopy(self.state)
            state["config"]["activity"]["profile"] = profile
            if profile == "retest":
                state["config"]["trade"].update(max_hold=120, cooldown=15, daily_entries=4)
            state["config"] = apply_activity(state["config"])
            state["config_sha256"] = digest(state["config"])
            book = restore_book(state)
            if book:
                entries = [r["entry_time"] for r in book.history]
                if book.position:
                    entries.append(book.position["time"])
                if entries:
                    state["activity_last_slot"] = max(
                        state.get("activity_last_slot") or 0, max(entries) // 900000
                    )
                apply_book_config(book, state["config"]["trade"])
                state["book"] = book.to_state()
            state.update(
                technical_cursor=None,
                technical=None,
                arm=None,
                message="Профиль изменён; ждём новую свечу. Кошелёк и лимиты потерь сохранены",
            )
            self.commit(state)

    def set_entries(self, value):
        if type(value) is not bool:
            raise ValueError("Некорректный режим")
        with self.lock:
            if self.state.get("profile_pending"):
                raise ValueError(
                    "Сначала дождитесь перехода на счёт 100 USDT / 5× по свежей котировке"
                )
            state = copy.deepcopy(self.state)
            state["entries_enabled"] = value
            state["arm"] = None
            self.commit(state)

    def reset(self, confirmation):
        with self.lock:
            book = restore_book(self.state)
            if self.state["entries_enabled"] or (book and book.position):
                raise ValueError("Выключите входы; дождитесь закрытия открытой позиции")
            if confirmation != "ARCHIVE_SOL_PAPER":
                raise ValueError("Требуется явная архивация счёта")
            state = self.new_state(read(self.settings), requested_profile=True)
            state["entries_enabled"] = False
            self.commit(state, archive=True)

    def export_csv(self, archive_id=None):
        with self.lock:
            session = self.state["session"]
            if archive_id is not None:
                if (
                    not isinstance(archive_id, str)
                    or not archive_id.isdecimal()
                    or len(archive_id) > 12
                ):
                    raise ValueError("Неизвестный архив")
                archived = self.db.execute(
                    "SELECT body FROM archives WHERE id=?", (int(archive_id),)
                ).fetchone()
                if not archived:
                    raise ValueError("Неизвестный архив")
                session = json.loads(archived[0])["session"]
            rows = [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT body FROM trades WHERE session=? ORDER BY exit_t",
                    (session,),
                )
            ]
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        fields = [
            "entry_time",
            "exit_time",
            "side",
            "quantity",
            "entry_price",
            "exit_price",
            "net_pnl",
            "fees",
            "funding",
            "reason",
        ]
        writer.writerow([*fields, "entry_news_json", "exit_news_json", "entry_reason_json"])
        for row in rows:
            writer.writerow(
                [
                    *[row[k] for k in fields],
                    json.dumps(row.get("entry_news"), ensure_ascii=False),
                    json.dumps(row.get("exit_news"), ensure_ascii=False),
                    json.dumps(row.get("entry_reason"), ensure_ascii=False),
                ]
            )
        return out.getvalue().encode("utf-8-sig")

    def close(self):
        self.shutdown.set()
        for thread in self.threads:
            thread.join(timeout=15)
        if not any(t.is_alive() for t in self.threads):
            with self.lock:
                self.db.close()
