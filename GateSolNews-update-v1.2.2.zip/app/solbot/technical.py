"""Fixed, causal market setups on complete 5m bars. No news is required.

Finite SMA/Cutler-RSI windows avoid reseeding recursive indicators on every poll.
The result describes a completed bar; actual entry remains a newly observed quote.
"""

from decimal import Decimal


def evaluate(bars, now):
    grouped = {}
    for bar in bars:
        if bar.t + 60000 <= now:
            grouped.setdefault(bar.t // 300000 * 300000, []).append(bar)
    completed = []
    for start, parts in sorted(grouped.items()):
        parts = sorted(parts, key=lambda b: b.t)
        if (
            len(parts) == 5
            and [b.t for b in parts] == list(range(start, start + 300000, 60000))
            and start + 300000 <= now
        ):
            completed.append(
                {
                    "t": start,
                    "o": parts[0].o,
                    "c": parts[-1].c,
                    "h": max(b.h for b in parts),
                    "l": min(b.l for b in parts),
                    "v": sum((b.v for b in parts), Decimal(0)),
                }
            )
    out = {
        "bar_t": completed[-1]["t"] if completed else None,
        "bar_end": completed[-1]["t"] + 300000 if completed else None,
        "candidate": None,
        "trend": 0,
        "reason": "Прогрев: нужны 22 полные пятиминутные свечи",
        "features": None,
    }
    if len(completed) < 22:
        return out
    rows = completed[-22:]
    if any(b["t"] - a["t"] != 300000 for a, b in zip(rows, rows[1:], strict=False)):
        out["reason"] = "Неполная последовательность пятиминутных свечей"
        return out
    current = rows[-1]
    fast = sum((b["c"] for b in rows[-9:]), Decimal(0)) / 9
    slow = sum((b["c"] for b in rows[-21:]), Decimal(0)) / 21
    previous_slow = sum((b["c"] for b in rows[-22:-1]), Decimal(0)) / 21
    changes = [b["c"] - a["c"] for a, b in zip(rows[-15:-1], rows[-14:], strict=True)]
    gains = sum((max(d, Decimal(0)) for d in changes), Decimal(0))
    losses = sum((max(-d, Decimal(0)) for d in changes), Decimal(0))
    rsi = 100 - 100 / (1 + gains / losses) if losses else Decimal(100) if gains else Decimal(50)
    ranges = [
        max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"]))
        for a, b in zip(rows[-15:-1], rows[-14:], strict=True)
    ]
    atr = sum(ranges, Decimal(0)) / 14 / current["c"] * 100
    volume = sum((b["v"] for b in rows[-11:-1]), Decimal(0)) / 10
    ratio = current["v"] / volume if volume else Decimal(0)
    trend = (
        1
        if fast > slow and current["c"] > slow
        else -1
        if fast < slow and current["c"] < slow
        else 0
    )
    out.update(
        trend=trend,
        features={
            "sma9": str(fast),
            "sma21": str(slow),
            "rsi14_cutler": str(rsi),
            "atr14_pct": str(atr),
            "volume_ratio": str(ratio),
            "close": str(current["c"]),
        },
    )
    if now - out["bar_end"] > 90000:
        out["reason"] = "Закрытая свеча устарела для нового входа"
        return out
    if not Decimal(".15") <= atr <= Decimal("2"):
        out["reason"] = "Волатильность вне рабочего диапазона 0,15–2%"
        return out
    if not Decimal(".8") <= ratio <= Decimal("3"):
        out["reason"] = "Объём вне диапазона 0,8–3×: слабый рынок или всплеск"
        return out
    side = trend
    momentum = current["c"] - rows[-4]["c"]
    if not side or side * momentum <= 0 or side * (slow - previous_slow) <= 0:
        out["reason"] = "Тренд и движение за 15 минут не согласованы"
        return out
    if not (50 <= rsi <= 70 if side == 1 else 30 <= rsi <= 50):
        out["reason"] = "RSI вне диапазона 50–70 LONG / 30–50 SHORT"
        return out
    atr_price = atr * current["c"] / 100
    out["reason"] = "Ждём возврат к уровню после пробоя; вход на самом пробое запрещён"
    # A breakout must precede the entry candle by 1–3 COMPLETE bars.
    # All levels and volume baselines use only data before that breakout.
    for age in (1, 2, 3):
        index = len(rows) - 1 - age
        breakout = rows[index]
        history = rows[index - 6 : index]
        level = max(b["h"] for b in history) if side == 1 else min(b["l"] for b in history)
        volume_base = sum((b["v"] for b in rows[index - 10 : index]), Decimal(0)) / 10
        breakout_ratio = breakout["v"] / volume_base if volume_base else Decimal(0)
        if not Decimal("1.1") <= breakout_ratio <= 4:
            continue
        if side * (breakout["c"] - level) <= 0 or side * (breakout["c"] - breakout["o"]) <= 0:
            continue
        intervening = rows[index + 1 : -1]
        if any(side * (b["c"] - level) < -atr_price / 4 for b in intervening):
            continue

        # One retest, one opportunity: a previous rejection consumes this setup.
        def rejection(b, level=level):
            extreme = b["l"] if side == 1 else b["h"]
            return (
                abs(extreme - level) <= atr_price / 4
                and 0 < side * (b["c"] - level) <= atr_price * Decimal(".75")
                and side * (b["c"] - b["o"]) > 0
            )

        if any(rejection(b) for b in intervening) or not rejection(current):
            continue
        out["candidate"] = {
            "id": f"technical:{breakout['t']}:{side}:retest",
            "direction": side,
            "rule": "breakout_retest",
            "setup_t": breakout["t"],
            "level": str(level),
            "bar_t": current["t"],
            "bar_end": out["bar_end"],
            "features": out["features"],
        }
        out["reason"] = "Пробой и последующий возврат к уровню подтверждены"
        break
    return out
