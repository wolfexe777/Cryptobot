"""Bounded RSS/Atom parsing and explicit event rules, never an instruction engine.

These are headline heuristics, not a fact checker or a predictive language model.
Publication time and the time first observed by this process are kept separately.
"""

import hashlib
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser

SOURCES = {
    "agave_github": {
        "name": "Agave · GitHub releases",
        "url": "https://github.com/anza-xyz/agave/releases.atom",
        "host": "github.com",
        "path_prefix": "/anza-xyz/agave/releases",
        "primary": False,
        "kind": "release",
        "can_signal": False,
    },
    "firedancer_github": {
        "name": "Firedancer · GitHub releases",
        "url": "https://github.com/firedancer-io/firedancer/releases.atom",
        "host": "github.com",
        "path_prefix": "/firedancer-io/firedancer/releases",
        "primary": False,
        "kind": "release",
        "can_signal": False,
    },
    "solana_status": {
        "name": "Solana Status · mainnet",
        "url": "https://status.solana.com/history.atom",
        "host": "status.solana.com",
        "primary": True,
        "kind": "publisher",
    },
    "google_news": {
        "name": "Google News · Solana",
        "url": "https://news.google.com/rss/search?q=Solana+OR+SOL+when:1d&hl=en-US&gl=US&ceid=US:en",
        "host": "news.google.com",
        "primary": False,
        "kind": "aggregator",
    },
    "bing_news": {
        "name": "Bing News · Solana",
        "url": "https://www.bing.com/news/search?q=Solana&format=rss&setlang=en-US&mkt=en-US",
        "host": "bing.com",
        "path_prefix": "/news/",
        "primary": False,
        "kind": "aggregator",
    },
    "decrypt": {
        "name": "Decrypt",
        "url": "https://decrypt.co/feed",
        "host": "decrypt.co",
        "primary": False,
    },
    "theblock": {
        "name": "The Block",
        "url": "https://www.theblock.co/rss.xml",
        "host": "theblock.co",
        "primary": False,
    },
    "coindesk": {
        "name": "CoinDesk",
        "url": "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "host": "coindesk.com",
        "primary": False,
    },
    "cointelegraph": {
        "name": "Cointelegraph",
        "url": "https://cointelegraph.com/rss",
        "host": "cointelegraph.com",
        "primary": False,
    },
}

# Official mirrors belong to one publisher, never two independent votes.
PUBLISHERS = {
    "status.solana.com": ("solana_project", "Solana"),
    "solana.com": ("solana_project", "Solana"),
    "coindesk.com": ("coindesk", "CoinDesk"),
    "cointelegraph.com": ("cointelegraph", "Cointelegraph"),
    "decrypt.co": ("decrypt", "Decrypt"),
    "theblock.co": ("theblock", "The Block"),
    "reuters.com": ("reuters", "Reuters"),
    "apnews.com": ("ap", "Associated Press"),
    "cnbc.com": ("cnbc", "CNBC"),
    "bloomberg.com": ("bloomberg", "Bloomberg"),
}


def publisher_for(url):
    try:
        parsed = urllib.parse.urlsplit(url)
        if (
            parsed.scheme != "https"
            or parsed.username is not None
            or parsed.password is not None
            or parsed.port not in (None, 443)
        ):
            return None
        host = parsed.hostname or ""
        return next(
            (
                value
                for domain, value in PUBLISHERS.items()
                if host == domain or host.endswith("." + domain)
            ),
            None,
        )
    except ValueError:
        return None


class NewsError(RuntimeError):
    pass


def allowed_url(url, source):
    try:
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname or ""
        expected = SOURCES[source]["host"]
        return (
            parsed.scheme == "https"
            and (host == expected or host.endswith("." + expected))
            and parsed.username is None
            and parsed.password is None
            and parsed.port in (None, 443)
            and parsed.path.startswith(SOURCES[source].get("path_prefix", "/"))
        )
    except ValueError:
        return False


class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(value, limit=3000):
    parser = Text()
    parser.feed(value[:12000])
    return " ".join(" ".join(parser.parts).split())[:limit]


def fingerprint(title):
    return hashlib.sha256(re.sub(r"[^a-z0-9]+", " ", title.lower()).strip().encode()).hexdigest()


def classify(title, summary, source):
    title = title.lower()
    body = title + " " + summary.lower()
    result = {
        "direction": 0,
        "event_key": None,
        "reason": "Нет однозначного фундаментального события",
    }
    if source == "solana_status" and re.search(
        r"\b(?:resolved|restored|incident closed)\b", summary.lower()[:500]
    ):
        return {
            **result,
            "reason": "Официальный статус сообщает о восстановлении; без нового входа",
        }
    if not (re.search(r"\b(?:solana|sol)\b", body) or SOURCES[source]["primary"]):
        return {**result, "reason": "Нет связи с Solana"}
    if (
        re.search(
            r"\b(?:could|may|might|will|would|to approve|to list|set to|rumou?r|reportedly|unconfirmed|alleged|propos(?:al|ed|es|ing)|plans?|expected|consider(?:ing|s)?|seeks?|filed|application|denies|denied|not|fake|prediction|forecast)\b",
            title,
        )
        or "?" in title
    ):
        return {**result, "reason": "Слух, прогноз, отрицание или ещё не принятое решение"}
    if re.search(r"\b(?:price|rallies|surges|soars|jumps|plunges|tumbles|rally|sell-off)\b", title):
        return {**result, "reason": "Описание уже прошедшего движения цены"}
    if re.search(
        r"\b(?:fixed|fixes|patched|resolved|mitigated|historical|simulation|testnet|devnet)\b", title
    ):
        return {**result, "reason": "Устранённое, историческое или тестовое событие"}
    if (
        source == "solana_status"
        and re.search(r"\bmainnet(?:[ -]beta)?\b", title)
        and not re.search(r"\b(?:rpc|explorer|wallet|devnet|testnet)\b", title)
        and re.search(r"\b(?:outage|halted|stalled|block production stopped)\b", title)
    ):
        return {
            "direction": -1,
            "event_key": "security:sol",
            "reason": "Официальный статус сообщает об остановке mainnet Solana",
        }
    asset = bool(re.search(r"\b(?:solana|sol)\b", title))
    exchanges = [
        name
        for name in ("coinbase", "binance", "kraken", "gate", "okx", "bybit", "bitstamp")
        if re.search(r"\b" + name + r"\b", title)
    ]
    jurisdiction = re.search(r"\b(?:eu|us|uk|japan|india|australia|germany|france)\b", title)
    if (
        asset
        and jurisdiction
        and re.search(
            r"\b(?:bans|ban on) (?:solana|sol)\b|\b(?:solana|sol) (?:trading )?(?:is |has been )?banned\b",
            title,
        )
    ):
        return {
            "direction": -1,
            "event_key": "regulation:" + jurisdiction[0],
            "reason": "Заголовок сообщает о запрете Solana в указанной юрисдикции",
        }
    if asset and re.search(
        r"\b(?:solana|sol)(?:['’]s)? (?:network |chain )?(?:was |is |has been )?(?:exploited|hacked|halted|critical vulnerability disclosed|suffers attack)\b|\b(?:funds stolen from|critical vulnerability disclosed in) (?:solana|sol)\b",
        title,
    ):
        return {
            "direction": -1,
            "event_key": "security:sol",
            "reason": "Заголовок сообщает о действующем инциденте Solana",
        }
    if (
        asset
        and exchanges
        and re.search(
            r"\b(?:delists?|delisting|removes?) (?:solana|sol)\b|\b(?:solana|sol) (?:is |was |has been )?(?:delisted|delisting|removed from trading)\b",
            title,
        )
    ):
        return {
            "direction": -1,
            "event_key": "listing:" + exchanges[0],
            "reason": "Заголовок сообщает о делистинге Solana",
        }
    if (
        asset
        and exchanges
        and re.search(
            r"\b(?:lists|listed|begins trading) (?:solana|sol)\b|\b(?:solana|sol) (?:is |now |has been )?listed on\b",
            title,
        )
    ):
        return {
            "direction": 1,
            "event_key": "listing:" + exchanges[0],
            "reason": "Заголовок сообщает о начавшемся листинге Solana",
        }
    if asset and (
        re.search(r"approves? (?:the )?(?:first )?(?:solana|sol) (?:spot )?etf", title)
        or re.search(r"(?:solana|sol) (?:spot )?etf (?:is |has been )?approved", title)
    ):
        return {
            "direction": 1,
            "event_key": "etf:sol",
            "reason": "Заголовок сообщает об одобрении Solana ETF",
        }
    if asset and re.search(
        r"\b(?:activated|activation complete|upgrade is live|upgrade completed)\b", title
    ):
        version = re.search(r"\bv\d+(?:\.\d+){1,2}\b|\b(?:firedancer|alpenglow)\b", title)
        if version or (asset and re.search(r"\b(?:solana|sol) network upgrade\b", title)):
            return {
                "direction": 1,
                "event_key": "upgrade:" + (version[0].replace(" ", "") if version else "sol"),
                "reason": "Заголовок сообщает об активации обновления сети",
            }
    return result


def parse_feed(data, source, observed_at):
    if (
        len(data) > 1024 * 1024
        or b"\x00" in data
        or re.search(rb"<!\s*(?:DOCTYPE|ENTITY)", data, re.I)
    ):
        raise NewsError("Слишком большой XML или запрещённый DTD/ENTITY")
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise NewsError("Источник не вернул корректный RSS/Atom") from exc

    def local(tag):
        return tag.rsplit("}", 1)[-1]

    if local(root.tag) not in ("rss", "feed", "RDF"):
        raise NewsError("Ответ не является RSS/Atom")
    rows = []
    for node in (n for n in root.iter() if local(n.tag) in ("item", "entry")):
        fields = {}
        url = None
        publisher_url = None
        publisher_label = None
        for item in node:
            key = local(item.tag)
            if key.lower() == "source":
                publisher_url = item.attrib.get("url")
                publisher_label = plain("".join(item.itertext()), 100)
            if (
                key == "link"
                and item.attrib.get("href")
                and item.attrib.get("rel", "alternate") == "alternate"
            ):
                url = item.attrib["href"]
            fields.setdefault(key, "".join(item.itertext()).strip())
        title = plain(fields.get("title", ""), 500)
        url = url or fields.get("link", "")
        if not title or not allowed_url(url, source):
            continue
        kind = SOURCES[source].get("kind", "publisher")
        publisher = publisher_for(url) if kind == "publisher" else None
        origin_url = None
        if kind == "aggregator":
            if source == "bing_news":
                origin_url = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).get(
                    "url", [None]
                )[0]
                publisher = publisher_for(origin_url or "")
            else:
                publisher = publisher_for(publisher_url or "")
            if publisher_label and title.casefold().endswith((" - " + publisher_label).casefold()):
                title = title[: -(len(publisher_label) + 3)].rstrip()
        parsed = urllib.parse.urlsplit(url)
        query = urllib.parse.urlencode(
            [
                (k, v)
                for k, v in urllib.parse.parse_qsl(parsed.query)
                if not k.lower().startswith("utm_") and k.lower() not in ("fbclid", "gclid", "ref")
            ]
        )
        canonical = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, query, ""))
        stamp = fields.get("pubDate") or fields.get("published") or fields.get("date")
        time_kind = "published" if stamp else "missing"
        if not stamp and fields.get("updated"):
            stamp = fields["updated"]
            time_kind = "updated_only"
        published = None
        if stamp:
            try:
                date = parsedate_to_datetime(stamp)
            except (ValueError, TypeError):
                try:
                    date = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
                except ValueError:
                    date = None
            if date and date.tzinfo is not None:
                published = int(date.astimezone(timezone.utc).timestamp() * 1000)
        summary = plain(
            fields.get("description") or fields.get("summary") or fields.get("encoded") or ""
        )
        identifier = hashlib.sha256((source + "|" + canonical).encode()).hexdigest()
        classification = classify(title, summary, source)
        can_signal = SOURCES[source].get("can_signal", True) and time_kind == "published"
        if kind == "release":
            classification = {
                "direction": 0,
                "event_key": None,
                "reason": "Релиз программного обеспечения: наблюдение, без торгового сигнала",
            }
        elif kind == "aggregator" and publisher is None:
            can_signal = False
            classification = {
                "direction": 0,
                "event_key": None,
                "reason": "Агрегатор: исходный издатель не определён или не входит в список",
            }
        rows.append(
            {
                "id": identifier,
                "source": source,
                "title": title,
                "url": canonical,
                "published_at": published,
                "first_seen": observed_at,
                "fingerprint": fingerprint(title),
                "classification": classification,
                "publisher": publisher[0] if publisher else source,
                "publisher_name": publisher[1] if publisher else SOURCES[source]["name"],
                "primary": SOURCES[source]["primary"] and kind == "publisher",
                "can_signal": can_signal,
                "time_kind": time_kind,
                "origin_url": origin_url,
            }
        )
        if len(rows) >= 100:
            break
    return rows


def fetch(source, timeout=20):
    class Redirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, msg, headers, url):
            if not allowed_url(url, source):
                raise NewsError("Редирект за пределы издателя отклонён")
            return super().redirect_request(request, fp, code, msg, headers, url)

    opener = urllib.request.build_opener(Redirect())
    request = urllib.request.Request(
        SOURCES[source]["url"],
        headers={
            "User-Agent": "GateSolNews/1.1 (+RSS paper research)",
            "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml",
        },
    )
    with opener.open(request, timeout=timeout) as response:
        if not allowed_url(response.url, source):
            raise NewsError("Неожиданный адрес ленты")
        deadline = time.monotonic() + timeout
        chunks = []
        size = 0
        reader = getattr(response, "read1", response.read)
        while size <= 1024 * 1024:
            if time.monotonic() > deadline:
                raise NewsError("Превышено время чтения ленты")
            chunk = reader(min(65536, 1024 * 1024 + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
        data = b"".join(chunks)
    observed = int(time.time() * 1000)
    return observed, parse_feed(data, source, observed)


def confirmed_events(articles, health, now, settings):
    groups = {}
    invalidated = {
        r["invalidated_event"]
        for r in articles
        if r.get("invalidated_event")
        and now - settings["max_age_minutes"] * 60000 <= r.get("updated_at", 0) <= now
    }
    baseline_copies = {
        r["fingerprint"]
        for r in articles
        if r.get("baseline")
        and r["published_at"] is not None
        and now - settings["max_age_minutes"] * 60000 <= r["published_at"] <= now
    }
    for row in articles:
        pub = row["published_at"]
        classification = row["classification"]
        status = health.get(row["source"], {})
        if (
            row.get("baseline")
            or not row.get("can_signal", SOURCES[row["source"]].get("can_signal", True))
            or row["fingerprint"] in baseline_copies
            or pub is None
            or not classification["direction"]
            or not now - settings["max_age_minutes"] * 60000 <= pub <= now + 60000
            or not now - settings["confirmation_minutes"] * 60000 <= row["first_seen"] <= now
            or status.get("error")
            or status.get("last_ok") is None
            or not 0 <= now - status["last_ok"] <= 180000
        ):
            continue
        key = classification["event_key"]
        groups.setdefault(key, []).append(row)
    result = []
    for key, rows in groups.items():
        if key in invalidated:
            continue
        if len({r["classification"]["direction"] for r in rows}) != 1:
            continue
        primary = any(r.get("primary", SOURCES[r["source"]]["primary"]) for r in rows)
        # Copied titles cannot turn one story into two confirmations.
        unique = {}
        for row in rows:
            unique.setdefault(row["fingerprint"], row)
        publishers = {r.get("publisher", r["source"]) for r in unique.values()}
        if not primary and len(publishers) < 2:
            continue
        first = min(r["first_seen"] for r in rows)
        result.append(
            {
                "id": key,
                "direction": rows[0]["classification"]["direction"],
                "first_seen": first,
                "published_at": min(r["published_at"] for r in rows),
                "article_ids": [r["id"] for r in rows],
                "titles": [r["title"] for r in rows],
                "sources": sorted({r["source"] for r in rows}),
                "publishers": sorted(publishers),
                "basis": "Первичный источник" if primary else "Два разных издателя",
            }
        )
    return sorted(result, key=lambda r: r["first_seen"], reverse=True)


def readiness(health, now, enabled):
    connected = [
        s
        for s in enabled
        if health.get(s, {}).get("last_ok") is not None
        and not health[s].get("error")
        and 0 <= now - health[s]["last_ok"] <= 180000
    ]
    event_sources = [s for s in connected if SOURCES[s].get("can_signal", True)]
    return {
        "connected": connected,
        "event_sources": event_sources,
        "release_only": bool(connected) and not event_sources,
        "message": "Доступны только релизы ПО; для новостных входов нужны публикации"
        if connected and not event_sources
        else "Есть каналы публикаций; новостной вход требует нового подтверждённого события"
        if event_sources
        else "Нет доступных новостных источников: новостные сигналы невозможны; рыночный режим работает отдельно",
    }
