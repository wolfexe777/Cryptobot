"""Causal trend confirmation; thresholds are a PAPER hypothesis, not proven alpha."""

from decimal import Decimal

from .config import SIGNALS

STRATEGY_REVISION = "sol-confirmed-trend-1"


def evaluate(bars, now, settings=None):
    settings = settings or SIGNALS
    rows = sorted((b for b in bars if b.t + 60000 <= now), key=lambda b: b.t)[-31:]
    out = {
        "bar_t": rows[-1].t if rows else None,
        "bar_end": rows[-1].t + 60000 if rows else None,
        "candidate": None,
        "trend": 0,
        "features": None,
        "reason": "Прогрев: нужны 31 непрерывная минутная свеча",
    }
    if len(rows) < 31:
        return out
    if any(b.t - a.t != 60000 for a, b in zip(rows, rows[1:], strict=False)):
        out["reason"] = "Разрыв или повтор в минутных свечах"
        return out
    c = rows[-1]
    fast = sum((b.c for b in rows[-5:]), Decimal(0)) / 5
    middle = sum((b.c for b in rows[-15:]), Decimal(0)) / 15
    slow = sum((b.c for b in rows[-30:]), Decimal(0)) / 30
    previous_slow = sum((b.c for b in rows[-31:-1]), Decimal(0)) / 30
    changes = [b.c - a.c for a, b in zip(rows[-15:-1], rows[-14:], strict=True)]
    gains = sum((max(x, Decimal(0)) for x in changes), Decimal(0))
    losses = sum((max(-x, Decimal(0)) for x in changes), Decimal(0))
    rsi = 100 - 100 / (1 + gains / losses) if losses else Decimal(100) if gains else Decimal(50)
    atr = (
        sum(
            (
                max(b.h - b.l, abs(b.h - a.c), abs(b.l - a.c))
                for a, b in zip(rows[-15:-1], rows[-14:], strict=True)
            ),
            Decimal(0),
        )
        / 14
        / c.c
        * 100
    )
    old_volume = sum((b.v for b in rows[-21:-1]), Decimal(0)) / 20
    ratio = c.v / old_volume if old_volume else Decimal(0)
    momentum = (c.c / rows[-16].c - 1) * 100
    recent_range = (max(b.h for b in rows[-15:]) - min(b.l for b in rows[-15:])) / c.c * 100
    trend = (
        1
        if fast > middle > slow and slow >= previous_slow and momentum > 0
        else -1
        if fast < middle < slow and slow <= previous_slow and momentum < 0
        else 0
    )
    out["trend"] = trend
    out["features"] = {
        "sma9": str(fast),
        "sma21": str(middle),
        "sma30": str(slow),
        "fast_period": 5,
        "slow_period": 15,
        "timeframe": "1m",
        "rsi14_cutler": str(rsi),
        "atr14_pct": str(atr),
        "volume_ratio": str(ratio),
        "close": str(c.c),
        "momentum_15m_pct": str(momentum),
        "momentum_atr_ratio": str(abs(momentum) / atr) if atr else "0",
        "range_15m_pct": str(recent_range),
        "sma30_slope_pct": str((slow / previous_slow - 1) * 100),
        "strategy_revision": STRATEGY_REVISION,
    }
    if now - out["bar_end"] > 90000:
        out["reason"] = "Минутная свеча устарела: ждём свежие данные"
        return out
    if not Decimal(".05") <= atr <= Decimal("1.5"):
        out["reason"] = "Минутная волатильность вне диапазона 0,05–1,5%"
        return out
    if not Decimal(".5") <= ratio <= 5:
        out["reason"] = "Объём вне диапазона 0,5–5×"
        return out
    if not trend:
        out["reason"] = "Нет согласованного тренда SMA5/15/30"
        return out
    if abs(momentum) < atr * Decimal(settings["min_momentum_atr"]):
        out["reason"] = "Движение за 15 минут слабее одного ATR: вход пропущен"
        return out
    if not (55 <= rsi <= 75 if trend == 1 else 25 <= rsi <= 45):
        out["reason"] = "RSI не подтверждает импульс: 55–75 LONG / 25–45 SHORT"
        return out
    if trend * (c.c - c.o) <= 0 or trend * (c.c - fast) <= 0:
        out["reason"] = "Закрытая свеча не подтверждает направление тренда"
        return out
    out["candidate"] = {
        "id": f"confirmed:{c.t}:{trend}",
        "direction": trend,
        "rule": "confirmed_trend",
        "strategy_revision": STRATEGY_REVISION,
        "bar_t": c.t,
        "bar_end": out["bar_end"],
        "features": out["features"],
    }
    out["reason"] = "Подтверждённый тренд SMA5/15/30 и импульс не менее одного ATR"
    return out
