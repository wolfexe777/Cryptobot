"""Explicit PAPER frequency experiment. No claim of a profitable trading edge."""

from decimal import Decimal

from . import activity


def evaluate(bars, now, settings):
    out = activity.evaluate(bars, now, settings)
    out["candidate"] = None
    out["strategy"] = "paper_cadence"
    if out["features"] is None:
        return out
    if now - out["bar_end"] > 90000:
        out["reason"] = "PAPER по расписанию: минутная свеча устарела"
        return out
    rows = sorted((b for b in bars if b.t + 60000 <= now), key=lambda b: b.t)[-31:]
    if Decimal(out["features"]["volume_ratio"]) <= 0:
        out["reason"] = "PAPER по расписанию: нет объёма последней минуты"
        return out
    c = rows[-1]
    choices = [
        ("closed_minute_body", c.c - c.o),
        ("three_minute_return", c.c - rows[-4].c),
        ("fifteen_minute_return", c.c - rows[-16].c),
    ]
    basis, change = next(((name, value) for name, value in choices if value), (None, 0))
    if not change:
        out["reason"] = "PAPER по расписанию: цена не меняется, направления нет"
        return out
    direction = 1 if change > 0 else -1
    out["features"]["frequency_experiment"] = True
    out["candidate"] = {
        "id": f"paper-cadence:{now // 900000}",
        "direction": direction,
        "rule": "paper_cadence",
        "strategy_revision": "paper-cadence-1",
        "frequency_experiment": True,
        "direction_basis": basis,
        "bar_t": out["bar_t"],
        "bar_end": out["bar_end"],
        "features": out["features"],
    }
    out["reason"] = "PAPER по расписанию: направление закрытой свечи, без порога MGM"
    return out
