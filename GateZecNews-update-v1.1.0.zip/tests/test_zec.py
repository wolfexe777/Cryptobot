"""Synthetic news/quotes for technical checks only; no performance claims."""

import copy
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal
from email.utils import format_datetime
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from zecbot import market, news
from zecbot.config import DEFAULT, validate
from zecbot.service import Service, restore_book
from zecbot.web import create_server

SPEC = {
    "multiplier": ".01",
    "minimum": 1,
    "maintenance": ".003",
    "tick": ".01",
    "fee": ".00075",
    "funding_interval": 28800,
    "funding_offset": 0,
}
NOW = 1793400000000


def article(title="Zcash NU7 activated", source="ecc", stamp=NOW, path="news-a", seen=None):
    host = news.SOURCES[source]["host"]
    date = format_datetime(datetime.fromtimestamp(stamp / 1000, timezone.utc))
    xml = f"<rss><channel><item><title>{title}</title><link>https://{host}/{path}</link><pubDate>{date}</pubDate><description>Zcash ecosystem</description></item></channel></rss>".encode()
    return news.parse_feed(xml, source, stamp if seen is None else seen)[0]


class NewsTests(unittest.TestCase):
    def test_only_asset_specific_confirmed_events_have_direction(self):
        cases = {
            "Zcash NU7 activated": 1,
            "SEC approves Zcash ETF": 1,
            "Coinbase lists Zcash": 1,
            "Zcash network halted": -1,
            "Kraken delists Zcash": -1,
            "Zcash could get ETF approval": 0,
            "SEC has not approved Zcash ETF": 0,
            "Zcash surges 20% after news": 0,
            "Zcash fixes vulnerability": 0,
            "SEC approves Bitcoin ETF while Zcash waits": 0,
            "Binance lists Bitcoin while Zcash developers meet": 0,
            "Bitcoin network halted while Zcash remains online": 0,
            "Zcash ETF application filed": 0,
            "Zcash denies network halt": 0,
            "EU bans Zcash trading": -1,
            "EU considers ban on Zcash": 0,
        }
        for title, side in cases.items():
            with self.subTest(title=title):
                self.assertEqual(news.classify(title, "Zcash", "coindesk")["direction"], side)

    def test_parse_preserves_publication_and_first_observation_separately(self):
        row = article(stamp=NOW - 60000, seen=NOW)
        self.assertEqual(row["published_at"], NOW - 60000)
        self.assertEqual(row["first_seen"], NOW)

    def test_rss_missing_date_is_visible_but_never_a_trade(self):
        data = b"<rss><channel><item><title>Zcash NU7 activated</title><link>https://electriccoin.co/post</link></item></channel></rss>"
        row = news.parse_feed(data, "ecc", NOW)[0]
        self.assertIsNone(row["published_at"])
        self.assertEqual(
            news.confirmed_events(
                [row], {"ecc": {"last_ok": NOW, "error": None}}, NOW, DEFAULT["news"]
            ),
            [],
        )

    def test_atom_namespaces_and_plain_text(self):
        data = b'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>&lt;b&gt;Zcash NU7 activated&lt;/b&gt;</title><link href="https://electriccoin.co/post"/><published>2026-10-31T00:00:00Z</published></entry></feed>'
        row = news.parse_feed(data, "ecc", NOW)[0]
        self.assertEqual(row["title"], "Zcash NU7 activated")
        self.assertIsNotNone(row["published_at"])

    def test_xml_entities_utf16_large_payload_and_html_are_rejected(self):
        for data in (
            b'<!DOCTYPE rss [<!ENTITY x "bad">]><rss/>',
            "<rss/>".encode("utf-16"),
            b"x" * (1024 * 1024 + 1),
            b"<html>not a feed</html>",
        ):
            with self.subTest(data=data[:30]), self.assertRaises(news.NewsError):
                news.parse_feed(data, "ecc", NOW)

    def test_links_are_https_and_publisher_scoped(self):
        for url in (
            "http://electriccoin.co/p",
            "https://electriccoin.co.evil/p",
            "https://user@electriccoin.co/p",
            "https://127.0.0.1/p",
            "javascript:alert(1)",
        ):
            self.assertFalse(news.allowed_url(url, "ecc"))
        self.assertTrue(news.allowed_url("https://www.electriccoin.co/p", "ecc"))

    def test_tracking_removed_without_collapsing_wordpress_article_ids(self):
        def row(n):
            data = f"<rss><channel><item><title>Zcash NU7 activated</title><link>https://electriccoin.co/?p={n}&amp;utm_source=x</link></item></channel></rss>".encode()
            return news.parse_feed(data, "ecc", NOW)[0]

        self.assertNotEqual(row(1)["id"], row(2)["id"])
        self.assertEqual(row(1)["url"], "https://electriccoin.co/?p=1")

    def test_one_primary_or_two_distinct_publishers_required(self):
        primary = article()
        a = article("Zcash NU7 activated", "coindesk")
        b = article("ZEC network upgrade NU7 activation complete", "cointelegraph")
        health = {s: {"last_ok": NOW, "error": None} for s in news.SOURCES}
        self.assertEqual(len(news.confirmed_events([primary], health, NOW, DEFAULT["news"])), 1)
        self.assertEqual(news.confirmed_events([a], health, NOW, DEFAULT["news"]), [])
        self.assertEqual(len(news.confirmed_events([a, b], health, NOW, DEFAULT["news"])), 1)

    def test_copied_titles_do_not_count_as_two_confirmations(self):
        rows = [article(source=s) for s in ("coindesk", "cointelegraph")]
        health = {s: {"last_ok": NOW, "error": None} for s in news.SOURCES}
        self.assertEqual(news.confirmed_events(rows, health, NOW, DEFAULT["news"]), [])

    def test_stale_future_baseline_and_offline_sources_do_not_confirm(self):
        health = {"ecc": {"last_ok": NOW, "error": None}}
        for changes in (
            {"first_seen": NOW + 1},
            {"published_at": NOW + 120000},
            {"published_at": NOW - 7200000},
            {"baseline": True},
        ):
            row = article()
            row.update(changes)
            self.assertEqual(news.confirmed_events([row], health, NOW, DEFAULT["news"]), [])
        self.assertEqual(
            news.confirmed_events(
                [article()], {"ecc": {"last_ok": NOW, "error": "offline"}}, NOW, DEFAULT["news"]
            ),
            [],
        )

    def test_changed_story_invalidates_other_confirmations(self):
        row = article()
        row.update(invalidated_event="upgrade:nu7", updated_at=NOW)
        self.assertEqual(
            news.confirmed_events([row], {"ecc": {"last_ok": NOW}}, NOW, DEFAULT["news"]), []
        )


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.settings = self.root / "settings.json"
        cfg = copy.deepcopy(DEFAULT)
        cfg["sources"] = ["ecc"]
        self.settings.write_text(json.dumps(cfg))
        self.boundary = (NOW // 28800000 + 1) * 28800000
        self.clock = self.boundary - 10 * 60000 + 10000
        self.feed = []
        self.price = Decimal("100")
        self.reaction = False
        self.feed_error = False
        self.patches = [
            patch("zecbot.service.time.time", side_effect=lambda: self.clock / 1000),
            patch("zecbot.service.market.packet", side_effect=self.packet),
            patch(
                "zecbot.service.market.funding_prices",
                side_effect=lambda events, bars: {e["t"]: "100" for e in events},
            ),
            patch("zecbot.service.news.fetch", side_effect=self.fetch),
        ]
        for p in self.patches:
            p.start()
        self.service = Service(self.root / "data", self.settings)

    def tearDown(self):
        self.service.close()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def fetch(self, source, timeout=20):
        if self.feed_error:
            raise OSError("offline fixture")
        return self.clock, copy.deepcopy(self.feed)

    def packet(self):
        last = self.clock // 60000 * 60000 - 60000
        bars = [
            market.Candle(
                t, Decimal(100), Decimal("100.2"), Decimal("99.8"), Decimal(100), Decimal(10)
            )
            for t in range(last - 119 * 60000, last + 1, 60000)
        ]
        if self.reaction:
            bars[-1] = market.Candle(
                last,
                self.price - Decimal(".15"),
                self.price + Decimal(".1"),
                self.price - Decimal(".2"),
                self.price,
                Decimal(30),
            )
        q = {
            "t": self.clock + 1000,
            "bid": str(self.price - Decimal(".01")),
            "ask": str(self.price + Decimal(".01")),
        }
        rates = [
            {"t": t, "rate": ".0001"}
            for t in range(self.boundary - 28800000, self.boundary + 28800001, 28800000)
        ]
        return {"spec": dict(SPEC), "bars": bars, "quote": q, "funding": rates}

    def new_story(self, title="Zcash NU7 activated", path="new-story"):
        self.feed = [article(title, stamp=self.clock, path=path)]
        self.service.poll_news()

    def open_position(self):
        self.service.poll_news()  # Empty initial snapshot, no invented old stories.
        self.new_story()
        self.service.tick()
        self.clock += 60000
        self.service.tick()
        self.assertIsNotNone(self.service.state["arm"])
        self.clock += 120000
        self.price = Decimal("100.4")
        self.reaction = True
        self.service.poll_news()
        self.service.tick()
        self.assertIsNotNone(self.service.state["book"]["position"])

    def test_first_snapshot_never_opens_from_existing_rss_headlines(self):
        self.feed = [article(stamp=self.clock)]
        self.service.poll_news()
        self.service.tick()
        self.clock += 180000
        self.price = Decimal("100.4")
        self.reaction = True
        self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])
        self.assertTrue(self.service.status()["news"][0]["baseline"])

    def test_news_needs_later_completed_price_and_actual_quote_execution(self):
        self.open_position()
        status = self.service.status()
        p = status["position"]
        self.assertGreater(p["time"], status["news"][0]["first_seen"])
        self.assertEqual(p["time"], status["quote"]["t"])
        self.assertGreater(Decimal(p["entry"]), Decimal(status["quote"]["ask"]))
        self.assertGreater(Decimal(status["summary"]["fees"]), 0)
        self.assertLess(Decimal(status["summary"]["net_pnl"]), 0)  # modeled round trip costs

    def test_negative_news_can_open_short_after_new_downward_price_reaction(self):
        self.service.poll_news()
        self.new_story("Zcash network halted")
        self.clock += 60000
        self.service.tick()
        self.clock += 120000
        self.price = Decimal("99.6")
        self.reaction = True
        packet = self.packet()
        bar = packet["bars"][-1]
        packet["bars"][-1] = market.Candle(
            bar.t, Decimal("99.75"), Decimal("99.8"), Decimal("99.5"), Decimal("99.6"), Decimal(30)
        )
        self.service.poll_news()
        with patch("zecbot.service.market.packet", return_value=packet):
            self.service.tick()
        position = self.service.status()["position"]
        self.assertEqual(position["side"], -1)
        self.assertLess(Decimal(position["entry"]), Decimal(packet["quote"]["bid"]))

    def test_news_already_priced_by_large_move_does_not_arm(self):
        self.service.poll_news()
        self.new_story()
        self.clock += 60000
        self.price = Decimal("104")
        self.service.tick()
        self.assertIsNone(self.service.state["arm"])
        self.assertIsNone(self.service.state["book"]["position"])

    def test_unconfirmed_direction_does_not_arm_despite_price_reaction(self):
        self.service.poll_news()
        self.new_story("Zcash could activate NU7")
        self.clock += 180000
        self.price = Decimal("100.4")
        self.reaction = True
        self.service.poll_news()
        self.service.tick()
        self.assertIsNone(self.service.state["arm"])
        self.assertIsNone(self.service.state["book"]["position"])

    def test_repeated_quote_and_news_are_not_duplicate_fills(self):
        self.open_position()
        before = copy.deepcopy(self.service.state)
        self.service.poll_news()
        self.service.tick()
        self.assertEqual(self.service.state, before)
        self.assertEqual(self.service.db.execute("SELECT COUNT(*) FROM articles").fetchone()[0], 1)

    def test_wide_spread_blocks_entry(self):
        self.service.poll_news()
        self.new_story()
        self.clock += 60000
        self.service.tick()
        self.clock += 120000
        self.price = Decimal("100.4")
        self.reaction = True
        self.service.poll_news()
        packet = self.packet()
        packet["quote"].update(bid="100", ask="100.8")
        with patch("zecbot.service.market.packet", return_value=packet):
            self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])
        self.assertIn("Спред", self.service.state["message"])

    def test_old_signal_cannot_extend_after_expiry(self):
        self.service.poll_news()
        self.new_story()
        self.clock += 60000
        self.service.tick()
        self.clock += 11 * 60000
        self.price = Decimal("100.4")
        self.reaction = True
        self.service.poll_news()
        self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])
        self.assertIsNone(self.service.state["arm"])

    def test_news_failure_blocks_entries_but_not_existing_stop(self):
        self.open_position()
        self.service.set_entries(False)
        self.feed_error = True
        self.service.poll_news()
        self.clock += 10000
        self.price = Decimal("98")
        self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])
        row = self.service.status()["history"][0]
        self.assertEqual(row["reason"], "stop_loss")
        self.assertLess(Decimal(row["exit_price"]), Decimal(98))
        self.assertIsNotNone(row["entry_news"])

    def test_opposing_confirmed_news_reduces_position_even_with_mixed_news(self):
        self.open_position()
        self.clock += 10000
        self.feed.append(article("Zcash network halted", stamp=self.clock, path="incident"))
        self.service.poll_news()
        self.service.tick()
        self.assertIsNone(self.service.state["book"]["position"])
        row = self.service.status()["history"][0]
        self.assertEqual(row["reason"], "news_reversal")
        self.assertEqual(row["exit_news"]["direction"], -1)

    def test_changed_headline_cancels_event_and_closes_exposure(self):
        self.open_position()
        seen = self.service.status()["news"][0]["first_seen"]
        self.clock += 10000
        self.feed = [article("Zcash NU7 activation denied", stamp=self.clock, path="new-story")]
        self.service.poll_news()
        self.service.tick()
        row = self.service.status()["news"][0]
        self.assertEqual(row["first_seen"], seen)
        self.assertEqual(row["classification"]["direction"], 0)
        self.assertEqual(self.service.status()["history"][0]["reason"], "news_retraction")
        self.clock += 10000
        self.service.poll_news()
        self.assertEqual(self.service.status()["news"][0]["invalidated_event"], "upgrade:nu7")

    def test_restart_keeps_positions_news_consumption_and_execution_costs(self):
        self.open_position()
        before = copy.deepcopy(self.service.state)
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(self.service.state, before)
        self.assertEqual(restore_book(before).metrics(), self.service.status()["summary"])
        self.assertEqual(len(self.service.status()["news"]), 1)

    def test_no_late_commit_after_pause_during_network(self):
        before = copy.deepcopy(self.service.state)
        packet = self.packet()

        def delayed():
            self.service.set_entries(False)
            return packet

        with patch("zecbot.service.market.packet", side_effect=delayed):
            self.service.tick()
        self.assertFalse(self.service.state["entries_enabled"])
        self.assertEqual(self.service.state["book"], before["book"])

    def test_slow_history_fetch_requires_a_fresh_quote_before_execution(self):
        self.open_position()
        self.clock += 10000
        packet = self.packet()
        packet["quote"]["t"] = self.clock - 3000
        fresh = self.packet()["quote"]
        with (
            patch("zecbot.service.market.packet", return_value=packet),
            patch("zecbot.service.market.quote", return_value=fresh) as get,
        ):
            self.service.tick()
        get.assert_called_once()
        self.assertEqual(self.service.state["quote"]["t"], fresh["t"])

    def test_funding_is_once_and_is_in_closed_trade_net(self):
        self.open_position()
        p = self.service.state["book"]["position"]
        quantity = Decimal(p["quantity"])
        self.clock = self.boundary + 60000
        self.service.tick()
        cost = quantity * 100 * Decimal(".0001")
        self.assertEqual(Decimal(self.service.state["book"]["funding"]), cost)
        self.service.tick()
        self.assertEqual(Decimal(self.service.state["book"]["funding"]), cost)
        self.clock += 10000
        self.price = Decimal("98")
        self.service.tick()
        self.assertEqual(Decimal(self.service.status()["history"][0]["funding"]), cost)

    def test_missing_funding_does_not_advance_financial_state(self):
        self.open_position()
        before = copy.deepcopy(self.service.state)
        self.clock = self.boundary + 60000
        packet = self.packet()
        packet["funding"] = []
        with (
            patch("zecbot.service.market.packet", return_value=packet),
            self.assertRaises(market.MarketError),
        ):
            self.service.tick()
        self.assertEqual(self.service.state, before)

    def test_explicit_archive_and_config_changes_preserve_old_account(self):
        self.service.tick()
        session = self.service.state["session"]
        cfg = copy.deepcopy(DEFAULT)
        cfg["sources"] = ["ecc"]
        cfg["trade"]["balance"] = "20000"
        self.settings.write_text(json.dumps(cfg))
        self.assertTrue(self.service.status()["settings_changed"])
        with self.assertRaises(ValueError):
            self.service.reset("ARCHIVE_ZEC_PAPER")
        self.service.set_entries(False)
        self.service.reset("ARCHIVE_ZEC_PAPER")
        self.assertNotEqual(self.service.state["session"], session)
        self.assertEqual(self.service.state["config"]["trade"]["balance"], "20000")
        self.assertEqual(self.service.db.execute("SELECT COUNT(*) FROM archives").fetchone()[0], 1)

    def test_csv_preserves_news_provenance(self):
        self.open_position()
        self.clock += 10000
        self.price = Decimal(98)
        self.service.tick()
        data = self.service.export_csv()
        self.assertTrue(data.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"Zcash NU7 activated", data)
        self.assertIn(b"entry_news_json", data)


class ConfigMarketTests(unittest.TestCase):
    def test_live_unknown_sources_and_invalid_thresholds_rejected(self):
        for changed in (
            {"mode": "live"},
            {"contract": "ETH_USDT"},
            {"sources": ["untrusted"]},
            {"api_key": "secret"},
        ):
            cfg = copy.deepcopy(DEFAULT)
            cfg.update(changed)
            with self.assertRaises(ValueError):
                validate(cfg)
        cfg = copy.deepcopy(DEFAULT)
        cfg["news"]["min_move_pct"] = "NaN"
        with self.assertRaises(ValueError):
            validate(cfg)

    def test_public_contract_calls_are_zec_and_validate_name(self):
        raw = {
            "name": "ZEC_USDT",
            "type": "direct",
            "quanto_multiplier": ".01",
            "order_size_min": 1,
            "maintenance_rate": ".003",
            "taker_fee_rate": ".00075",
            "order_price_round": ".01",
            "funding_interval": 28800,
        }
        with patch("zecbot.market.get", return_value=raw) as get:
            self.assertEqual(market.contract()["tick"], "0.01")
        get.assert_called_once_with("/contracts/ZEC_USDT")
        raw["name"] = "ETH_USDT"
        with patch("zecbot.market.get", return_value=raw), self.assertRaises(market.MarketError):
            market.contract()

    def test_quote_spread_uses_observed_bids_asks_and_rejects_crossed_book(self):
        raw = {"bids": [{"p": "100", "s": 1}], "asks": [{"p": "100.2", "s": 1}]}
        with patch("zecbot.market.get", return_value=raw):
            self.assertEqual(market.quote()["ask"], "100.2")
        raw["asks"][0]["p"] = "99"
        with patch("zecbot.market.get", return_value=raw), self.assertRaises(market.MarketError):
            market.quote()

    def test_candle_gap_and_invalid_ohlc_rejected(self):
        rows = [
            {"t": 60, "o": "100", "h": "101", "l": "99", "c": "100", "v": "1"},
            {"t": 180, "o": "100", "h": "101", "l": "99", "c": "100", "v": "1"},
        ]
        with patch("zecbot.market.get", return_value=rows), self.assertRaises(market.MarketError):
            market.candles()
        rows[0]["h"] = "98"
        with (
            patch("zecbot.market.get", return_value=rows[:1]),
            self.assertRaises(market.MarketError),
        ):
            market.candles()


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        settings = root / "settings.json"
        settings.write_text(json.dumps(DEFAULT))
        self.service = Service(root / "data", settings)
        self.server, self.token = create_server(
            self.service, Path(__file__).resolve().parents[1] / "app/static", 0
        )
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)
        self.service.close()
        self.tmp.cleanup()

    def test_actual_page_status_and_control_authentication(self):
        with urllib.request.urlopen(self.base + "/") as response:
            self.assertIn(b"ZEC_USDT", response.read())
        with urllib.request.urlopen(self.base + "/api/status") as response:
            self.assertFalse(json.load(response)["real_orders"])
        with self.assertRaises(urllib.error.HTTPError) as err:
            urllib.request.urlopen(urllib.request.Request(self.base + "/api/pause", data=b"{}"))
        self.assertEqual(err.exception.code, 403)
        err.exception.close()
        req = urllib.request.Request(
            self.base + "/api/pause", data=b"{}", headers={"X-Control-Token": self.token}
        )
        urllib.request.urlopen(req).close()
        self.assertFalse(self.service.state["entries_enabled"])

    def test_foreign_origin_and_filesystem_paths_rejected(self):
        req = urllib.request.Request(
            self.base + "/api/start",
            data=b"{}",
            headers={"X-Control-Token": self.token, "Origin": "https://example.com"},
        )
        with self.assertRaises(urllib.error.HTTPError) as err:
            urllib.request.urlopen(req)
        self.assertEqual(err.exception.code, 403)
        err.exception.close()
        with self.assertRaises(urllib.error.HTTPError) as err:
            urllib.request.urlopen(self.base + "/../settings.json")
        self.assertEqual(err.exception.code, 404)
        err.exception.close()

    def test_fake_historical_news_backtest_is_not_exposed(self):
        req = urllib.request.Request(
            self.base + "/api/backtest", data=b'{"days":7}', headers={"X-Control-Token": self.token}
        )
        with self.assertRaises(urllib.error.HTTPError) as err:
            urllib.request.urlopen(req)
        self.assertEqual(err.exception.code, 400)
        err.exception.close()


if __name__ == "__main__":
    unittest.main()
