"""Offline integrity checks; --network separately checks real public endpoints."""

import argparse
import hashlib
import json
import os
import platform
import sys
import time
import unittest
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--network", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args(argv)
    from zecbot import VERSION

    print("Gate ZEC News PAPER check:", VERSION, platform.platform(), sys.version.split()[0])
    if args.network:
        from zecbot import market, news

        def test(name, action):
            start = time.monotonic()
            try:
                result = action()
                feed = name in news.SOURCES
                rows = result[1] if feed else []
                record = {
                    "id": name,
                    "ok": True,
                    "elapsed_ms": int((time.monotonic() - start) * 1000),
                }
                if feed:
                    record.update(
                        kind=news.SOURCES[name].get("kind", "publisher"),
                        url=news.SOURCES[name]["url"],
                        entries=len(rows),
                        can_signal=news.SOURCES[name].get("can_signal", True),
                        publishers=sorted(
                            {
                                r.get("publisher", r["source"])
                                for r in rows
                                if r.get("can_signal", True)
                            }
                        ),
                    )
                print(
                    name,
                    "OK",
                    f"{len(rows)} items; {record['kind']}"
                    if feed
                    else "ZEC contract/book/funding available",
                    f"({record['elapsed_ms']} ms)",
                    flush=True,
                )
                return record
            except Exception as exc:
                print(name, "FAILED:", str(exc), flush=True)
                return {
                    "id": name,
                    "ok": False,
                    "error": str(exc),
                    "elapsed_ms": int((time.monotonic() - start) * 1000),
                }

        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = [pool.submit(test, "Gate ZEC_USDT", market.packet)]
            futures.extend(
                pool.submit(test, key, lambda key=key: news.fetch(key)) for key in news.SOURCES
            )
            results = [f.result() for f in as_completed(futures)]
        gate = next(r["ok"] for r in results if r["id"] == "Gate ZEC_USDT")
        feeds = [r for r in results if r["id"] in news.SOURCES and r["ok"]]
        event_feeds = [r for r in feeds if r["can_signal"]]
        summary = {
            "version": VERSION,
            "platform": platform.platform(),
            "python": sys.version.split()[0],
            "checked_at_utc": datetime.now(timezone.utc).isoformat(),
            "gate_ok": gate,
            "feeds_available": len(feeds),
            "event_feeds_available": len(event_feeds),
            "results": results,
            "real_orders": False,
            "status": "EVENT_FEEDS_AVAILABLE"
            if gate and event_feeds
            else "ONLY_RELEASE_FEEDS_AVAILABLE"
            if gate and feeds
            else "NEWS_OR_GATE_UNAVAILABLE",
        }
        output = (
            args.report
            or Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share")))
            / "GateZecNews"
            / "network-check.json"
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(
            "Gate:",
            "OK" if gate else "FAILED",
            "| Feeds:",
            len(feeds),
            "| Event-capable feeds:",
            len(event_feeds),
        )
        if feeds and not event_feeds:
            print("Only software releases available. They DO NOT authorize news trades.")
        elif not event_feeds:
            print("No event feeds available. News entries remain blocked.")
        else:
            print(
                "News routes available. Every trade still needs a NEW confirmed event and price reaction."
            )
        print("Diagnostic JSON:", output)
        print("No orders were submitted; public endpoints only.")
        return 0 if gate and event_feeds else 2 if gate and feeds else 1
    manifest = ROOT / "MANIFEST.json"
    if manifest.exists():
        changed = []
        for relative, sha in json.loads(manifest.read_text(encoding="utf-8"))["files"].items():
            path = ROOT / relative
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != sha:
                changed.append(relative)
        if changed:
            print("Changed files:", ", ".join(changed))
            if changed != ["settings.json"]:
                return 1
        else:
            print("All packaged file hashes: OK")
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(
        "Test quotes/news are technical fixtures, not trading performance. No external network used."
    )
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
