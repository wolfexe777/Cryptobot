"""Pause regression checks with synthetic quotes, not market performance."""

import copy
import json
import sys
import unittest
from decimal import Decimal as D
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import test_activity as activity_tests
from solbot.broker import Broker, TradeConfig
from solbot.config import DEFAULT
from solbot.service import trend_exit_due
from test_activity import BASE
from test_hybrid import SPEC


def point(t, p=100):
    p = D(str(p))
    return SimpleNamespace(t=t, o=p, h=p, l=p, c=p)


class StreakPauseTests(unittest.TestCase):
    def broker(self, **updates):
        cfg = dict(DEFAULT["trade"])
        cfg.update(updates)
        return Broker(TradeConfig(**cfg), SPEC)

    def lose_twice(self, b):
        for i in range(2):
            t = BASE + i * 900000
            b.process(point(t), 0)
            b.open(t, D(100), 1)
            self.assertIsNotNone(b.position)
            b.close(t + 60000, D("99.9"), "fixture_loss")
            b.last_t = t + 60000
            b.check_limits()
        return BASE + 16 * 60000

    def test_second_small_loss_pauses_15_minutes_not_remainder_of_day(self):
        b = self.broker()
        last_exit = self.lose_twice(b)
        self.assertFalse(b.limits["daily_halt"])
        self.assertEqual(b.limits["streak_pause_until"], last_exit + 900000)
        self.assertEqual(b.metrics()["risk_status"], "streak_pause")
        b.open(last_exit + 899999, D(100), 1)
        self.assertIsNone(b.position)
        b.process(point(last_exit + 900000), 0)
        b.open(last_exit + 900000, D(100), 1)
        self.assertIsNotNone(b.position)
        self.assertEqual(b.limits["streak"], 0)

    def test_restart_does_not_shorten_or_extend_pause(self):
        b = self.broker()
        t = self.lose_twice(b)
        b = Broker.restore(json.loads(json.dumps(b.to_state())))
        b.open(t + 60000, D(100), 1)
        self.assertIsNone(b.position)
        self.assertEqual(b.limits["streak_pause_until"], t + 900000)
        b.process(point(t + 900000), 0)
        self.assertEqual(b.metrics()["risk_status"], "active")

    def test_expiry_never_clears_monetary_daily_or_total_halt(self):
        for kind in ("daily_halt", "total_halt"):
            b = self.broker()
            t = self.lose_twice(b)
            b.limits[kind] = True
            if kind == "daily_halt":
                b.limits["daily_halt_reason"] = "daily_loss"
            b.process(point(t + 900000), 0)
            b.open(t + 900000, D(100), 1)
            self.assertIsNone(b.position)
            self.assertTrue(b.limits[kind])

    def test_legacy_retest_policy_still_halts_after_two_losses(self):
        b = self.broker(streak_pause_minutes=0)
        self.lose_twice(b)
        self.assertTrue(b.limits["daily_halt"])
        self.assertEqual(b.limits["daily_halt_reason"], "loss_streak")

    def test_unknown_old_halt_is_not_silently_cleared_on_restore(self):
        b = self.broker()
        self.lose_twice(b)
        s = b.to_state()
        s["limits"]["daily_halt"] = True
        s["limits"].pop("daily_halt_reason")
        s["limits"].pop("streak_pause_until")
        restored = Broker.restore(s)
        self.assertTrue(restored.limits["daily_halt"])
        self.assertEqual(restored.limits["daily_halt_reason"], "legacy_unknown")

    def test_daily_limit_records_actual_monetary_reason(self):
        b = self.broker()
        b.process(point(BASE), 0)
        b.wallet = D("99.69")
        b.check_limits()
        self.assertTrue(b.limits["daily_halt"])
        self.assertEqual(b.limits["daily_halt_reason"], "daily_loss")

    def test_pause_validation(self):
        for x in (-1, 61, True, "15"):
            with self.assertRaises(ValueError):
                self.broker(streak_pause_minutes=x)


class TrendExitTests(unittest.TestCase):
    def p(self, rule="active_momentum"):
        return {"side": 1, "time": BASE, "entry_reason": {"rule": rule}}

    def tech(self, minute, trend=-1):
        return {
            "bar_t": BASE + minute * 60000,
            "bar_end": BASE + (minute + 1) * 60000,
            "trend": trend,
        }

    def test_range_reversal_not_closed_by_existing_opposite_trend(self):
        p = self.p("active_range_reversal")
        for i in range(1, 10):
            self.assertFalse(trend_exit_due(p, self.tech(i), True))

    def test_momentum_requires_two_consecutive_opposite_completed_bars(self):
        p = self.p()
        self.assertFalse(trend_exit_due(p, self.tech(1), True))
        self.assertFalse(trend_exit_due(p, self.tech(1), True))
        self.assertTrue(trend_exit_due(p, self.tech(2), True))

    def test_gap_and_neutral_break_the_confirmation_sequence(self):
        p = self.p()
        self.assertFalse(trend_exit_due(p, self.tech(1), True))
        self.assertFalse(trend_exit_due(p, self.tech(3), True))
        self.assertFalse(trend_exit_due(p, self.tech(4, 0), True))
        self.assertFalse(trend_exit_due(p, self.tech(5), True))
        self.assertTrue(trend_exit_due(p, self.tech(6), True))

    def test_entry_bar_cannot_count_as_confirmation_and_retest_unchanged(self):
        p = self.p()
        self.assertFalse(trend_exit_due(p, self.tech(-1), True))
        self.assertTrue(trend_exit_due(p, self.tech(1), False))


class ServicePauseFixTests(unittest.TestCase):
    setUp = activity_tests.ActiveExecutionTests.setUp
    tearDown = activity_tests.ActiveExecutionTests.tearDown
    now = activity_tests.ActiveExecutionTests.now
    packet = activity_tests.ActiveExecutionTests.packet
    step = activity_tests.ActiveExecutionTests.step
    open = activity_tests.ActiveExecutionTests.open

    def legacy(self, reason="legacy_unknown"):
        self.step(1)
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"].update(daily_halt=True, daily_halt_reason=reason, streak=2)
        self.service.commit(state)

    def test_legacy_resume_waits_for_fresh_quote_and_preserves_wallet(self):
        self.legacy()
        wallet = self.service.state["book"]["wallet"]
        session = self.service.state["session"]
        self.service.resume_legacy_pause()
        self.assertTrue(self.service.state["book"]["limits"]["daily_halt"])
        self.assertTrue(self.service.status()["activity"]["resume_pending"])
        self.step(2)
        self.assertFalse(self.service.state["book"]["limits"]["daily_halt"])
        self.assertEqual(self.service.state["session"], session)
        # No reset to 100: equity changes only through normal entry costs.
        self.assertLessEqual(D(self.service.state["book"]["wallet"]), D(wallet))
        self.assertTrue(
            any(d["kind"] == "legacy_pause_resumed" for d in self.service.status()["decisions"])
        )

    def test_legacy_resume_refuses_current_daily_breach(self):
        self.legacy()
        state = copy.deepcopy(self.service.state)
        state["book"]["wallet"] = "99.6"
        self.service.commit(state)
        self.service.resume_legacy_pause()
        self.step(2)
        limits = self.service.state["book"]["limits"]
        self.assertTrue(limits["daily_halt"])
        self.assertEqual(limits["daily_halt_reason"], "daily_loss")
        self.assertIsNone(self.service.status()["position"])

    def test_known_daily_and_total_stops_cannot_be_resumed(self):
        self.legacy("daily_loss")
        with self.assertRaises(ValueError):
            self.service.resume_legacy_pause()
        state = copy.deepcopy(self.service.state)
        state["book"]["limits"].update(daily_halt_reason="legacy_unknown", total_halt=True)
        self.service.commit(state)
        with self.assertRaises(ValueError):
            self.service.resume_legacy_pause()

    def test_network_failure_does_not_clear_queued_legacy_halt(self):
        self.legacy()
        self.service.resume_legacy_pause()
        before = copy.deepcopy(self.service.state)
        with patch("solbot.service.market.packet", side_effect=OSError("fixture offline")):
            with self.assertRaises(OSError):
                self.step(2)
        self.assertEqual(self.service.state, before)

    def test_late_entry_closes_by_end_of_current_quarter(self):
        self.step(1)
        self.step(10)
        self.assertIsNotNone(self.service.status()["position"])
        self.step(15)
        row = self.service.status()["history"][0]
        self.assertEqual(row["reason"], "window_end")
        self.assertEqual(row["exit_time"], self.now())

    def test_interval_export_records_real_observations_only(self):
        self.step(1)
        self.service.set_entries(False)
        self.step(2)
        self.step(46)
        s = self.service.status()
        windows = s["activity"]["windows"]
        self.assertEqual(len(windows), 2)  # offline windows were never observed
        self.assertEqual(windows[0]["reason"], "paused")
        self.assertIn(b"first_observed", self.service.export_activity_csv())
        self.assertEqual(sum(w["entries"] for w in windows), 0)
