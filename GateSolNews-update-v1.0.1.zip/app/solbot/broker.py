"""One-position futures PAPER broker. Exact and screening runs share execution rules."""

import copy
import math
from dataclasses import asdict, dataclass
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal, InvalidOperation, localcontext


@dataclass(frozen=True)
class TradeConfig:
    stop: str = ".004"
    take: str = ".006"
    direction: str = "both"
    max_hold: int = 30
    cooldown: int = 0
    allocation: str = ".10"
    leverage: int = 1
    fee: str = ".00075"
    slippage: str = ".0002"
    balance: str = "10000"
    daily_loss_pct: str = "0"
    total_loss_pct: str = "0"
    daily_entries: int = 0
    loss_streak: int = 0
    streak_pause_minutes: int = 0

    def __post_init__(self):
        limits = {
            "stop": (".0001", ".5"),
            "take": (".0001", "1"),
            "allocation": (".001", "1"),
            "fee": ("0", ".02"),
            "slippage": ("0", ".02"),
            "balance": ("1", "1e12"),
            "daily_loss_pct": ("0", "100"),
            "total_loss_pct": ("0", "100"),
        }
        for key, (lo, hi) in limits.items():
            try:
                value = Decimal(str(getattr(self, key)))
            except InvalidOperation as exc:
                raise ValueError(f"Invalid {key}") from exc
            if not value.is_finite() or not Decimal(lo) <= value <= Decimal(hi):
                raise ValueError(f"Invalid {key}")
            object.__setattr__(self, key, str(value))
        if self.direction not in ("both", "long", "short"):
            raise ValueError("Invalid direction")
        for name, lo, hi in (
            ("max_hold", 1, 240),
            ("cooldown", 0, 120),
            ("leverage", 1, 5),
            ("streak_pause_minutes", 0, 60),
        ):
            if type(getattr(self, name)) is not int or not lo <= getattr(self, name) <= hi:
                raise ValueError(f"Invalid {name}")
        for name in ("daily_entries", "loss_streak"):
            if type(getattr(self, name)) is not int or not 0 <= getattr(self, name) <= 100:
                raise ValueError(f"Invalid {name}")

    @property
    def limited(self):
        return bool(
            Decimal(self.daily_loss_pct)
            or Decimal(self.total_loss_pct)
            or self.daily_entries
            or self.loss_streak
        )

    def to_dict(self):
        result = asdict(self)
        if not self.streak_pause_minutes:
            result.pop("streak_pause_minutes")
        if not self.limited:
            for key in ("daily_loss_pct", "total_loss_pct", "daily_entries", "loss_streak"):
                result.pop(key)
        return result


class Broker:
    def __init__(self, config, spec, exact=True):
        self.config, self.spec, self.exact = config, dict(spec), exact
        self.num = Decimal if exact else float
        self.zero = self.num(0)
        self.balance = self.num(config.balance)
        self.wallet = self.peak = self.balance
        self.fee, self.slip = self.num(config.fee), self.num(config.slippage)
        self.stop, self.take = self.num(config.stop), self.num(config.take)
        self.mult, self.tick = self.num(spec["multiplier"]), self.num(spec["tick"])
        self.maintenance = self.num(spec["maintenance"])
        self.alloc = self.num(config.allocation)
        self.position = None
        self.entry_management = None
        self.last_entry_block = None
        self.pending = 0
        self.last_t = None
        self.last_price = None
        self.last_exit = -(10**18)
        self.fees = self.funding = self.realized = self.gains = self.losses = self.zero
        self.max_dd = self.zero
        self.trades = self.wins = self.liquidations = self.hold_ms = 0
        self.history, self.curve = [], []
        self.limits = (
            {
                "day": None,
                "day_start": self.balance,
                "entries": 0,
                "streak": 0,
                "daily_halt": False,
                "daily_halt_reason": None,
                "streak_pause_until": 0,
                "total_halt": False,
            }
            if config.limited
            else None
        )

    def risk_equity(self):
        value = self.wallet + self.unrealized()
        if self.position:
            p = self.position
            exit_price = self.price(self.last_price, p["side"] == -1)
            value -= p["side"] * p["quantity"] * (self.last_price - exit_price)
            value -= exit_price * p["quantity"] * self.fee
        return value

    def release_streak_pause(self, timestamp):
        if (
            self.limits
            and self.limits.get("streak_pause_until", 0)
            and timestamp >= self.limits["streak_pause_until"]
        ):
            self.limits.update(streak_pause_until=0, streak=0)

    def roll_limits(self, timestamp):
        self.release_streak_pause(timestamp)
        if self.limits is not None and self.limits["day"] != timestamp // 86400000:
            self.limits.update(
                day=timestamp // 86400000,
                day_start=self.risk_equity(),
                entries=0,
                streak=0,
                daily_halt=False,
                daily_halt_reason=None,
            )

    def check_limits(self):
        if self.limits is None:
            return
        value = self.risk_equity()
        daily, total = self.num(self.config.daily_loss_pct), self.num(self.config.total_loss_pct)
        if daily and value <= self.limits["day_start"] * (1 - daily / 100):
            self.limits["daily_halt"] = True
            self.limits["daily_halt_reason"] = "daily_loss"
        if total and value <= self.balance * (1 - total / 100):
            self.limits["total_halt"] = True

    def price(self, reference, buy):
        value = reference * (1 + self.slip if buy else 1 - self.slip)
        units = value / self.tick
        if self.exact:
            units = units.to_integral_value(rounding=ROUND_CEILING if buy else ROUND_FLOOR)
        else:
            units = math.ceil(units - 1e-9) if buy else math.floor(units + 1e-9)
        result = units * self.tick
        if result <= 0:
            raise ValueError("Execution price below contract tick")
        return result

    def risk(self, opening, high, low):
        p = self.position
        side, entry, quantity = p["side"], p["entry"], p["quantity"]
        stop = p.get("protective_stop", entry * (1 - side * self.stop))
        take = entry * (1 + side * p.get("target_fraction", self.take))
        reserve = p["margin"] - p["funding"]
        if side == 1:
            liq = (quantity * entry - reserve) / (quantity * (1 - self.maintenance))
            liq_hit, gap_liq = low <= liq, opening <= liq
            liq_first, hit_stop, gap_stop, hit_take = (
                liq >= stop,
                low <= stop,
                opening <= stop,
                high >= take,
            )
        else:
            liq = (quantity * entry + reserve) / (quantity * (1 + self.maintenance))
            liq_hit, gap_liq = high >= liq, opening >= liq
            liq_first, hit_stop, gap_stop, hit_take = (
                liq <= stop,
                high >= stop,
                opening >= stop,
                low <= take,
            )
        if liq_hit and (gap_liq or liq_first):
            return (opening if gap_liq else low if side == 1 else high), "liquidation"
        if hit_stop:
            return (opening if gap_stop else stop), (
                "trailing_stop"
                if "initial_risk" in p and side * (stop - entry) > 0
                else "stop_loss"
            )
        if hit_take:
            return take, "take_profit"
        return None

    def close(self, t, reference, reason):
        p = self.position
        price = self.price(reference, p["side"] == -1)
        fee = price * p["quantity"] * self.fee
        gross = p["side"] * p["quantity"] * (price - p["entry"])
        if reason == "liquidation":
            gross = max(gross, -p["margin"])
            self.liquidations += 1
        self.wallet += gross - fee
        self.fees += fee
        net = gross - p["entry_fee"] - fee - p["funding"]
        self.realized += net
        self.gains += max(net, self.zero)
        self.losses += max(-net, self.zero)
        self.trades += 1
        self.wins += int(net > 0)
        self.hold_ms += t - p["time"]
        if self.limits is not None:
            self.limits["streak"] = self.limits["streak"] + 1 if net <= 0 else 0
            if self.config.loss_streak and self.limits["streak"] >= self.config.loss_streak:
                if self.config.streak_pause_minutes:
                    self.limits["streak_pause_until"] = t + self.config.streak_pause_minutes * 60000
                else:
                    self.limits["daily_halt"] = True
                    self.limits["daily_halt_reason"] = (
                        self.limits.get("daily_halt_reason") or "loss_streak"
                    )
        record = {
            "entry_time": p["time"],
            "exit_time": t,
            "side": "LONG" if p["side"] == 1 else "SHORT",
            "contracts": str(p["contracts"])
            if isinstance(p["contracts"], Decimal)
            else p["contracts"],
            "quantity": str(p["quantity"]),
            "entry_price": str(p["entry"]),
            "exit_price": str(price),
            "net_pnl": str(net),
            "fees": str(p["entry_fee"] + fee),
            "funding": str(p["funding"]),
            "reason": reason,
        }
        if self.exact:
            self.history.append(record)
            self.history = self.history[-5000:]
        self.position = None
        self.last_exit = t
        return record

    def open(self, t, reference, side):
        self.last_entry_block = None
        self.release_streak_pause(t)
        if self.limits is not None and (
            self.limits["daily_halt"]
            or self.limits["total_halt"]
            or t < self.limits.get("streak_pause_until", 0)
            or (self.config.daily_entries and self.limits["entries"] >= self.config.daily_entries)
        ):
            self.last_entry_block = "Лимит потерь или пауза после серии убытков"
            return
        if self.config.leverage > self.num(self.spec.get("max_leverage", self.config.leverage)):
            self.last_entry_block = "Плечо профиля превышает текущий предел SOL-контракта Gate"
            return
        allowed = self.config.direction == "both" or self.config.direction == (
            "long" if side == 1 else "short"
        )
        if not allowed or self.wallet <= 0 or t - self.last_exit < self.config.cooldown * 60000:
            self.last_entry_block = (
                "Запрещённое направление, недостаток средств или пауза после выхода"
            )
            return
        price = self.price(reference, side == 1)
        step = self.num(self.spec.get("size_step", "1"))
        minimum = self.num(self.spec["minimum"])
        unit = price * self.mult * step
        count = int((self.wallet * self.alloc) / (unit / self.config.leverage + unit * self.fee))
        if "maximum" in self.spec:
            count = min(count, int(self.num(self.spec["maximum"]) / step))
        management = self.entry_management
        if management:
            # Fees, adverse execution and two ticks are included in sizing;
            # gaps and future funding can still exceed this planned budget.
            stop_fraction = self.num(management["stop_fraction"])
            risk_unit = (
                unit * (stop_fraction + 2 * self.fee + 2 * self.slip)
                + 2 * self.tick * self.mult * step
            )
            count = min(count, int(self.wallet * self.num(management["risk_fraction"]) / risk_unit))
        if count * step < minimum:
            self.last_entry_block = "Минимальный контракт не укладывается в бюджет маржи или риска"
            return
        contracts = count if step == 1 else count * step
        quantity = contracts * self.mult
        notional = quantity * price
        margin, fee = notional / self.config.leverage, notional * self.fee
        if margin + fee > self.wallet * self.alloc:
            count -= 1
            if count * step < minimum:
                self.last_entry_block = "Минимальный контракт не укладывается в бюджет маржи"
                return
            contracts = count if step == 1 else count * step
            quantity = contracts * self.mult
            notional = quantity * price
            margin, fee = notional / self.config.leverage, notional * self.fee
        self.wallet -= fee
        self.fees += fee
        self.position = {
            "side": side,
            "entry": price,
            "time": t,
            "contracts": contracts,
            "quantity": quantity,
            "margin": margin,
            "entry_fee": fee,
            "funding": self.zero,
        }
        if management:
            risk = price * self.num(management["stop_fraction"])
            self.position.update(
                initial_risk=risk,
                protective_stop=price - side * risk,
                target_fraction=self.num(management["stop_fraction"]) * 2,
                best_price=price,
            )
        if self.limits is not None:
            self.limits["entries"] += 1

    def update_protection(self, observed_price):
        """Called AFTER risk checks; revised stop applies to subsequent quotes."""
        p = self.position
        if not p or "initial_risk" not in p:
            return
        side, entry, risk = p["side"], p["entry"], p["initial_risk"]
        better = max if side == 1 else min
        p["best_price"] = better(p["best_price"], observed_price)
        profit = side * (p["best_price"] - entry)
        stop = p["protective_stop"]
        if profit >= risk:
            # Solve expected net exit >= 0 including current fees, adverse
            # execution, funding paid and tick rounding. Never loosen a stop.
            exit_fill = (entry + side * (p["entry_fee"] + p["funding"]) / p["quantity"]) / (
                1 - side * self.fee
            )
            breakeven = (exit_fill + side * self.tick) / (1 - side * self.slip)
            if side * (observed_price - breakeven) > 0:
                stop = better(stop, breakeven)
        if profit >= risk * self.num("1.5"):
            stop = better(stop, p["best_price"] - side * risk)
        p["protective_stop"] = stop

    def process(self, bar, signal, rate="0"):
        if type(signal) is not int or signal not in (-1, 0, 1):
            raise ValueError("Signal must be -1, 0 or +1")
        if self.last_t is not None and bar.t <= self.last_t:
            return []
        if not self.exact:
            return self._process(bar, signal, rate)
        with localcontext() as ctx:
            ctx.prec = 40
            return self._process(bar, signal, rate)

    def _process(self, bar, signal, rate):
        pending_limit_exit = bool(
            self.position
            and self.limits
            and (self.limits["daily_halt"] or self.limits["total_halt"])
        )
        self.roll_limits(bar.t)
        if self.exact:
            o, h, l, c = [Decimal(str(getattr(bar, k))) for k in ("o", "h", "l", "c")]
        else:
            o, h, l, c = bar.o, bar.h, bar.l, bar.c
        closed = []
        if self.position and self.position["time"] < bar.t:
            cost = self.position["side"] * self.position["quantity"] * o * self.num(str(rate))
            self.wallet -= cost
            self.funding += cost
            self.position["funding"] += cost
        blocked = False
        if pending_limit_exit:
            if self.position:
                closed.append(self.close(bar.t, o, "risk_limit"))
            blocked = True
        if self.position:
            gap = self.risk(o, o, o)
            if gap:
                closed.append(self.close(bar.t, *gap))
                blocked = True
            elif bar.t - self.position[
                "time"
            ] >= self.config.max_hold * 60000 or bar.t >= self.position.get(
                "exit_deadline", 10**30
            ):
                reason = (
                    "window_end"
                    if self.position.get("exit_deadline", 10**30)
                    < self.position["time"] + self.config.max_hold * 60000
                    else "time_limit"
                )
                closed.append(self.close(bar.t, o, reason))
                blocked = True
        if self.pending and not blocked:
            if self.position and self.position["side"] != self.pending:
                closed.append(self.close(bar.t, o, "signal_reverse"))
            if not self.position:
                self.open(bar.t, o, self.pending)
        if self.position and not blocked:
            risk = self.risk(o, h, l)
            if risk:
                closed.append(self.close(bar.t, *risk))
        self.pending = signal
        self.last_t, self.last_price = bar.t, c
        self.check_limits()
        equity = self.wallet + self.unrealized()
        self.peak = max(self.peak, equity)
        self.max_dd = max(self.max_dd, (self.peak - equity) / self.peak * 100)
        if self.exact:
            self.curve.append({"timestamp": bar.t, "equity": str(equity)})
            self.curve = self.curve[-5000:]
        return closed

    def unrealized(self):
        p = self.position
        return p["side"] * p["quantity"] * (self.last_price - p["entry"]) if p else self.zero

    def metrics(self):
        with localcontext() as ctx:
            ctx.prec = 40
            mark = self.wallet + self.unrealized()
            terminal = exit_fee = self.zero
            if self.position:
                p = self.position
                exit_price = self.price(self.last_price, p["side"] == -1)
                exit_fee = exit_price * p["quantity"] * self.fee
                terminal = p["side"] * p["quantity"] * (self.last_price - exit_price) + exit_fee
            net = mark - self.balance - terminal
            result = {
                "wallet": self.wallet,
                "equity": mark,
                "net_pnl": net,
                "mark_to_market_pnl": mark - self.balance,
                "exit_cost": terminal,
                "exit_fee": exit_fee,
                "return_pct": net / self.balance * 100,
                "max_drawdown_pct": max(
                    self.max_dd, (self.peak - (mark - terminal)) / self.peak * 100
                ),
                "fees": self.fees,
                "funding": self.funding,
                "realized_pnl": self.realized,
                "profit_factor": self.gains / self.losses if self.losses else None,
                "avg_hold_minutes": self.hold_ms / self.trades / 60000 if self.trades else 0,
                "trades": self.trades,
                "wins": self.wins,
                "win_rate": self.wins / self.trades * 100 if self.trades else 0,
                "liquidations": self.liquidations,
                "last_timestamp": self.last_t,
                "position": self.position is not None,
            }
            if self.limits is not None:
                result["risk_status"] = (
                    "total_stop"
                    if self.limits["total_halt"]
                    else "daily_pause"
                    if self.limits["daily_halt"]
                    else "streak_pause"
                    if self.limits.get("streak_pause_until", 0) > (self.last_t or 0)
                    else "entry_cap"
                    if self.config.daily_entries
                    and self.limits["entries"] >= self.config.daily_entries
                    else "active"
                )
                result["daily_entries"] = self.limits["entries"]
                result["daily_halt_reason"] = self.limits.get("daily_halt_reason")
                result["streak_pause_until"] = self.limits.get("streak_pause_until", 0)
            return {k: str(v) if isinstance(v, Decimal) else v for k, v in result.items()}

    def to_state(self):
        money = (
            "wallet",
            "peak",
            "fees",
            "funding",
            "realized",
            "gains",
            "losses",
            "max_dd",
            "last_price",
        )
        return {
            "version": 1,
            "config": self.config.to_dict(),
            "spec": self.spec,
            **{k: str(getattr(self, k)) if getattr(self, k) is not None else None for k in money},
            **{
                k: copy.deepcopy(getattr(self, k))
                for k in (
                    "pending",
                    "last_t",
                    "last_exit",
                    "trades",
                    "wins",
                    "liquidations",
                    "hold_ms",
                    "history",
                    "curve",
                )
            },
            "position": {
                k: str(v) if isinstance(v, Decimal) else v for k, v in self.position.items()
            }
            if self.position
            else None,
            **(
                {
                    "limits": {
                        k: str(v) if isinstance(v, Decimal) else v for k, v in self.limits.items()
                    }
                }
                if self.limits is not None
                else {}
            ),
        }

    @classmethod
    def restore(cls, state):
        state = copy.deepcopy(state)
        if state.get("version") != 1:
            raise ValueError("Unsupported portfolio state")
        broker = cls(TradeConfig(**state["config"]), state["spec"])
        if broker.limits is not None:
            broker.limits = dict(state["limits"])
            broker.limits.setdefault(
                "daily_halt_reason", "legacy_unknown" if broker.limits["daily_halt"] else None
            )
            broker.limits.setdefault("streak_pause_until", 0)
            broker.limits["day_start"] = Decimal(broker.limits["day_start"])
            if not broker.limits["day_start"].is_finite():
                raise ValueError("Corrupt risk limit state")
        for k in (
            "wallet",
            "peak",
            "fees",
            "funding",
            "realized",
            "gains",
            "losses",
            "max_dd",
            "last_price",
        ):
            value = None if state[k] is None else Decimal(state[k])
            if value is not None and not value.is_finite():
                raise ValueError("Corrupt monetary state")
            setattr(broker, k, value)
        for k in (
            "pending",
            "last_t",
            "last_exit",
            "trades",
            "wins",
            "liquidations",
            "hold_ms",
            "history",
            "curve",
        ):
            setattr(broker, k, state[k])
        if state["position"]:
            p = dict(state["position"])
            for k in (
                "entry",
                "quantity",
                "margin",
                "entry_fee",
                "funding",
                "initial_risk",
                "protective_stop",
                "target_fraction",
                "best_price",
            ):
                if k not in p:
                    continue
                p[k] = Decimal(p[k])
                if not p[k].is_finite():
                    raise ValueError("Corrupt position")
            if isinstance(p["contracts"], str):
                p["contracts"] = Decimal(p["contracts"])
            contracts = Decimal(str(p["contracts"]))
            if not contracts.is_finite() or contracts <= 0:
                raise ValueError("Corrupt contract size")
            if p["side"] not in (-1, 1) or p["quantity"] != p["contracts"] * broker.mult:
                raise ValueError("Inconsistent position")
            broker.position = p
        return broker


def evaluate(bars, signals, config, spec, rates, start, end, exact=True):
    if not 0 <= start < end <= len(bars) or len(signals) != len(bars):
        raise ValueError("Invalid research segment")
    broker = Broker(config, spec, exact=exact)
    for i in range(start, end):
        broker.process(bars[i], int(signals[i]), rates.get(bars[i].t, "0"))
    return broker.metrics(), broker
