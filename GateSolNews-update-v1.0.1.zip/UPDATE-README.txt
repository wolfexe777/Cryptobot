SOL ONLY 1.0.0 -> 1.0.1. Do NOT overlay on ZEC.
Stop SOL with STOP.cmd, extract into the existing SOL folder replacing files, run CHECK.cmd, CHECK_NETWORK.cmd, START.cmd. Runtime and settings are preserved; the wallet is not reset.
Adds decimal PAPER contract sizes for enable_decimal=true/order_size_min=0. Conservative PAPER increment is 0.1 contracts, not a claim about Gate's exact minimum.
CHECK_GATE_DETAIL.cmd collects public endpoint fields without account data or orders.
