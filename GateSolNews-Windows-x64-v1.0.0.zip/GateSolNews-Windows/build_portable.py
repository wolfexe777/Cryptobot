"""Assemble a self-contained Windows x64 zip from checksum-pinned runtime and sources."""

import argparse
import hashlib
import json
import shutil
import tarfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


def build(output, runtime_archive=None, patch_output=None):
    if patch_output:
        raise ValueError("SOL is a separate package: extract the full ZIP into a new folder")
    root = Path(__file__).resolve().parent
    lock = json.loads((root / "runtime-lock.json").read_text())
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Archive exists; use a new output filename")
    if patch_output and Path(patch_output).exists():
        raise ValueError("Patch exists; use a new output filename")
    cache = root / ".build-cache"
    cache.mkdir(exist_ok=True)
    archive = Path(runtime_archive) if runtime_archive else cache / "runtime.tar.gz"
    if not archive.exists():
        with (
            urllib.request.urlopen(lock["url"], timeout=60) as response,
            archive.open("wb") as stream,
        ):
            shutil.copyfileobj(response, stream)
    with archive.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    if checksum != lock["sha256"]:
        raise ValueError("Runtime SHA256 mismatch; downloaded artifact is not used")
    build_root = root / ".build/GateSolNews-Windows"
    if build_root.exists():
        shutil.rmtree(build_root)
    runtime = build_root / "runtime"
    runtime.mkdir(parents=True)
    with tarfile.open(archive, "r:gz") as source:
        for member in source.getmembers():
            relative = PurePosixPath(member.name).relative_to("python")
            if ".." in relative.parts or relative.is_absolute():
                raise ValueError("Unsafe runtime path")
            destination = runtime.joinpath(*relative.parts)
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                destination.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(member) as src, destination.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
            else:
                raise ValueError("Unexpected runtime link; extraction refused")
    if not (runtime / "python.exe").is_file() or not (runtime / "LICENSE.txt").is_file():
        raise ValueError("Incomplete Windows runtime")
    for name in ("app", "tools", "tests"):
        shutil.copytree(
            root / name, build_root / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
        )
    for name in (
        "START.cmd",
        "STOP.cmd",
        "CHECK.cmd",
        "CHECK_NETWORK.cmd",
        "ENABLE_AUTOSTART.cmd",
        "DISABLE_AUTOSTART.cmd",
        "settings.json",
        "README-RU.txt",
        "LICENSE.txt",
        "SOURCES.md",
        "runtime-lock.json",
        "VALIDATION.md",
        "build_portable.py",
    ):
        shutil.copy2(root / name, build_root / name)
    files = {
        str(p.relative_to(build_root)).replace("\\", "/"): hashlib.sha256(
            p.read_bytes()
        ).hexdigest()
        for p in sorted(build_root.rglob("*"))
        if p.is_file()
    }
    (build_root / "MANIFEST.json").write_text(
        json.dumps({"version": 1, "files": files}, indent=2), encoding="utf-8"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in sorted(build_root.rglob("*")):
            if path.is_file():
                bundle.write(path, "GateSolNews-Windows/" + path.relative_to(build_root).as_posix())
    with output.open("rb") as stream:
        bundle_hash = hashlib.file_digest(stream, "sha256").hexdigest()
    output.with_suffix(".zip.sha256").write_text(bundle_hash + "  " + output.name + "\n")
    print(
        json.dumps(
            {
                "archive": str(output),
                "bytes": output.stat().st_size,
                "sha256": bundle_hash,
                "files": len(files),
                "runtime_sha256_verified": True,
            }
        )
    )
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-archive", type=Path)
    parser.add_argument("--patch-output", type=Path)
    args = parser.parse_args()
    build(args.output, args.runtime_archive, args.patch_output)
