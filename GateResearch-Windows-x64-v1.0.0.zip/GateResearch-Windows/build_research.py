"""Build a separate Windows research tool; never ship wallets or start trading."""

import argparse
import hashlib
import json
import shutil
import tarfile
import zipfile
from pathlib import Path, PurePosixPath


def build(output, runtime_archive):
    root = Path(__file__).resolve().parent
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Output already exists")
    lock = json.loads((root / "runtime-lock.json").read_text())
    archive = Path(runtime_archive)
    if hashlib.sha256(archive.read_bytes()).hexdigest() != lock["sha256"]:
        raise ValueError("Pinned Windows runtime checksum mismatch")
    staging = root / ".research-build/GateResearch-Windows"
    if staging.exists():
        shutil.rmtree(staging)
    runtime = staging / "runtime"
    runtime.mkdir(parents=True)
    with tarfile.open(archive, "r:gz") as source:
        for item in source.getmembers():
            relative = PurePosixPath(item.name).relative_to("python")
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Unsafe runtime path")
            target = runtime.joinpath(*relative.parts)
            if item.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif item.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(item) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
            else:
                raise ValueError("Unsupported runtime link")
    for folder in ("app", "tests", "third_party"):
        shutil.copytree(
            root / folder, staging / folder, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
        )
    tools = staging / "tools"
    tools.mkdir()
    for name in ("compare_swing.py", "research_swing.py"):
        shutil.copy2(root / "tools" / name, tools / name)
    check = (root / "tools/check.py").read_text()
    check = check.replace('pattern="test_windows.py"', 'pattern="test_*.py"').replace(
        "GatePaper technical", "GateResearch technical"
    )
    (tools / "check.py").write_text(check, encoding="utf-8")
    for name in ("LICENSE.txt", "SOURCES.md", "runtime-lock.json", "build_research.py"):
        shutil.copy2(root / name, staging / name)
    sample = staging / "sample"
    sample.mkdir()
    input_dataset = root / "research-inputs/alternatives-30d-5m.json"
    if not input_dataset.exists():
        input_dataset = root / "sample/dataset.json"
    shutil.copy2(input_dataset, sample / "dataset.json")
    reports = root.parent / "reports/efficiency-20261031/swing"
    if not reports.exists():
        reports = root / "sample"
    for name in ("protocol.json", "development.json", "selection.json", "results.json"):
        shutil.copy2(reports / name, sample / name)
    diagnosis = root.parent / "reports/efficiency-20261031/diagnosis.json"
    if not diagnosis.exists():
        diagnosis = root / "sample/diagnosis.json"
    shutil.copy2(diagnosis, sample / "diagnosis.json")
    readme = root / "RESEARCH-README-RU.txt"
    shutil.copy2(readme if readme.exists() else root / "README-RU.txt", staging / "README-RU.txt")
    commands = {
        "RUN_RESEARCH.cmd": "tools\\research_swing.py --contracts ETH_USDT",
        "RUN_LIQUID.cmd": "tools\\research_swing.py --contracts ETH_USDT BTC_USDT SOL_USDT",
        "TEST_OFFLINE.cmd": 'tools\\research_swing.py --dataset "%~dp0sample\\dataset.json"',
        "CHECK.cmd": "tools\\check.py",
    }
    for name, command in commands.items():
        content = (
            '@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\n"runtime\\python.exe" -I -B -X utf8 '
            + command
            + "\r\nif errorlevel 1 echo Research failed. See the message above.\r\npause\r\n"
        )
        (staging / name).write_bytes(content.encode("ascii"))
    files = {
        p.relative_to(staging).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(staging.rglob("*"))
        if p.is_file()
    }
    (staging / "MANIFEST.json").write_text(
        json.dumps({"version": 1, "files": files}, indent=2), encoding="utf-8"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in sorted(staging.rglob("*")):
            if path.is_file():
                bundle.write(path, "GateResearch-Windows/" + path.relative_to(staging).as_posix())
    sha = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(".zip.sha256").write_text(sha + "  " + output.name + "\n")
    print(
        json.dumps(
            {
                "archive": str(output),
                "bytes": output.stat().st_size,
                "sha256": sha,
                "files": len(files),
            }
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-archive", type=Path, required=True)
    args = parser.parse_args()
    build(args.output, args.runtime_archive)
