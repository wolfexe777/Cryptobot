@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 tools\research_swing.py --dataset "%~dp0sample\dataset.json"
if errorlevel 1 echo Research failed. See the message above.
pause
