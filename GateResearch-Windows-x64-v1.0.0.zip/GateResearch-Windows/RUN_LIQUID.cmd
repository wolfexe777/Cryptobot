@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 tools\research_swing.py --contracts ETH_USDT BTC_USDT SOL_USDT
if errorlevel 1 echo Research failed. See the message above.
pause
