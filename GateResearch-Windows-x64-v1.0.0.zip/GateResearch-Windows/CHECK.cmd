@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I -B -X utf8 tools\check.py
if errorlevel 1 echo Research failed. See the message above.
pause
