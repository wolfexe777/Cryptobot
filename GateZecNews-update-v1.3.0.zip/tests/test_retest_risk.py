"""Causality, sizing, protection and loss-preserving profile migration.

Synthetic prices exercise behavior; they are not a profitability backtest.
"""

import copy
import json
import sys
import tempfile
import unittest
from decimal import Decimal as D
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from test_hybrid import SPEC, START, append_bar, setup_bars
from zecbot import technical
from zecbot.broker import Broker, TradeConfig
from zecbot.config import DEFAULT, validate
from zecbot.service import Service


def tick(t, price):
    price = D(str(price))
    return SimpleNamespace(t=t, o=price, h=price, l=price, c=price)


class RetestTests(unittest.TestCase):
    def test_breakout_alone_never_enters(self):
        for side in (1, -1):
            bars = setup_bars(side)[:-5]
            self.assertIsNone(technical.evaluate(bars, START + 30 * 300000 + 10000)["candidate"])

    def test_first_later_retest_can_enter_both_directions(self):
        for side in (1, -1):
            result = technical.evaluate(setup_bars(side), START + 31 * 300000 + 10000)
            p = result["candidate"]
            self.assertEqual(p["direction"], side)
            self.assertLess(p["setup_t"], p["bar_t"])
            self.assertEqual(p["rule"], "breakout_retest")

    def test_same_breakout_cannot_be_reused_on_second_retest(self):
        for side in (1, -1):
            bars = setup_bars(side)
            o, c = (D("100.85"), D("100.96")) if side == 1 else (D("99.15"), D("99.04"))
            append_bar(bars, START + 31 * 300000, o, c)
            self.assertIsNone(technical.evaluate(bars, START + 32 * 300000 + 10000)["candidate"])

    def test_broken_time_sequence_blocks_entry(self):
        bars = setup_bars()
        del bars[80]
        self.assertIsNone(technical.evaluate(bars, START + 31 * 300000 + 10000)["candidate"])

    def test_final_climax_volume_blocks_entry(self):
        bars = setup_bars()
        for i in range(-5, 0):
            b = bars[i]
            bars[i] = type(b)(b.t, b.o, b.h, b.l, b.c, D(500))
        self.assertIsNone(technical.evaluate(bars, START + 31 * 300000 + 10000)["candidate"])


class ManagedRiskTests(unittest.TestCase):
    def broker(self, side=1, price=100):
        book = Broker(TradeConfig(**DEFAULT["trade"]), SPEC)
        book.entry_management = {"stop_fraction": ".01", "risk_fraction": ".0025"}
        book.pending = side
        book.process(tick(START, price), 0)
        self.assertIsNotNone(book.position)
        return book

    def test_default_requested_profile_and_leverage_validation(self):
        self.assertEqual(DEFAULT["trade"]["balance"], "100")
        self.assertEqual(DEFAULT["trade"]["leverage"], 5)
        with self.assertRaises(ValueError):
            TradeConfig(leverage=6)

    def test_100_usdt_sizing_obeys_margin_and_estimated_loss_budget(self):
        for side in (1, -1):
            for price in (100, 1150):
                b = self.broker(side, price)
                p = b.position
                self.assertLessEqual(p["margin"] + p["entry_fee"], D(5))
                # This is a no-gap stop estimate; future funding is unknown.
                exit_price = b.price(p["protective_stop"], side == -1)
                loss = (
                    -side * p["quantity"] * (exit_price - p["entry"])
                    + p["entry_fee"]
                    + exit_price * p["quantity"] * b.fee
                )
                self.assertLessEqual(loss, D(".25"))

    def test_minimum_contract_is_never_forced_over_budget(self):
        b = Broker(TradeConfig(**DEFAULT["trade"]), SPEC)
        b.entry_management = {"stop_fraction": ".018", "risk_fraction": ".00001"}
        b.pending = 1
        b.process(tick(START, 1150), 0)
        self.assertIsNone(b.position)
        self.assertEqual(b.wallet, D(100))

    def test_stop_loss_then_roundtrip_costs_respected(self):
        for side in (1, -1):
            b = self.broker(side)
            stop = b.position["protective_stop"]
            records = b.process(tick(START + 10000, stop), 0)
            self.assertEqual(records[0]["reason"], "stop_loss")
            self.assertLess(D(records[0]["net_pnl"]), 0)
            self.assertGreaterEqual(D(records[0]["net_pnl"]), D("-.25"))

    def test_protection_is_causal_monotone_and_persistent(self):
        for side in (1, -1):
            b = self.broker(side)
            p = b.position
            entry, risk = p["entry"], p["initial_risk"]
            initial = p["protective_stop"]
            quote = entry + side * risk * D("1.6")
            self.assertEqual(b.process(tick(START + 10000, quote), 0), [])
            self.assertEqual(p["protective_stop"], initial)  # no future intrabar path
            b.update_protection(quote)
            stop = p["protective_stop"]
            self.assertGreater(side * (stop - entry), 0)
            b.update_protection(entry + side * risk * D("1.4"))
            self.assertEqual(p["protective_stop"], stop)
            restored = Broker.restore(json.loads(json.dumps(b.to_state())))
            self.assertEqual(restored.position, p)
            rows = restored.process(tick(START + 20000, stop), 0)
            self.assertEqual(rows[0]["reason"], "trailing_stop")
            self.assertGreater(D(rows[0]["net_pnl"]), 0)

    def test_breakeven_covers_funding_fees_slippage_and_ticks(self):
        for side in (1, -1):
            b = self.broker(side)
            p = b.position
            funding = D(".003")
            b.wallet -= funding
            b.funding += funding
            p["funding"] += funding
            quote = p["entry"] + side * p["initial_risk"] * D("1.1")
            b.process(tick(START + 10000, quote), 0)
            b.update_protection(quote)
            rows = b.process(tick(START + 20000, p["protective_stop"]), 0)
            self.assertGreaterEqual(D(rows[0]["net_pnl"]), 0)

    def test_legacy_positions_keep_original_static_stop(self):
        b = Broker(TradeConfig(balance="100", leverage=5), SPEC)
        b.pending = 1
        b.process(tick(START, 100), 0)
        before = copy.deepcopy(b.position)
        b.update_protection(D(110))
        self.assertEqual(b.position, before)
        self.assertEqual(Broker.restore(b.to_state()).position, before)

    def test_management_nan_rejected(self):
        cfg = copy.deepcopy(DEFAULT)
        cfg["management"]["risk_per_trade_pct"] = "NaN"
        with self.assertRaises(ValueError):
            validate(cfg)


class ProfileMigrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.settings = self.root / "settings.json"
        self.settings.write_text(json.dumps(DEFAULT))
        self.service = Service(self.root / "data", self.settings)

    def tearDown(self):
        self.service.close()
        self.tmp.cleanup()

    def legacy(self, position=False):
        cfg = copy.deepcopy(DEFAULT)
        cfg["trade"].update(balance="10000", leverage=1)
        state = self.service.new_state(cfg)
        state.pop("account_profile")
        book = Broker(TradeConfig(**cfg["trade"]), SPEC)
        book.pending = 1
        book.process(tick(START, 100), 0)
        records = []
        if not position:
            records.append(book.close(START + 10000, D(99), "stop_loss"))
        state.update(
            book=book.to_state(),
            spec=SPEC,
            funding_cursor=START,
            quote={"t": START, "bid": "99.99", "ask": "100.01"},
        )
        self.service.commit(state, records)
        self.old = copy.deepcopy(self.service.state)
        self.settings.write_text(json.dumps(cfg))
        self.service.close()
        self.service = Service(self.root / "data", self.settings)

    def test_flat_old_losing_account_archived_once_without_erasing_trades(self):
        self.legacy()
        s = self.service.status()
        self.assertNotEqual(s["session"], self.old["session"])
        self.assertEqual(s["config"]["trade"]["balance"], "100")
        self.assertEqual(s["config"]["trade"]["leverage"], 5)
        self.assertEqual(len(s["archives"]), 1)
        self.assertEqual(self.service.export_csv().count(b"\n"), 1)
        self.assertIn(b"stop_loss", self.service.export_csv(str(s["archives"][0]["id"])))
        archived = json.loads(self.service.db.execute("SELECT body FROM archives").fetchone()[0])
        self.assertEqual(archived["book"], self.old["book"])
        self.service.close()
        self.service = Service(self.root / "data", self.settings)
        self.assertEqual(len(self.service.status()["archives"]), 1)
        self.assertEqual(self.service.state["session"], s["session"])

    def test_old_open_position_waits_then_closes_at_fresh_price_in_old_session(self):
        self.legacy(position=True)
        self.assertTrue(self.service.state["profile_pending"])
        self.assertFalse(self.service.state["entries_enabled"])
        self.assertEqual(self.service.state["book"], self.old["book"])
        with self.assertRaises(ValueError):
            self.service.set_entries(True)
        now = START + 20000
        packet = {
            "bars": [],
            "quote": {"t": now, "bid": "98.99", "ask": "99.01"},
            "spec": SPEC,
            "funding": [],
        }
        with (
            patch("zecbot.service.market.packet", return_value=packet),
            patch("zecbot.service.time.time", return_value=now / 1000),
        ):
            self.service.tick()
        s = self.service.status()
        self.assertEqual(s["config"]["trade"]["balance"], "100")
        self.assertIsNone(s["position"])
        row = self.service.db.execute("SELECT session,body FROM trades").fetchone()
        self.assertEqual(row[0], self.old["session"])
        record = json.loads(row[1])
        self.assertEqual(record["reason"], "profile_change")
        self.assertEqual(record["exit_time"], now)
        self.assertLess(D(record["net_pnl"]), 0)
        self.assertEqual(s["history"], [])
        self.assertTrue(s["entries_enabled"])

    def test_unavailable_market_does_not_invent_profile_closing_price(self):
        self.legacy(position=True)
        before = copy.deepcopy(self.service.state)
        with patch("zecbot.service.market.packet", side_effect=OSError("offline")):
            with self.assertRaises(OSError):
                self.service.tick()
        self.assertEqual(self.service.state, before)
        self.assertEqual(len(self.service.status()["archives"]), 0)

    def test_archive_ids_validated(self):
        for value in ("-1", "1 OR 1=1", "9999999999999999", "123"):
            with self.assertRaises(ValueError):
                self.service.export_csv(value)
