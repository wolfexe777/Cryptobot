"""Local PAPER-only settings. Network destinations cannot come from news text."""

import copy
import hashlib
import json

from .broker import TradeConfig

LEGACY_SOURCES = ["zcash", "ecc", "foundation", "coindesk", "cointelegraph"]
DEFAULT_SOURCES = [
    "zcash_github",
    "zebra_github",
    "google_news",
    "bing_news",
    "decrypt",
    "theblock",
    *LEGACY_SOURCES,
]


def upgrade_sources(config):
    """Upgrade transport/strategy defaults; never replace a wallet or risk profile."""
    result = copy.deepcopy(config)
    if result.get("sources") == LEGACY_SOURCES:
        result["sources"] = list(DEFAULT_SOURCES)
    result.setdefault("news_timeout_seconds", 20)
    result.setdefault(
        "management",
        {
            "risk_per_trade_pct": "0.25",
            "atr_multiple": "1.5",
            "min_stop_pct": "0.6",
            "max_stop_pct": "1.8",
        },
    )
    result.setdefault("trading", {"mode": "hybrid", "news_bias_minutes": 30})
    return result


DEFAULT = {
    "mode": "paper",
    "contract": "ZEC_USDT",
    "auto_start": True,
    "market_poll_seconds": 10,
    "news_poll_seconds": 60,
    "news_timeout_seconds": 20,
    "sources": DEFAULT_SOURCES,
    "trading": {"mode": "hybrid", "news_bias_minutes": 30},
    "news": {
        "max_age_minutes": 60,
        "confirmation_minutes": 20,
        "signal_ttl_minutes": 10,
        "min_move_pct": ".15",
        "max_move_pct": "1.5",
        "max_spread_pct": ".15",
        "volume_ratio": "1.2",
    },
    "management": {
        "risk_per_trade_pct": "0.25",
        "atr_multiple": "1.5",
        "min_stop_pct": "0.6",
        "max_stop_pct": "1.8",
    },
    "trade": TradeConfig(
        stop=".01",
        take=".02",
        max_hold=120,
        cooldown=15,
        allocation=".05",
        balance="100",
        leverage=5,
        daily_loss_pct=".3",
        total_loss_pct="1",
        daily_entries=4,
        loss_streak=2,
    ).to_dict(),
}


def validate(document):
    from decimal import Decimal

    if not isinstance(document, dict) or set(document) - set(DEFAULT):
        raise ValueError("Неизвестные настройки")
    result = upgrade_sources({**copy.deepcopy(DEFAULT), **document})
    if result["mode"] != "paper" or result["contract"] != "ZEC_USDT":
        raise ValueError("Поддерживается только PAPER, ZEC_USDT Gate")
    if type(result["auto_start"]) is not bool:
        raise ValueError("auto_start должен быть true/false")
    for key, lo, hi in (
        ("market_poll_seconds", 5, 60),
        ("news_poll_seconds", 60, 600),
        ("news_timeout_seconds", 8, 30),
    ):
        if type(result[key]) is not int or not lo <= result[key] <= hi:
            raise ValueError("Недопустимый интервал опроса")
    sources = result["sources"]
    if (
        not isinstance(sources, list)
        or not sources
        or any(not isinstance(s, str) or s not in DEFAULT["sources"] for s in sources)
        or len(set(sources)) != len(sources)
    ):
        raise ValueError("Укажите известные неповторяющиеся sources")
    news = result["news"]
    if not isinstance(news, dict) or set(news) != set(DEFAULT["news"]):
        raise ValueError("Некорректные news настройки")
    for key, lo, hi in (
        ("max_age_minutes", 5, 180),
        ("confirmation_minutes", 1, 30),
        ("signal_ttl_minutes", 2, 30),
    ):
        if type(news[key]) is not int or not lo <= news[key] <= hi:
            raise ValueError("Некорректное время новости")
    for key, lo, hi in (
        ("min_move_pct", ".05", "1"),
        ("max_move_pct", ".2", "3"),
        ("max_spread_pct", ".01", ".5"),
        ("volume_ratio", "1", "5"),
    ):
        value = Decimal(str(news[key]))
        if not value.is_finite() or not Decimal(lo) <= value <= Decimal(hi):
            raise ValueError("Некорректный порог новости/цены")
        news[key] = str(value)
    if Decimal(news["min_move_pct"]) >= Decimal(news["max_move_pct"]):
        raise ValueError("min_move_pct должен быть меньше max_move_pct")
    management = result["management"]
    if not isinstance(management, dict) or set(management) != set(DEFAULT["management"]):
        raise ValueError("Некорректные настройки управления позицией")
    for key, lo, hi in (
        ("risk_per_trade_pct", ".05", "1"),
        ("atr_multiple", "1", "3"),
        ("min_stop_pct", ".3", "2"),
        ("max_stop_pct", ".5", "3"),
    ):
        value = Decimal(str(management[key]))
        if not value.is_finite() or not Decimal(lo) <= value <= Decimal(hi):
            raise ValueError("Некорректный риск/ATR")
        management[key] = str(value)
    if Decimal(management["min_stop_pct"]) > Decimal(management["max_stop_pct"]):
        raise ValueError("Минимальный стоп больше максимального")
    result["trade"] = TradeConfig(**result["trade"]).to_dict()
    trading = result["trading"]
    if (
        not isinstance(trading, dict)
        or set(trading) != {"mode", "news_bias_minutes"}
        or trading["mode"] not in ("hybrid", "news_only")
        or type(trading["news_bias_minutes"]) is not int
        or not 10 <= trading["news_bias_minutes"] <= 60
    ):
        raise ValueError("trading: mode hybrid/news_only, news_bias_minutes 10–60")
    return result


def read(path):
    return validate(json.loads(path.read_text(encoding="utf-8-sig")))


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    ).hexdigest()
