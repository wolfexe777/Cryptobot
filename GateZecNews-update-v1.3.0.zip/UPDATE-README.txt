Gate ZEC News update 1.0.0/1.1.0/1.2.0 -> 1.3.0 RETEST
1. Stop the existing bot using STOP.cmd.
2. Extract this ZIP INTO the existing bot folder, replacing files.
3. Existing runtime and settings.json are preserved. Old wallet is archived on startup. An open PAPER position waits for a fresh quote before the switch to 100 USDT / 5x.
4. Run CHECK.cmd, CHECK_NETWORK.cmd, then START.cmd.
5. Diagnostics: %LOCALAPPDATA%\GateZecNews\network-check.json
The update requires the original 1.0.0 Windows package with its bundled runtime.
